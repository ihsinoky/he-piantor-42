import { SxClass } from "../base-classes/SxClass"
import type { PrimitiveSExpr } from "../parseToPrimitiveSExpr"
import { EmbeddedFonts } from "./EmbeddedFonts"
import { EmbeddedFiles } from "./EmbeddedFiles"
import { Footprint } from "./Footprint"
import { GrArc } from "./GrArc"
import { GrCircle } from "./GrCircle"
import { GrCurve } from "./GrCurve"
import { GrLine } from "./GrLine"
import { GrPoly } from "./GrPoly"
import { GrRect } from "./GrRect"
import { GrText } from "./GrText"
import { Image } from "./Image"
import { Paper } from "./Paper"
import { PcbGeneral } from "./PcbGeneral"
import { PcbGenerator } from "./PcbGenerator"
import { PcbGeneratorVersion } from "./PcbGeneratorVersion"
import { PcbLayers } from "./PcbLayers"
import { PcbNet } from "./PcbNet"
import { PcbArc } from "./PcbArc"
import { PcbVersion } from "./PcbVersion"
import { Property } from "./Property"
import { Segment } from "./Segment"
import { Setup } from "./Setup/Setup"
import { TitleBlock } from "./TitleBlock"
import { Via } from "./Via"
import { Zone } from "./Zone"

export interface KicadPcbConstructorParams {
  version?: number
  generator?: string
  generatorVersion?: string
  general?: PcbGeneral
  paper?: Paper
  titleBlock?: TitleBlock
  layers?: PcbLayers
  setup?: Setup
  properties?: Property[]
  nets?: PcbNet[]
  footprints?: Footprint[]
  images?: Image[]
  segments?: Segment[]
  arcs?: PcbArc[]
  graphicArcs?: GrArc[]
  graphicCircles?: GrCircle[]
  graphicCurves?: GrCurve[]
  graphicLines?: GrLine[]
  graphicTexts?: GrText[]
  graphicPolys?: GrPoly[]
  graphicRects?: GrRect[]
  vias?: Via[]
  zones?: Zone[]
  embeddedFonts?: EmbeddedFonts
  embeddedFiles?: EmbeddedFiles
  otherChildren?: SxClass[]
}

export class KicadPcb extends SxClass {
  static override token = "kicad_pcb"
  token = "kicad_pcb"

  private _sxVersion?: PcbVersion
  private _sxGenerator?: PcbGenerator
  private _sxGeneratorVersion?: PcbGeneratorVersion
  private _sxGeneral?: PcbGeneral
  private _sxPaper?: Paper
  private _sxTitleBlock?: TitleBlock
  private _sxLayers?: PcbLayers
  private _sxSetup?: Setup
  private _properties: Property[] = []
  private _nets: PcbNet[] = []
  private _footprints: Footprint[] = []
  private _images: Image[] = []
  private _segments: Segment[] = []
  private _arcs: PcbArc[] = []
  private _grArcs: GrArc[] = []
  private _grCircles: GrCircle[] = []
  private _grCurves: GrCurve[] = []
  private _grLines: GrLine[] = []
  private _grTexts: GrText[] = []
  private _grPolys: GrPoly[] = []
  private _grRects: GrRect[] = []
  private _vias: Via[] = []
  private _zones: Zone[] = []
  private _sxEmbeddedFonts?: EmbeddedFonts
  private _sxEmbeddedFiles?: EmbeddedFiles
  private _otherChildren: SxClass[] = []

  constructor(params: KicadPcbConstructorParams = {}) {
    super()
    if (params.version !== undefined) this.version = params.version
    if (params.generator !== undefined) this.generator = params.generator
    if (params.generatorVersion !== undefined)
      this.generatorVersion = params.generatorVersion
    if (params.general !== undefined) this.general = params.general
    if (params.paper !== undefined) this.paper = params.paper
    if (params.titleBlock !== undefined) this.titleBlock = params.titleBlock
    if (params.layers !== undefined) this.layers = params.layers
    if (params.setup !== undefined) this.setup = params.setup
    if (params.properties !== undefined) this.properties = params.properties
    if (params.nets !== undefined) this.nets = params.nets
    if (params.footprints !== undefined) this.footprints = params.footprints
    if (params.images !== undefined) this.images = params.images
    if (params.segments !== undefined) this.segments = params.segments
    if (params.arcs !== undefined) this.arcs = params.arcs
    if (params.graphicArcs !== undefined) this.graphicArcs = params.graphicArcs
    if (params.graphicCircles !== undefined)
      this.graphicCircles = params.graphicCircles
    if (params.graphicCurves !== undefined)
      this.graphicCurves = params.graphicCurves
    if (params.graphicLines !== undefined)
      this.graphicLines = params.graphicLines
    if (params.graphicTexts !== undefined)
      this.graphicTexts = params.graphicTexts
    if (params.graphicPolys !== undefined)
      this.graphicPolys = params.graphicPolys
    if (params.graphicRects !== undefined)
      this.graphicRects = params.graphicRects
    if (params.vias !== undefined) this.vias = params.vias
    if (params.zones !== undefined) this.zones = params.zones
    if (params.embeddedFonts !== undefined)
      this.embeddedFonts = params.embeddedFonts
    if (params.embeddedFiles !== undefined)
      this.embeddedFiles = params.embeddedFiles
    if (params.otherChildren !== undefined)
      this.otherChildren = params.otherChildren
  }

  static override fromSexprPrimitives(
    primitiveSexprs: PrimitiveSExpr[],
  ): KicadPcb {
    const pcb = new KicadPcb()

    for (const primitive of primitiveSexprs) {
      if (!Array.isArray(primitive) || primitive.length === 0) {
        throw new Error(
          `kicad_pcb encountered unsupported primitive child: ${JSON.stringify(primitive)}`,
        )
      }

      const parsed = SxClass.parsePrimitiveSexpr(primitive, {
        parentToken: KicadPcb.token,
      })

      if (!(parsed instanceof SxClass)) {
        throw new Error(
          `kicad_pcb expected SxClass child, received ${JSON.stringify(primitive)}`,
        )
      }

      pcb.consumeChild(parsed)
    }

    return pcb
  }

  private consumeChild(child: SxClass) {
    if (child instanceof PcbVersion) {
      this._sxVersion = child
      return
    }
    if (child instanceof PcbGenerator) {
      this._sxGenerator = child
      return
    }
    if (child instanceof PcbGeneratorVersion) {
      this._sxGeneratorVersion = child
      return
    }
    if (child instanceof PcbGeneral) {
      this._sxGeneral = child
      return
    }
    if (child instanceof Paper) {
      this._sxPaper = child
      return
    }
    if (child instanceof TitleBlock) {
      this._sxTitleBlock = child
      return
    }
    if (child instanceof PcbLayers) {
      this._sxLayers = child
      return
    }
    if (child instanceof Setup) {
      this._sxSetup = child
      return
    }
    if (child instanceof Property) {
      this._properties.push(child)
      return
    }
    if (child instanceof PcbNet) {
      this._nets.push(child)
      return
    }
    if (child instanceof Footprint) {
      this._footprints.push(child)
      return
    }
    if (child instanceof Image) {
      this._images.push(child)
      return
    }
    if (child instanceof Segment) {
      this._segments.push(child)
      return
    }
    if (child instanceof PcbArc) {
      this._arcs.push(child)
      return
    }
    if (child instanceof GrArc) {
      this._grArcs.push(child)
      return
    }
    if (child instanceof GrCircle) {
      this._grCircles.push(child)
      return
    }
    if (child instanceof GrCurve) {
      this._grCurves.push(child)
      return
    }
    if (child instanceof GrLine) {
      this._grLines.push(child)
      return
    }
    if (child instanceof GrText) {
      this._grTexts.push(child)
      return
    }
    if (child instanceof GrPoly) {
      this._grPolys.push(child)
      return
    }
    if (child instanceof GrRect) {
      this._grRects.push(child)
      return
    }
    if (child instanceof Via) {
      this._vias.push(child)
      return
    }
    if (child instanceof Zone) {
      this._zones.push(child)
      return
    }
    if (child instanceof EmbeddedFonts) {
      this._sxEmbeddedFonts = child
      return
    }
    if (child instanceof EmbeddedFiles) {
      this._sxEmbeddedFiles = child
      return
    }

    this._otherChildren.push(child)
  }

  get version(): number | undefined {
    return this._sxVersion?.value
  }

  set version(value: number | undefined) {
    this._sxVersion = value === undefined ? undefined : new PcbVersion(value)
  }

  get generator(): string | undefined {
    return this._sxGenerator?.value
  }

  set generator(value: string | undefined) {
    this._sxGenerator =
      value === undefined ? undefined : new PcbGenerator(value)
  }

  get generatorVersion(): string | undefined {
    return this._sxGeneratorVersion?.value
  }

  set generatorVersion(value: string | undefined) {
    this._sxGeneratorVersion =
      value === undefined ? undefined : new PcbGeneratorVersion(value)
  }

  get general(): PcbGeneral | undefined {
    return this._sxGeneral
  }

  set general(value: PcbGeneral | undefined) {
    this._sxGeneral = value
  }

  get paper(): Paper | undefined {
    return this._sxPaper
  }

  set paper(value: Paper | undefined) {
    this._sxPaper = value
  }

  get titleBlock(): TitleBlock | undefined {
    return this._sxTitleBlock
  }

  set titleBlock(value: TitleBlock | undefined) {
    this._sxTitleBlock = value
  }

  get layers(): PcbLayers | undefined {
    return this._sxLayers
  }

  set layers(value: PcbLayers | undefined) {
    this._sxLayers = value
  }

  get setup(): Setup | undefined {
    return this._sxSetup
  }

  set setup(value: Setup | undefined) {
    this._sxSetup = value
  }

  get properties(): Property[] {
    return [...this._properties]
  }

  set properties(value: Property[]) {
    this._properties = [...value]
  }

  get nets(): PcbNet[] {
    return [...this._nets]
  }

  set nets(value: PcbNet[]) {
    this._nets = [...value]
  }

  get footprints(): Footprint[] {
    return [...this._footprints]
  }

  set footprints(value: Footprint[]) {
    this._footprints = [...value]
  }

  get images(): Image[] {
    return [...this._images]
  }

  set images(value: Image[]) {
    this._images = [...value]
  }

  get segments(): Segment[] {
    return [...this._segments]
  }

  set segments(value: Segment[]) {
    this._segments = [...value]
  }

  get arcs(): PcbArc[] {
    return [...this._arcs]
  }

  set arcs(value: PcbArc[]) {
    this._arcs = [...value]
  }

  get graphicArcs(): GrArc[] {
    return [...this._grArcs]
  }

  set graphicArcs(value: GrArc[]) {
    this._grArcs = [...value]
  }

  get graphicCircles(): GrCircle[] {
    return [...this._grCircles]
  }

  set graphicCircles(value: GrCircle[]) {
    this._grCircles = [...value]
  }

  get graphicCurves(): GrCurve[] {
    return [...this._grCurves]
  }

  set graphicCurves(value: GrCurve[]) {
    this._grCurves = [...value]
  }

  get graphicLines(): GrLine[] {
    return [...this._grLines]
  }

  set graphicLines(value: GrLine[]) {
    this._grLines = [...value]
  }

  get graphicTexts(): GrText[] {
    return [...this._grTexts]
  }

  set graphicTexts(value: GrText[]) {
    this._grTexts = [...value]
  }

  get graphicPolys(): GrPoly[] {
    return [...this._grPolys]
  }

  set graphicPolys(value: GrPoly[]) {
    this._grPolys = [...value]
  }

  get graphicRects(): GrRect[] {
    return [...this._grRects]
  }

  set graphicRects(value: GrRect[]) {
    this._grRects = [...value]
  }

  get vias(): Via[] {
    return [...this._vias]
  }

  set vias(value: Via[]) {
    this._vias = [...value]
  }

  get zones(): Zone[] {
    return [...this._zones]
  }

  set zones(value: Zone[]) {
    this._zones = [...value]
  }

  get embeddedFonts(): EmbeddedFonts | undefined {
    return this._sxEmbeddedFonts
  }

  set embeddedFonts(value: EmbeddedFonts | undefined) {
    this._sxEmbeddedFonts = value
  }

  get embeddedFiles(): EmbeddedFiles | undefined {
    return this._sxEmbeddedFiles
  }

  set embeddedFiles(value: EmbeddedFiles | undefined) {
    this._sxEmbeddedFiles = value
  }

  get otherChildren(): SxClass[] {
    return [...this._otherChildren]
  }

  set otherChildren(value: SxClass[]) {
    this._otherChildren = [...value]
  }

  override getChildren(): SxClass[] {
    const children: SxClass[] = []
    if (this._sxVersion) children.push(this._sxVersion)
    if (this._sxGenerator) children.push(this._sxGenerator)
    if (this._sxGeneratorVersion) children.push(this._sxGeneratorVersion)
    if (this._sxGeneral) children.push(this._sxGeneral)
    if (this._sxPaper) children.push(this._sxPaper)
    if (this._sxTitleBlock) children.push(this._sxTitleBlock)
    if (this._sxLayers) children.push(this._sxLayers)
    if (this._sxSetup) children.push(this._sxSetup)
    children.push(...this._properties)
    children.push(...this._nets)
    children.push(...this._footprints)
    children.push(...this._images)
    children.push(...this._segments)
    children.push(...this._arcs)
    children.push(...this._grArcs)
    children.push(...this._grCircles)
    children.push(...this._grCurves)
    children.push(...this._grLines)
    children.push(...this._grTexts)
    children.push(...this._grPolys)
    children.push(...this._grRects)
    children.push(...this._vias)
    children.push(...this._zones)
    if (this._sxEmbeddedFonts) children.push(this._sxEmbeddedFonts)
    if (this._sxEmbeddedFiles) children.push(this._sxEmbeddedFiles)
    children.push(...this._otherChildren)
    return children
  }
}
SxClass.register(KicadPcb)
