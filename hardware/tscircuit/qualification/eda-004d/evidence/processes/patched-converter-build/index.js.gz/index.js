// lib/schematic/CircuitJsonToKicadSchConverter.ts
import { cju } from "@tscircuit/circuit-json-util";
import { KicadSch } from "kicadts";
import { compose as compose2, scale, translate as translate2 } from "transformation-matrix";

// lib/schematic/buildChildSheetNodes.ts
import {
  At,
  Color,
  Sheet,
  SheetFill,
  SheetInstancePage,
  SheetInstancePath,
  SheetInstancesForSheet,
  SheetInstancesProject,
  SheetProperty,
  SheetSize,
  Stroke,
  TextEffects,
  TextEffectsFont,
  TextEffectsJustify
} from "kicadts";
var BOX_WIDTH = 40;
var BOX_HEIGHT = 25;
var GUTTER_X = 20;
var GUTTER_Y = 30;
var MARGIN = 25.4;
var PROPERTY_FONT_SIZE = 1.524;
var SHEET_BORDER_WIDTH = 0.1524;
function createSheetPropertyEffects(vertical) {
  const font = new TextEffectsFont();
  font.size = { height: PROPERTY_FONT_SIZE, width: PROPERTY_FONT_SIZE };
  return new TextEffects({
    font,
    justify: new TextEffectsJustify({ horizontal: "left", vertical })
  });
}
function buildSheetNode(entry, rootUuid, x, y, width, height) {
  const stroke = new Stroke();
  stroke.width = SHEET_BORDER_WIDTH;
  stroke.type = "solid";
  const fill = new SheetFill();
  fill.color = new Color([0, 0, 0, 0]);
  const sheetnameProperty = new SheetProperty({
    key: "Sheetname",
    value: entry.sheetName,
    id: 0,
    at: At.from([x, y - 0.7, 0]),
    effects: createSheetPropertyEffects("bottom")
  });
  const sheetfileProperty = new SheetProperty({
    key: "Sheetfile",
    value: entry.filename,
    id: 1,
    at: At.from([x, y + height + 0.7, 0]),
    effects: createSheetPropertyEffects("top")
  });
  const instancePath = new SheetInstancePath(`/${rootUuid}`);
  instancePath.pages = [new SheetInstancePage(entry.pageNumber)];
  const instancesProject = new SheetInstancesProject("");
  instancesProject.paths = [instancePath];
  const instances = new SheetInstancesForSheet();
  instances.projects = [instancesProject];
  return new Sheet({
    position: [x, y],
    size: new SheetSize(width, height),
    excludeFromSim: false,
    inBom: true,
    onBoard: true,
    dnp: false,
    fieldsAutoplaced: true,
    stroke,
    fill,
    uuid: entry.sheetNodeUuid,
    properties: [sheetnameProperty, sheetfileProperty],
    // No pins: cross-sheet connectivity is carried by global labels.
    instances
  });
}
function buildChildSheetNodes(children, rootUuid, schematicSheetOptions = []) {
  const count = children.length;
  const cols = Math.max(1, Math.ceil(Math.sqrt(count)));
  const rows = Math.max(1, Math.ceil(count / cols));
  const nodes = [];
  let maximumRight = 0;
  let maximumBottom = 0;
  for (let index = 0; index < children.length; index++) {
    const col = index % cols;
    const row = Math.floor(index / cols);
    const child = children[index];
    const hierarchyNode = schematicSheetOptions.find(
      (sheetOptions) => sheetOptions.schematicSheetId === child.schematicSheetId
    )?.hierarchyNode;
    const x = hierarchyNode?.position.x ?? MARGIN + col * (BOX_WIDTH + GUTTER_X);
    const y = hierarchyNode?.position.y ?? MARGIN + row * (BOX_HEIGHT + GUTTER_Y);
    const width = hierarchyNode?.size.width ?? BOX_WIDTH;
    const height = hierarchyNode?.size.height ?? BOX_HEIGHT;
    nodes.push(buildSheetNode(child, rootUuid, x, y, width, height));
    maximumRight = Math.max(maximumRight, x + width);
    maximumBottom = Math.max(maximumBottom, y + height);
  }
  return {
    nodes,
    extentMm: {
      width: maximumRight + MARGIN,
      height: maximumBottom + MARGIN
    }
  };
}

// lib/schematic/buildSchematicSheetPlan.ts
var DEFAULT_ROOT_FILENAME = "schematic.kicad_sch";
function toFileBaseName(sheetName, fallbackIndex) {
  const baseName = sheetName.trim().toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
  return baseName.length > 0 ? baseName : `sheet_${fallbackIndex + 1}`;
}
function buildSchematicSheetPlan(circuitJson) {
  const rootUuid = crypto.randomUUID();
  const root = {
    schematicSheetId: null,
    sheetName: "Root",
    fileBaseName: "root",
    filename: DEFAULT_ROOT_FILENAME,
    pageNumber: "1",
    fileUuid: rootUuid
  };
  const schematicSheets = circuitJson.filter((el) => el.type === "schematic_sheet").slice().sort((a, b) => (a.sheet_index ?? 0) - (b.sheet_index ?? 0));
  const usedFileBaseNames = /* @__PURE__ */ new Set(["root"]);
  const children = [];
  for (let index = 0; index < schematicSheets.length; index++) {
    const sheet = schematicSheets[index];
    const sheetName = sheet.display_name ?? sheet.name ?? `Sheet ${index + 1}`;
    let fileBaseName = toFileBaseName(sheet.name ?? sheetName, index);
    if (usedFileBaseNames.has(fileBaseName)) {
      let suffix = 2;
      while (usedFileBaseNames.has(`${fileBaseName}_${suffix}`)) suffix++;
      fileBaseName = `${fileBaseName}_${suffix}`;
    }
    usedFileBaseNames.add(fileBaseName);
    children.push({
      schematicSheetId: sheet.schematic_sheet_id,
      sheetName,
      fileBaseName,
      filename: `${fileBaseName}.kicad_sch`,
      pageNumber: `${index + 2}`,
      sheetNodeUuid: crypto.randomUUID(),
      fileUuid: crypto.randomUUID()
    });
  }
  return {
    rootUuid,
    root,
    children,
    isHierarchical: children.length > 0
  };
}

// lib/schematic/createKicadSchematicTitleBlock.ts
import { TitleBlock, TitleBlockComment } from "kicadts";
function createKicadSchematicTitleBlock(metadata) {
  if (!metadata) return void 0;
  return new TitleBlock({
    company: metadata.company,
    comments: metadata.comments?.map(
      ({ index, text }) => new TitleBlockComment(index, text)
    ),
    date: metadata.date,
    rev: metadata.revision,
    title: metadata.title
  });
}

// lib/schematic/stages/utils/hasComponentLevelSymbolPrimitives.ts
var componentPrimitiveTypes = /* @__PURE__ */ new Set([
  "schematic_path",
  "schematic_circle",
  "schematic_arc",
  "schematic_line",
  "schematic_rect"
]);
function hasComponentLevelSymbolPrimitives(circuitJson, schematicComponent) {
  const schematicComponentId = schematicComponent.schematic_component_id;
  if (schematicComponent.is_box_with_pins !== false || schematicComponent.symbol_name || "schematic_symbol_id" in schematicComponent || circuitJson.some(
    (element) => element.schematic_component_id === schematicComponentId && element.schematic_symbol_id
  )) {
    return false;
  }
  return circuitJson.some(
    (element) => componentPrimitiveTypes.has(element.type) && element.schematic_component_id === schematicComponentId && !element.schematic_symbol_id
  );
}

// lib/schematic/getSchematicBoundsAndCenter.ts
function getSchematicBoundsAndCenter(db, {
  useComponentLevelSourceGeometry = false
} = {}) {
  const circuitJson = db.toArray();
  const schematicComponents = db.schematic_component.list();
  const schematicTraces = db.schematic_trace.list();
  const schematicArcs = db.schematic_arc.list();
  const sourceGeometryComponentIds = new Set(
    schematicComponents.filter(
      (component) => hasComponentLevelSymbolPrimitives(circuitJson, component)
    ).map((component) => component.schematic_component_id)
  );
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  const includePoint = (point) => {
    minX = Math.min(minX, point.x);
    minY = Math.min(minY, point.y);
    maxX = Math.max(maxX, point.x);
    maxY = Math.max(maxY, point.y);
  };
  for (const component of schematicComponents) {
    if (useComponentLevelSourceGeometry && sourceGeometryComponentIds.has(component.schematic_component_id)) {
      continue;
    }
    const width = component.size?.width ?? 0;
    const height = component.size?.height ?? 0;
    includePoint({
      x: component.center.x - width / 2,
      y: component.center.y - height / 2
    });
    includePoint({
      x: component.center.x + width / 2,
      y: component.center.y + height / 2
    });
  }
  for (const trace of schematicTraces) {
    for (const edge of trace.edges) {
      includePoint(edge.from);
      includePoint(edge.to);
    }
  }
  for (const arc of schematicArcs) {
    includePoint({ x: arc.center.x - arc.radius, y: arc.center.y - arc.radius });
    includePoint({ x: arc.center.x + arc.radius, y: arc.center.y + arc.radius });
  }
  if (useComponentLevelSourceGeometry) {
    for (const line of db.schematic_line.list()) {
      if (!line.schematic_component_id || !sourceGeometryComponentIds.has(line.schematic_component_id)) {
        continue;
      }
      includePoint({ x: line.x1, y: line.y1 });
      includePoint({ x: line.x2, y: line.y2 });
    }
    for (const path of db.schematic_path.list()) {
      if (!path.schematic_component_id || !sourceGeometryComponentIds.has(path.schematic_component_id)) {
        continue;
      }
      for (const point of path.points) includePoint(point);
    }
    for (const rect of db.schematic_rect.list()) {
      if (!rect.schematic_component_id || !sourceGeometryComponentIds.has(rect.schematic_component_id)) {
        continue;
      }
      const halfWidth = rect.width / 2;
      const halfHeight = rect.height / 2;
      const rotationRadians = rect.rotation * Math.PI / 180;
      const cos = Math.cos(rotationRadians);
      const sin = Math.sin(rotationRadians);
      for (const corner of [
        { x: -halfWidth, y: -halfHeight },
        { x: halfWidth, y: -halfHeight },
        { x: halfWidth, y: halfHeight },
        { x: -halfWidth, y: halfHeight }
      ]) {
        includePoint({
          x: rect.center.x + corner.x * cos - corner.y * sin,
          y: rect.center.y + corner.x * sin + corner.y * cos
        });
      }
    }
    for (const circle of db.schematic_circle.list()) {
      if (!circle.schematic_component_id || !sourceGeometryComponentIds.has(circle.schematic_component_id)) {
        continue;
      }
      includePoint({
        x: circle.center.x - circle.radius,
        y: circle.center.y - circle.radius
      });
      includePoint({
        x: circle.center.x + circle.radius,
        y: circle.center.y + circle.radius
      });
    }
  }
  if (minX === Infinity) {
    minX = 0;
    minY = 0;
    maxX = 0;
    maxY = 0;
  }
  const centerX = (minX + maxX) / 2;
  const centerY = (minY + maxY) / 2;
  return {
    hasComponentLevelSourceGeometry: sourceGeometryComponentIds.size > 0,
    center: {
      x: centerX,
      y: centerY
    },
    bounds: {
      minX,
      minY,
      maxX,
      maxY
    }
  };
}

// lib/schematic/selectSchematicPaperSize.ts
var PAPER_SIZES = [
  { name: "A4", width: 297, height: 210 },
  { name: "A3", width: 420, height: 297 },
  { name: "A2", width: 594, height: 420 },
  { name: "A1", width: 841, height: 594 },
  { name: "A0", width: 1189, height: 841 }
];
function selectSchematicPaperSize(contentWidth, contentHeight, paddingMm = 20) {
  const requiredWidth = contentWidth + 2 * paddingMm;
  const requiredHeight = contentHeight + 2 * paddingMm;
  for (let i = 0; i < PAPER_SIZES.length; i++) {
    const paperSize = PAPER_SIZES[i];
    if (requiredWidth <= paperSize.width && requiredHeight <= paperSize.height) {
      return paperSize;
    }
  }
  return PAPER_SIZES[PAPER_SIZES.length - 1];
}

// lib/schematic/getSchematicPageLayout.ts
var DEFAULT_CONTENT_MARGIN_MM = 20;
var KICAD_TITLE_BLOCK_HEIGHT_MM = 44;
var TITLE_BLOCK_CLEARANCE_MM = 5;
function getSchematicPageLayout({
  contentWidthMm,
  contentHeightMm,
  extraPaperExtentMm
}) {
  const requiredWidthMm = Math.max(
    contentWidthMm + 2 * DEFAULT_CONTENT_MARGIN_MM,
    extraPaperExtentMm?.width ?? 0
  );
  const requiredHeightMm = Math.max(
    contentHeightMm + DEFAULT_CONTENT_MARGIN_MM + KICAD_TITLE_BLOCK_HEIGHT_MM + TITLE_BLOCK_CLEARANCE_MM,
    extraPaperExtentMm?.height ?? 0
  );
  const paperSize = selectSchematicPaperSize(
    requiredWidthMm,
    requiredHeightMm,
    0
  );
  const centeredY = paperSize.height / 2;
  const lowestSafeCenterY = paperSize.height - KICAD_TITLE_BLOCK_HEIGHT_MM - TITLE_BLOCK_CLEARANCE_MM - contentHeightMm / 2;
  return {
    paperSize,
    contentCenter: {
      x: paperSize.width / 2,
      y: Math.min(centeredY, lowestSafeCenterY)
    }
  };
}

// lib/schematic/partitionCircuitJsonBySheet.ts
function isSchematicElement(el) {
  return typeof el.type === "string" && el.type.startsWith("schematic_");
}
function keepElementForSheet(el, sheetId, componentIdsOnSheet) {
  if (!isSchematicElement(el)) return true;
  if (el.type === "schematic_sheet") return false;
  if (el.type === "schematic_symbol") return true;
  if ((el.schematic_sheet_id ?? null) === sheetId) return true;
  return el.schematic_component_id != null && componentIdsOnSheet.has(el.schematic_component_id);
}
function partitionCircuitJsonBySheet(circuitJson, sheetId) {
  const elements = circuitJson;
  const componentIdsOnSheet = /* @__PURE__ */ new Set();
  for (const el of elements) {
    if (el.type !== "schematic_component") continue;
    if ((el.schematic_sheet_id ?? null) === sheetId) {
      componentIdsOnSheet.add(el.schematic_component_id);
    }
  }
  const subset = [];
  for (const el of elements) {
    if (keepElementForSheet(el, sheetId, componentIdsOnSheet)) {
      subset.push(el);
    }
  }
  return subset;
}

// lib/schematic/stages/AddLibrarySymbolsStage.ts
import {
  EmbeddedFonts,
  LibSymbols,
  SchematicSymbol as SchematicSymbol4,
  SymbolPinNames,
  SymbolPinNumbers
} from "kicadts";
import { symbols as symbols3 } from "schematic-symbols";

// lib/types.ts
var ConverterStage = class {
  MAX_ITERATIONS = 1e3;
  iteration = 0;
  finished = false;
  input;
  ctx;
  constructor(input, ctx) {
    this.input = input;
    this.ctx = ctx;
  }
  step() {
    this.iteration++;
    if (this.iteration > this.MAX_ITERATIONS) {
      throw new Error("Max iterations reached");
    }
    this._step();
  }
  _step() {
    throw new Error("Not implemented");
  }
  runUntilFinished() {
    while (!this.finished) {
      this.step();
    }
  }
  getOutput() {
    throw new Error("Not implemented");
  }
};

// lib/utils/getKicadCompatibleComponentName.ts
function getKicadCompatibleComponentName(sourceComponent, cadComponent) {
  if (sourceComponent.manufacturer_part_number) {
    return sanitizeName(sourceComponent.manufacturer_part_number);
  }
  const cleanType = getCleanTypeName(sourceComponent.ftype);
  const footprinterString = cadComponent?.footprinter_string;
  if (footprinterString) {
    return sanitizeName(`${cleanType}_${footprinterString}`);
  }
  return sanitizeName(cleanType);
}
function getKicadCompatibleCustomSymbolName(sourceComponent, cadComponent, schematicSymbolId) {
  if (sourceComponent.manufacturer_part_number || cadComponent?.footprinter_string) {
    return getKicadCompatibleComponentName(sourceComponent, cadComponent);
  }
  return sanitizeName(
    `custom_${getCleanTypeName(sourceComponent.ftype)}_${schematicSymbolId}`
  );
}
function getCleanTypeName(ftype) {
  if (!ftype) return "component";
  let cleanName = ftype.replace(/^simple_/, "");
  if (!cleanName) return "component";
  return cleanName;
}
function sanitizeName(name) {
  return name.replace(/[^A-Za-z0-9_-]+/g, "_").replace(/_+/g, "_").replace(/^_|_$/g, "").trim() || "component";
}
function extractReferencePrefix(name) {
  if (!name) return "U";
  const match = name.match(/^([A-Za-z]+)/);
  return match?.[1]?.toUpperCase() ?? "U";
}
var referencePrefixByFtype = {
  simple_resistor: "R",
  simple_capacitor: "C",
  simple_inductor: "L",
  simple_diode: "D",
  simple_led: "D",
  simple_chip: "U",
  simple_transistor: "Q",
  simple_mosfet: "Q",
  simple_fuse: "F",
  simple_switch: "SW",
  simple_push_button: "SW",
  simple_potentiometer: "RV",
  simple_crystal: "Y",
  simple_resonator: "Y",
  simple_pin_header: "J",
  simple_pinout: "J",
  simple_test_point: "TP",
  simple_battery: "BT"
};
var referenceDesignatorPattern = /^[A-Za-z]+\d+$/;
function isReferenceDesignator(value) {
  if (!value) return false;
  return referenceDesignatorPattern.test(value.trim());
}
function getReferencePrefixForComponent(sourceComponent) {
  const ftype = sourceComponent?.ftype;
  if (ftype && referencePrefixByFtype[ftype]) {
    return referencePrefixByFtype[ftype];
  }
  const name = sourceComponent?.name;
  if (isReferenceDesignator(name)) {
    return extractReferencePrefix(name);
  }
  return extractReferencePrefix(name);
}
function getReferenceDesignator(sourceComponent) {
  const name = sourceComponent?.name;
  const trimmedName = name?.trim();
  if (trimmedName) {
    return trimmedName;
  }
  const prefix = getReferencePrefixForComponent(sourceComponent);
  return `${prefix}?`;
}

// lib/schematic/getSchematicSymbolData.ts
import { symbols } from "schematic-symbols";
var legacySymbolNameByOrientedSymbolName = {
  n_channel_e_mosfet_transistor_gate_left_drain_top: "n_channel_e_mosfet_transistor_horz",
  n_channel_e_mosfet_transistor_gate_top_drain_right: "n_channel_e_mosfet_transistor_vert",
  n_channel_d_mosfet_transistor_gate_left_drain_top: "n_channel_d_mosfet_transistor_horz",
  n_channel_d_mosfet_transistor_gate_top_drain_right: "n_channel_d_mosfet_transistor_vert",
  p_channel_e_mosfet_transistor_gate_left_drain_top: "p_channel_e_mosfet_transistor_horz",
  p_channel_e_mosfet_transistor_gate_top_drain_right: "p_channel_e_mosfet_transistor_vert",
  p_channel_d_mosfet_transistor_gate_left_drain_top: "p_channel_d_mosfet_transistor_horz",
  p_channel_d_mosfet_transistor_gate_top_drain_right: "p_channel_d_mosfet_transistor_vert"
};
var getSchematicSymbolData = (symbolName) => {
  const resolvedSymbolName = legacySymbolNameByOrientedSymbolName[symbolName] ?? symbolName;
  return symbols[resolvedSymbolName];
};

// lib/schematic/getLibraryId.ts
import { symbols as symbols2 } from "schematic-symbols";
function isBuiltinSymbol(symbolName) {
  return symbolName in symbols2;
}
function sanitizeLibraryIdentifierPart(value) {
  return value.replace(/[^A-Za-z0-9_-]+/g, "_").replace(/_+/g, "_").replace(/^_|_$/g, "") || "connector";
}
function getBaseLibraryId(sourceComp, schematicComp, cadComponent, schematicSymbolName) {
  if (schematicSymbolName) {
    return `Custom:${schematicSymbolName}`;
  }
  if (sourceComp.type !== "source_component") {
    if (schematicComp.symbol_name) {
      if (isBuiltinSymbol(schematicComp.symbol_name)) {
        return `Device:${schematicComp.symbol_name}`;
      }
      return `Custom:${schematicComp.symbol_name}`;
    }
    return "Device:Component";
  }
  if (schematicComp.symbol_name) {
    if (isBuiltinSymbol(schematicComp.symbol_name)) {
      return `Device:${schematicComp.symbol_name}`;
    }
    return `Custom:${schematicComp.symbol_name}`;
  }
  if (sourceComp.ftype === "simple_pin_header") {
    const pinCount = sourceComp.pin_count;
    const instanceName = sanitizeLibraryIdentifierPart(
      sourceComp.name ?? schematicComp.schematic_component_id
    );
    return `Connector_Generic:Conn_01x${pinCount}_${instanceName}`;
  }
  const ergonomicName = getKicadCompatibleComponentName(
    sourceComp,
    cadComponent
  );
  const refPrefix = getReferencePrefixForComponent(sourceComp);
  return `Device:${refPrefix}_${ergonomicName}`;
}
function getLibraryId(sourceComp, schematicComp, cadComponent, schematicSymbolName) {
  const identity8 = Array.from(sourceComp.source_component_id).map((character) => character.codePointAt(0).toString(16)).join("_");
  return `${getBaseLibraryId(sourceComp, schematicComp, cadComponent, schematicSymbolName)}_${identity8}`;
}
function getComponentLevelLibraryId(sourceComp, schematicComp, cadComponent) {
  return `${getLibraryId(sourceComp, schematicComp, cadComponent)}_${sanitizeLibraryIdentifierPart(schematicComp.schematic_component_id)}`;
}

// lib/schematic/resolveSchematicComponentSymbol.ts
function isSchematicSymbolPrimitive(element) {
  return element.type === "schematic_arc" || element.type === "schematic_circle" || element.type === "schematic_line" || element.type === "schematic_path" || element.type === "schematic_rect";
}
function findLinkedSchematicSymbolId(circuitJson, schematicComponentId) {
  return circuitJson.find(
    (element) => isSchematicSymbolPrimitive(element) && element.schematic_component_id === schematicComponentId && Boolean(element.schematic_symbol_id)
  )?.schematic_symbol_id;
}
function resolveSchematicComponentSymbol({
  circuitJson,
  schematicComponent,
  sourceComponent,
  cadComponents
}) {
  const cadComponent = cadComponents.find(
    (candidate) => candidate.source_component_id === sourceComponent.source_component_id
  );
  const linkedSchematicSymbolId = findLinkedSchematicSymbolId(
    circuitJson,
    schematicComponent.schematic_component_id
  );
  const schematicSymbolId = schematicComponent.schematic_symbol_id || linkedSchematicSymbolId;
  const schematicSymbol = schematicSymbolId ? circuitJson.find(
    (element) => element.type === "schematic_symbol" && element.schematic_symbol_id === schematicSymbolId
  ) : void 0;
  const schematicSymbolName = schematicSymbolId ? schematicSymbol?.name ?? getKicadCompatibleCustomSymbolName(
    sourceComponent,
    cadComponent,
    schematicSymbolId
  ) : void 0;
  const usesComponentLevelSymbolPrimitives = hasComponentLevelSymbolPrimitives(
    circuitJson,
    schematicComponent
  );
  const libraryId = usesComponentLevelSymbolPrimitives ? getComponentLevelLibraryId(
    sourceComponent,
    schematicComponent,
    cadComponent
  ) : getLibraryId(
    sourceComponent,
    schematicComponent,
    cadComponent,
    schematicSymbolName
  );
  const isChip = sourceComponent.ftype === "simple_chip" || sourceComponent.ftype === "simple_pin_header" || sourceComponent.ftype === "simple_connector";
  return {
    cadComponent,
    schematicSymbol,
    schematicSymbolId,
    schematicSymbolName,
    hasLinkedSymbolPrimitives: Boolean(linkedSchematicSymbolId),
    usesComponentLevelSymbolPrimitives,
    libraryId,
    isChip
  };
}

// lib/schematic/getSchematicArcPoints.ts
var normalizePositiveDegrees = (degrees) => (degrees % 360 + 360) % 360;
var getDirectedSweepDegrees = ({
  startAngleDegrees,
  endAngleDegrees,
  direction
}) => {
  if (direction === "clockwise") {
    const sweep2 = normalizePositiveDegrees(startAngleDegrees - endAngleDegrees);
    return sweep2 === 0 && startAngleDegrees !== endAngleDegrees ? -360 : -sweep2;
  }
  const sweep = normalizePositiveDegrees(endAngleDegrees - startAngleDegrees);
  return sweep === 0 && startAngleDegrees !== endAngleDegrees ? 360 : sweep;
};
var getPointAtAngle = (arc, angleDegrees) => {
  const angleRadians = angleDegrees * Math.PI / 180;
  return {
    x: arc.center.x + arc.radius * Math.cos(angleRadians),
    y: arc.center.y + arc.radius * Math.sin(angleRadians)
  };
};
var getSchematicArcPoints = (arc) => {
  const sweepDegrees = getDirectedSweepDegrees({
    startAngleDegrees: arc.start_angle_degrees,
    endAngleDegrees: arc.end_angle_degrees,
    direction: arc.direction
  });
  const midAngleDegrees = arc.start_angle_degrees + sweepDegrees / 2;
  return {
    start: getPointAtAngle(arc, arc.start_angle_degrees),
    mid: getPointAtAngle(arc, midAngleDegrees),
    end: getPointAtAngle(arc, arc.start_angle_degrees + sweepDegrees)
  };
};

// lib/schematic/stages/symbols-stage-converters/buildSymbolDataFromSchematicPrimitives.ts
function buildSymbolDataFromSchematicPrimitives(params) {
  const {
    circuitJson,
    schematicSymbolId,
    schematicSymbol,
    schematicComponentId,
    schematicComponentCenter,
    schematicComponentSize
  } = params;
  const hasSchematicSymbolId = Boolean(schematicSymbolId);
  const isElementInTargetSymbolScope = (el) => {
    if (hasSchematicSymbolId) {
      return el.schematic_symbol_id === schematicSymbolId;
    }
    return el.schematic_component_id === schematicComponentId && !el.schematic_symbol_id;
  };
  const arcs = circuitJson.filter(
    (el) => el.type === "schematic_arc" && isElementInTargetSymbolScope(el)
  );
  const circles = circuitJson.filter(
    (el) => el.type === "schematic_circle" && isElementInTargetSymbolScope(el)
  );
  const symbolLines = circuitJson.filter(
    (el) => el.type === "schematic_line" && isElementInTargetSymbolScope(el)
  );
  let schLines = [];
  if (hasSchematicSymbolId && schematicComponentId) {
    schLines = circuitJson.filter(
      (el) => el.type === "schematic_line" && el.schematic_component_id === schematicComponentId && !el.schematic_symbol_id
    );
  }
  const lines = [...symbolLines, ...schLines];
  const paths = circuitJson.filter(
    (el) => el.type === "schematic_path" && isElementInTargetSymbolScope(el)
  );
  const rectangles = circuitJson.filter(
    (el) => el.type === "schematic_rect" && isElementInTargetSymbolScope(el)
  );
  const texts = circuitJson.filter(
    (el) => el.type === "schematic_text" && isElementInTargetSymbolScope(el)
  );
  let ports = [];
  if (hasSchematicSymbolId) {
    ports = circuitJson.filter(
      (el) => el.type === "schematic_port" && "schematic_symbol_id" in el && el.schematic_symbol_id === schematicSymbolId
    );
  }
  if (ports.length === 0 && schematicComponentId) {
    const labeledPorts = circuitJson.filter(
      (el) => el.type === "schematic_port" && el.schematic_component_id === schematicComponentId && el.display_pin_label !== void 0
    );
    const labelMap = /* @__PURE__ */ new Map();
    for (const port of labeledPorts) {
      if (port.display_pin_label) {
        labelMap.set(port.display_pin_label, port);
      }
    }
    ports = labeledPorts;
    if (labelMap.size > 0) {
      ports = Array.from(labelMap.values());
    }
    if (ports.length === 0) {
      const allPorts = circuitJson.filter(
        (el) => el.type === "schematic_port" && el.schematic_component_id === schematicComponentId
      );
      const seenPinNumbers = /* @__PURE__ */ new Set();
      ports = allPorts.filter((port) => {
        const pinNum = port.pin_number;
        if (pinNum !== void 0) {
          if (seenPinNumbers.has(pinNum)) {
            return false;
          }
          seenPinNumbers.add(pinNum);
        }
        return true;
      });
    }
  }
  const primitives = [];
  for (const arc of arcs) {
    primitives.push({
      type: "arc",
      ...getSchematicArcPoints(arc),
      isDashed: arc.is_dashed,
      strokeWidth: arc.stroke_width
    });
  }
  for (const circle of circles) {
    primitives.push({
      type: "circle",
      x: circle.center?.x ?? 0,
      y: circle.center?.y ?? 0,
      radius: circle.radius ?? 0.5,
      fill: circle.is_filled ?? false,
      fillColor: circle.fill_color,
      strokeWidth: circle.stroke_width
    });
  }
  for (const line of lines) {
    primitives.push({
      type: "path",
      points: [
        { x: line.x1 ?? 0, y: line.y1 ?? 0 },
        { x: line.x2 ?? 0, y: line.y2 ?? 0 }
      ],
      strokeWidth: line.stroke_width
    });
  }
  for (const path of paths) {
    if (path.points && path.points.length > 0) {
      primitives.push({
        type: "path",
        points: path.points,
        fill: path.is_filled ?? false,
        fillColor: path.fill_color,
        strokeWidth: path.stroke_width
      });
    }
  }
  for (const rect of rectangles) {
    const halfWidth = rect.width / 2;
    const halfHeight = rect.height / 2;
    if ((rect.rotation ?? 0) % 360 === 0) {
      primitives.push({
        type: "rectangle",
        start: { x: rect.center.x - halfWidth, y: rect.center.y - halfHeight },
        end: { x: rect.center.x + halfWidth, y: rect.center.y + halfHeight },
        fill: rect.is_filled,
        fillColor: rect.fill_color,
        strokeWidth: rect.stroke_width,
        isDashed: rect.is_dashed
      });
      continue;
    }
    const rotationRadians = rect.rotation * Math.PI / 180;
    const cos = Math.cos(rotationRadians);
    const sin = Math.sin(rotationRadians);
    const corners = [
      { x: -halfWidth, y: -halfHeight },
      { x: halfWidth, y: -halfHeight },
      { x: halfWidth, y: halfHeight },
      { x: -halfWidth, y: halfHeight }
    ].map((corner) => ({
      x: rect.center.x + corner.x * cos - corner.y * sin,
      y: rect.center.y + corner.x * sin + corner.y * cos
    }));
    primitives.push({
      type: "path",
      points: [...corners, corners[0]],
      fill: rect.is_filled,
      fillColor: rect.fill_color,
      strokeWidth: rect.stroke_width,
      isDashed: rect.is_dashed
    });
  }
  const symbolTexts = texts.map((text) => ({
    text: text.text ?? "",
    x: text.position?.x ?? 0,
    y: text.position?.y ?? 0,
    fontSize: text.font_size ?? 0.2,
    anchor: text.anchor ?? "center"
  }));
  const symbolPorts = ports.map((port, index) => ({
    x: port.center?.x ?? 0,
    y: port.center?.y ?? 0,
    labels: [port.display_pin_label || `${port.pin_number || index + 1}`],
    pinNumber: port.pin_number || index + 1,
    facingDirection: port.facing_direction
  }));
  symbolPorts.sort((a, b) => a.pinNumber - b.pinNumber);
  const symbolCenter = schematicSymbol.center || schematicComponentCenter || { x: 0, y: 0 };
  return {
    center: symbolCenter,
    size: schematicSymbol.size || schematicComponentSize || { width: 1, height: 1 },
    primitives,
    texts: symbolTexts,
    ports: symbolPorts
  };
}

// lib/schematic/stages/symbols-stage-converters/createDrawingSubsymbol.ts
import { SchematicSymbol } from "kicadts";
import {
  compose,
  scale as createScaleMatrix,
  translate
} from "transformation-matrix";

// lib/schematic/stages/symbols-stage-converters/createArcFromPrimitive.ts
import { SymbolArc } from "kicadts";
import { applyToPoint } from "transformation-matrix";
function createArcFromPrimitive({
  primitive,
  transform,
  scale: scale6
}) {
  const start = applyToPoint(transform, primitive.start);
  const mid = applyToPoint(transform, primitive.mid);
  const end = applyToPoint(transform, primitive.end);
  return SymbolArc.fromSexprPrimitives([
    ["start", start.x, start.y],
    ["mid", mid.x, mid.y],
    ["end", end.x, end.y],
    [
      "stroke",
      [
        "width",
        primitive.strokeWidth == null ? 0.254 : primitive.strokeWidth * scale6
      ],
      ["type", primitive.isDashed ? "dash" : "default"]
    ],
    ["fill", ["type", "none"]]
  ]);
}

// lib/schematic/stages/symbols-stage-converters/createCircleFromPrimitive.ts
import { SymbolCircle } from "kicadts";
import { applyToPoint as applyToPoint2 } from "transformation-matrix";

// lib/schematic/stages/utils/parseColor.ts
function parseColor(color) {
  const rgbMatch = color.match(
    /^rgba?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)(?:\s*,\s*(\d+(?:\.\d+)?))?\s*\)$/i
  );
  if (rgbMatch) {
    return {
      r: Number(rgbMatch[1]),
      g: Number(rgbMatch[2]),
      b: Number(rgbMatch[3]),
      a: rgbMatch[4] === void 0 ? 1 : Number(rgbMatch[4])
    };
  }
  const hexDigits = color.startsWith("#") ? color.slice(1) : color;
  if (![3, 4, 6, 8].includes(hexDigits.length)) return void 0;
  if (!/^[0-9a-f]+$/i.test(hexDigits)) return void 0;
  const expandedHexDigits = hexDigits.length <= 4 ? [...hexDigits].map((digit) => `${digit}${digit}`).join("") : hexDigits;
  return {
    r: Number.parseInt(expandedHexDigits.slice(0, 2), 16),
    g: Number.parseInt(expandedHexDigits.slice(2, 4), 16),
    b: Number.parseInt(expandedHexDigits.slice(4, 6), 16),
    a: expandedHexDigits.length === 8 ? Number.parseInt(expandedHexDigits.slice(6, 8), 16) / 255 : 1
  };
}

// lib/schematic/stages/symbols-stage-converters/createSymbolFillSexprPrimitives.ts
function createSymbolFillSexprPrimitives({
  isFilled,
  fillColor,
  fallbackFillType = "background"
}) {
  if (!isFilled) return [["type", "none"]];
  const parsedFillColor = fillColor ? parseColor(fillColor) : void 0;
  if (!parsedFillColor) return [["type", fallbackFillType]];
  return [
    ["type", "color"],
    [
      "color",
      parsedFillColor.r,
      parsedFillColor.g,
      parsedFillColor.b,
      parsedFillColor.a
    ]
  ];
}

// lib/schematic/stages/symbols-stage-converters/createCircleFromPrimitive.ts
function createCircleFromPrimitive({
  primitive,
  transform,
  scale: scale6
}) {
  const scaledPos = applyToPoint2(transform, {
    x: primitive.x,
    y: primitive.y
  });
  return SymbolCircle.fromSexprPrimitives([
    ["center", scaledPos.x, scaledPos.y],
    ["radius", primitive.radius * scale6],
    [
      "stroke",
      [
        "width",
        primitive.strokeWidth == null ? 0.254 : primitive.strokeWidth * scale6
      ],
      ["type", "default"]
    ],
    [
      "fill",
      ...createSymbolFillSexprPrimitives({
        isFilled: primitive.fill ?? false,
        fillColor: primitive.fillColor,
        fallbackFillType: primitive.kicadFillType === "outline" ? "outline" : "background"
      })
    ]
  ]);
}

// lib/schematic/stages/symbols-stage-converters/createPolylineFromPoints.ts
import { Pts, Stroke as Stroke2, SymbolPolyline, SymbolPolylineFill, Xy } from "kicadts";
import { applyToPoint as applyToPoint3 } from "transformation-matrix";
function createPolylineFromPoints({
  points,
  transform,
  isFilled,
  fillColor,
  fallbackFillType,
  strokeWidth,
  isDashed,
  scale: scale6
}) {
  const polyline = new SymbolPolyline();
  const xyPoints = points.map((p) => {
    const transformed = applyToPoint3(transform, p);
    return new Xy(transformed.x, transformed.y);
  });
  const pts = new Pts(xyPoints);
  polyline.points = pts;
  const stroke = new Stroke2();
  stroke.width = strokeWidth == null ? 0.254 : strokeWidth * scale6;
  stroke.type = isDashed ? "dash" : "default";
  polyline.stroke = stroke;
  const fill = SymbolPolylineFill.fromSexprPrimitives(
    createSymbolFillSexprPrimitives({
      isFilled,
      fillColor,
      fallbackFillType
    })
  );
  polyline.fill = fill;
  return polyline;
}

// lib/schematic/stages/symbols-stage-converters/createRectangleFromPrimitive.ts
import { SymbolRectangle } from "kicadts";
import { applyToPoint as applyToPoint4 } from "transformation-matrix";
function createRectangleFromPrimitive({
  primitive,
  transform,
  scale: scale6
}) {
  const start = applyToPoint4(transform, primitive.start);
  const end = applyToPoint4(transform, primitive.end);
  return SymbolRectangle.fromSexprPrimitives([
    ["start", start.x, start.y],
    ["end", end.x, end.y],
    [
      "stroke",
      [
        "width",
        primitive.strokeWidth == null ? 0.254 : primitive.strokeWidth * scale6
      ],
      ["type", primitive.isDashed ? "dash" : "default"]
    ],
    [
      "fill",
      ...createSymbolFillSexprPrimitives({
        isFilled: primitive.fill ?? false,
        fillColor: primitive.fillColor
      })
    ]
  ]);
}

// lib/schematic/stages/symbols-stage-converters/createTextFromPrimitive.ts
import { SymbolText, TextEffects as TextEffects2, TextEffectsFont as TextEffectsFont2 } from "kicadts";
import { applyToPoint as applyToPoint5 } from "transformation-matrix";
function createTextFromPrimitive({
  schText,
  transform,
  scale: scale6
}) {
  const symbolText = new SymbolText();
  const scaledPos = applyToPoint5(transform, { x: schText.x, y: schText.y });
  symbolText.value = schText.text;
  symbolText.at = [scaledPos.x, scaledPos.y, 0];
  const scaledFontSize = schText.fontSize * scale6;
  const font = new TextEffectsFont2();
  font.size = { height: scaledFontSize, width: scaledFontSize };
  symbolText.effects = new TextEffects2({ font });
  return symbolText;
}

// lib/schematic/stages/symbols-stage-converters/createDrawingSubsymbol.ts
function createDrawingSubsymbol({
  libId,
  symbolData,
  isChip,
  c2kMatSchScale
}) {
  const drawingSymbol = new SchematicSymbol({
    libraryId: `${libId.split(":")[1]}_0_1`
  });
  const symbolScale = c2kMatSchScale;
  const cx = symbolData.center?.x ?? 0;
  const cy = symbolData.center?.y ?? 0;
  const transform = compose(
    createScaleMatrix(symbolScale, symbolScale),
    translate(-cx, -cy)
  );
  for (const primitive of symbolData.primitives || []) {
    if (primitive.type === "arc") {
      drawingSymbol.arcs.push(
        createArcFromPrimitive({
          primitive,
          transform,
          scale: symbolScale
        })
      );
    } else if (primitive.type === "path" && primitive.points) {
      const polyline = createPolylineFromPoints({
        points: primitive.points,
        transform,
        isFilled: primitive.fill ?? false,
        fillColor: primitive.fillColor,
        fallbackFillType: primitive.kicadFillType === "outline" ? "outline" : "background",
        strokeWidth: primitive.strokeWidth,
        isDashed: primitive.isDashed,
        scale: symbolScale
      });
      drawingSymbol.polylines.push(polyline);
    } else if (primitive.type === "rectangle") {
      drawingSymbol.rectangles.push(
        createRectangleFromPrimitive({
          primitive,
          transform,
          scale: symbolScale
        })
      );
    } else if (primitive.type === "circle") {
      const circle = createCircleFromPrimitive({
        primitive,
        transform,
        scale: symbolScale
      });
      drawingSymbol.circles.push(circle);
    }
  }
  const textsArray = Array.isArray(symbolData.texts) ? symbolData.texts : [];
  for (const schText of textsArray) {
    const symbolText = createTextFromPrimitive({
      schText,
      transform,
      scale: symbolScale
    });
    drawingSymbol.texts.push(symbolText);
  }
  return drawingSymbol;
}

// lib/schematic/stages/symbols-stage-converters/createGenericChipSymbolData.ts
function createGenericChipSymbolData(schematicComp, db) {
  const schematicPorts = db.schematic_port.list().filter(
    (p) => p.schematic_component_id === schematicComp.schematic_component_id
  ).sort(
    (a, b) => (a.pin_number || 0) - (b.pin_number || 0)
  );
  const width = schematicComp.size?.width || 1.5;
  const height = schematicComp.size?.height || 1;
  const boxPath = {
    type: "path",
    fill: true,
    points: [
      { x: -width / 2, y: -height / 2 },
      { x: width / 2, y: -height / 2 },
      { x: width / 2, y: height / 2 },
      { x: -width / 2, y: height / 2 },
      { x: -width / 2, y: -height / 2 }
    ]
  };
  const ports = schematicPorts.map((port) => {
    const portX = port.center.x - schematicComp.center.x;
    const portY = port.center.y - schematicComp.center.y;
    return {
      x: portX,
      y: portY,
      labels: [port.display_pin_label || `${port.pin_number || 1}`],
      pinNumber: port.pin_number || 1
    };
  });
  return {
    center: { x: 0, y: 0 },
    primitives: [boxPath],
    ports,
    size: { width, height }
  };
}

// lib/schematic/stages/utils/addSymbolProperties.ts
import { SymbolProperty } from "kicadts";

// lib/schematic/stages/symbols-stage-converters/createTextEffects.ts
import { TextEffects as TextEffects3, TextEffectsFont as TextEffectsFont3 } from "kicadts";
function createTextEffects(size, hide) {
  const font = new TextEffectsFont3();
  font.size = { height: size, width: size };
  return new TextEffects3({
    font,
    hiddenText: hide
  });
}

// lib/schematic/stages/utils/addSymbolProperties.ts
function addSymbolProperties({
  symbol,
  libId,
  description,
  keywords,
  fpFilters,
  footprintRef = "",
  referencePrefix
}) {
  const refPrefix = referencePrefix || libId.split(":")[1]?.[0] || "U";
  const properties = [
    {
      key: "Reference",
      value: refPrefix,
      id: 0,
      at: [2.032, 0, 90],
      hide: false
    },
    { key: "Value", value: refPrefix, id: 1, at: [0, 0, 90], hide: false },
    {
      key: "Footprint",
      value: footprintRef,
      id: 2,
      at: [-1.778, 0, 90],
      hide: true
    },
    {
      key: "Datasheet",
      value: "~",
      id: 3,
      at: [0, 0, 0],
      hide: true
    },
    {
      key: "Description",
      value: description,
      id: 4,
      at: [0, 0, 0],
      hide: true
    },
    {
      key: "ki_keywords",
      value: keywords,
      id: 5,
      at: [0, 0, 0],
      hide: true
    },
    {
      key: "ki_fp_filters",
      value: fpFilters,
      id: 6,
      at: [0, 0, 0],
      hide: true
    }
  ];
  for (const prop of properties) {
    symbol.properties.push(
      new SymbolProperty({
        key: prop.key,
        value: prop.value,
        id: prop.id,
        at: prop.at,
        effects: createTextEffects(1.27, prop.hide)
      })
    );
  }
}

// lib/schematic/stages/utils/createPinSubsymbol.ts
import {
  SchematicSymbol as SchematicSymbol3,
  SymbolPin,
  SymbolPinName,
  SymbolPinNumber,
  TextEffects as TextEffects4,
  TextEffectsFont as TextEffectsFont4
} from "kicadts";

// lib/schematic/stages/utils/calculatePinPosition.ts
import { applyToPoint as applyToPoint6, scale as createScaleMatrix2 } from "transformation-matrix";
function calculatePinPosition({
  port,
  center,
  size,
  isChip,
  portIndex,
  schematicComponent,
  schematicPorts,
  c2kMatSchScale
}) {
  const symbolScale = c2kMatSchScale;
  let portX = port.x ?? 0;
  let portY = port.y ?? 0;
  let usingCircuitJsonPort = false;
  if (isChip && portIndex !== void 0 && schematicComponent) {
    const sortedPorts = schematicPorts.filter(
      (p) => p.schematic_component_id === schematicComponent.schematic_component_id
    ).sort((a, b) => (a.pin_number || 0) - (b.pin_number || 0));
    if (sortedPorts[portIndex]) {
      const schPort = sortedPorts[portIndex];
      portX = schPort.center.x - schematicComponent.center.x;
      portY = schPort.center.y - schematicComponent.center.y;
      usingCircuitJsonPort = true;
    }
  }
  let dx;
  let dy;
  if (usingCircuitJsonPort) {
    dx = portX;
    dy = portY;
  } else {
    const cx = center?.x ?? 0;
    const cy = center?.y ?? 0;
    dx = portX - cx;
    dy = portY - cy;
  }
  const scaleMatrix = createScaleMatrix2(symbolScale, symbolScale);
  const scaled = applyToPoint6(scaleMatrix, { x: dx, y: dy });
  let isHorizontalPin;
  if (isChip && size) {
    const halfWidth = size.width / 2;
    const halfHeight = size.height / 2;
    const normalizedDx = Math.abs(dx) / halfWidth;
    const normalizedDy = Math.abs(dy) / halfHeight;
    isHorizontalPin = normalizedDx > normalizedDy;
  } else {
    isHorizontalPin = Math.abs(dx) > Math.abs(dy);
  }
  let x = scaled.x;
  let y = scaled.y;
  const CHIP_PIN_LENGTH = 6;
  if (isChip && size) {
    const halfWidth = size.width / 2 * symbolScale;
    const halfHeight = size.height / 2 * symbolScale;
    if (isHorizontalPin) {
      x = dx > 0 ? halfWidth : -halfWidth;
      y = dy * symbolScale;
    } else {
      x = dx * symbolScale;
      y = dy > 0 ? halfHeight : -halfHeight;
    }
  }
  let angle = 0;
  if (isHorizontalPin) {
    if (dx > 0) {
      angle = 180;
      if (isChip) x = x + CHIP_PIN_LENGTH;
    } else {
      angle = 0;
      if (isChip) x = x - CHIP_PIN_LENGTH;
    }
  } else {
    if (dy > 0) {
      angle = 270;
      if (isChip) y = y + CHIP_PIN_LENGTH;
    } else {
      angle = 90;
      if (isChip) y = y - CHIP_PIN_LENGTH;
    }
  }
  return { x, y, angle };
}

// lib/schematic/stages/utils/createPinSubsymbol.ts
function sourceElectricalType(port) {
  const types = [];
  if (port.is_input) types.push("input");
  if (port.is_output) types.push("output");
  if (port.is_bidirectional) types.push("bidirectional");
  if (port.is_passive) types.push("passive");
  if (port.provides_power || port.provides_ground) types.push("power_out");
  if (port.requires_power || port.requires_ground) types.push("power_in");
  if (port.do_not_connect) types.push("no_connect");
  if (types.length !== 1) {
    throw new Error(`Missing or conflicting electrical type: ${port.source_port_id}`);
  }
  const special = [
    port.is_using_tri_state,
    port.is_using_open_collector,
    port.is_using_open_emitter
  ].filter(Boolean).length;
  if (special > 1 || special && types[0] !== "output") {
    throw new Error(`Conflicting output mode: ${port.source_port_id}`);
  }
  if (port.is_using_tri_state) return "tri_state";
  if (port.is_using_open_collector) return "open_collector";
  if (port.is_using_open_emitter) return "open_emitter";
  return types[0];
}
function getPortSide(x, y) {
  if (Math.abs(x) > Math.abs(y)) return x < 0 ? "left" : "right";
  return y < 0 ? "down" : "up";
}
function hasDuplicatePositions(values) {
  const sorted = [...values].sort((a, b) => a - b);
  return sorted.some((value, index) => {
    const previous = sorted[index - 1];
    return previous !== void 0 && Math.abs(value - previous) < 1e-6;
  });
}
function getCircuitPinNumbers({
  symbolData,
  schematicComponent,
  schematicPorts,
  sourcePorts
}) {
  const matches = /* @__PURE__ */ new Map();
  if (!schematicComponent) return matches;
  const sourcePortsById = new Map(
    sourcePorts.map((port) => [port.source_port_id, port])
  );
  const symbolCenter = symbolData.center ?? { x: 0, y: 0 };
  const componentPorts = schematicPorts.filter(
    (port) => port.schematic_component_id === schematicComponent.schematic_component_id
  );
  for (const side of ["left", "right", "up", "down"]) {
    const symbolPorts = symbolData.ports.map((port, index) => ({
      index,
      x: (port.x ?? 0) - symbolCenter.x,
      y: (port.y ?? 0) - symbolCenter.y
    })).filter(
      (port) => getPortSide(port.x, port.y) === side
    );
    const circuitPorts = componentPorts.map((port) => ({
      port,
      x: port.center.x - schematicComponent.center.x,
      y: port.center.y - schematicComponent.center.y
    })).filter(
      ({ port, x, y }) => (port.facing_direction ?? getPortSide(x, y)) === side
    );
    if (symbolPorts.length === 0 || symbolPorts.length !== circuitPorts.length) {
      continue;
    }
    const coordinate = (port) => side === "left" || side === "right" ? port.y : port.x;
    if (hasDuplicatePositions(symbolPorts.map(coordinate)) || hasDuplicatePositions(circuitPorts.map(coordinate))) {
      continue;
    }
    symbolPorts.sort((a, b) => coordinate(a) - coordinate(b));
    circuitPorts.sort((a, b) => coordinate(a) - coordinate(b));
    for (let index = 0; index < symbolPorts.length; index++) {
      const symbolPort = symbolPorts[index];
      const circuitPort = circuitPorts[index];
      if (!symbolPort || !circuitPort) continue;
      const pinNumber = circuitPort.port.pin_number ?? (circuitPort.port.source_port_id ? sourcePortsById.get(circuitPort.port.source_port_id)?.pin_number : void 0);
      if (pinNumber !== void 0 && pinNumber !== null) {
        matches.set(symbolPort.index, String(pinNumber));
      }
    }
  }
  return matches;
}
function validateInferredPinNumbers(symbolData, inferredPinNumbers) {
  const missingPinIndices = symbolData.ports.map((port, index) => port.pinNumber == null ? index : void 0).filter((index) => index !== void 0);
  if (missingPinIndices.length === 0 || missingPinIndices.some((index) => !inferredPinNumbers.has(index))) {
    return /* @__PURE__ */ new Map();
  }
  const resolvedPinNumbers = symbolData.ports.map(
    (port, index) => port.pinNumber?.toString() ?? inferredPinNumbers.get(index)
  );
  if (resolvedPinNumbers.some((pinNumber) => pinNumber === void 0) || new Set(resolvedPinNumbers).size !== resolvedPinNumbers.length) {
    return /* @__PURE__ */ new Map();
  }
  return inferredPinNumbers;
}
function createPinSubsymbol({
  libId,
  symbolData,
  isChip,
  schematicComponent,
  schematicPorts,
  sourcePorts,
  c2kMatSchScale
}) {
  const pinSymbol = new SchematicSymbol3({
    libraryId: `${libId.split(":")[1]}_1_1`
  });
  const CHIP_PIN_LENGTH = 6;
  const CUSTOM_SYMBOL_PIN_LENGTH = 0.01;
  const inferredPinNumbers = isChip ? /* @__PURE__ */ new Map() : getCircuitPinNumbers({
    symbolData,
    schematicComponent,
    schematicPorts,
    sourcePorts
  });
  const circuitPinNumbers = validateInferredPinNumbers(
    symbolData,
    inferredPinNumbers
  );
  for (const [i, port] of symbolData.ports.entries()) {
    const pin = new SymbolPin();
    pin.pinElectricalType = "passive";
    pin.pinGraphicStyle = "line";
    const { x, y, angle } = calculatePinPosition({
      port,
      center: symbolData.center,
      size: symbolData.size,
      isChip,
      portIndex: i,
      schematicComponent,
      schematicPorts,
      c2kMatSchScale
    });
    pin.at = [x, y, angle];
    pin.length = isChip ? CHIP_PIN_LENGTH : CUSTOM_SYMBOL_PIN_LENGTH;
    const nameFont = new TextEffectsFont4();
    nameFont.size = { height: 1.27, width: 1.27 };
    const nameEffects = new TextEffects4({ font: nameFont });
    const pinName = port.labels?.[0] || "~";
    pin._sxName = new SymbolPinName({ value: pinName, effects: nameEffects });
    const numFont = new TextEffectsFont4();
    numFont.size = { height: 1.27, width: 1.27 };
    const numEffects = new TextEffects4({ font: numFont });
    const pinNum = port.pinNumber?.toString() ?? circuitPinNumbers.get(i) ?? `${i + 1}`;
    if (schematicComponent) {
      const matches = schematicPorts.filter((candidate) => candidate.schematic_component_id === schematicComponent.schematic_component_id && String(candidate.pin_number) === pinNum);
      const source = matches.length === 1 ? sourcePorts.find((candidate) => candidate.source_port_id === matches[0].source_port_id) : void 0;
      if (!source) throw new Error(`Ambiguous source pin: ${libId} ${pinNum}`);
      pin.pinElectricalType = sourceElectricalType(source);
    }
    pin._sxNumber = new SymbolPinNumber({
      value: pinNum,
      effects: numEffects
    });
    pinSymbol.pins.push(pin);
  }
  return pinSymbol;
}

// lib/schematic/stages/AddLibrarySymbolsStage.ts
var AddLibrarySymbolsStage = class extends ConverterStage {
  // Track processed symbol names to avoid duplicates
  processedSymbolNames = /* @__PURE__ */ new Set();
  _step() {
    const { kicadSch, db } = this.ctx;
    const libSymbols = new LibSymbols();
    const librarySymbols = [];
    this.processedSymbolNames = /* @__PURE__ */ new Set();
    const schematicComponents = db.schematic_component.list();
    for (const schematicComponent of schematicComponents) {
      const libSymbol = this.createLibrarySymbolForComponent(schematicComponent);
      if (libSymbol) {
        librarySymbols.push(libSymbol);
      }
    }
    const netLabels = db.schematic_net_label?.list?.() || [];
    for (const netLabel of netLabels) {
      if (netLabel.symbol_name) {
        const isPower = netLabel.source_net_id ? db.source_net.get(netLabel.source_net_id)?.is_power : false;
        const isGround = netLabel.source_net_id ? db.source_net.get(netLabel.source_net_id)?.is_ground : false;
        const isPowerOrGround = isPower || isGround;
        if (isPowerOrGround) {
          const libSymbol = this.createLibrarySymbolForNetLabel({
            netLabel,
            isPower: isPower ?? false,
            isGround: isGround ?? false
          });
          if (libSymbol) {
            librarySymbols.push(libSymbol);
          }
        }
      }
    }
    libSymbols.symbols = librarySymbols;
    if (kicadSch) {
      kicadSch.libSymbols = libSymbols;
    }
    this.finished = true;
  }
  /**
   * Create library symbol for a schematic component.
   * Handles both builtin symbols and custom symbols defined via schematic_symbol elements.
   */
  createLibrarySymbolForComponent(schematicComponent) {
    const { db } = this.ctx;
    const sourceComp = schematicComponent.source_component_id ? db.source_component.get(schematicComponent.source_component_id) : null;
    if (!sourceComp) return null;
    const symbolContext = resolveSchematicComponentSymbol({
      circuitJson: this.ctx.circuitJson,
      schematicComponent,
      sourceComponent: sourceComp,
      cadComponents: db.cad_component?.list?.() ?? []
    });
    const {
      cadComponent,
      schematicSymbolId,
      usesComponentLevelSymbolPrimitives,
      libraryId,
      isChip
    } = symbolContext;
    if (schematicSymbolId) {
      return this.createLibrarySymbolFromSchematicSymbol(
        schematicComponent,
        sourceComp,
        symbolContext
      );
    }
    if (usesComponentLevelSymbolPrimitives) {
      const innerSymbolData = buildSymbolDataFromSchematicPrimitives({
        circuitJson: this.ctx.circuitJson,
        schematicComponentId: schematicComponent.schematic_component_id,
        schematicComponentCenter: schematicComponent.center,
        schematicComponentSize: schematicComponent.size,
        schematicSymbol: {
          center: schematicComponent.center,
          size: schematicComponent.size
        }
      });
      if (innerSymbolData.primitives?.length > 0) {
        const symbolData2 = {
          ...innerSymbolData,
          // Imported symbol text is emitted as standalone schematic text.
          texts: []
        };
        const footprintName2 = getKicadCompatibleComponentName(
          sourceComp,
          cadComponent
        );
        let footprintRef = "";
        if (footprintName2) {
          footprintRef = `tscircuit:${footprintName2}`;
        }
        return this.createLibrarySymbol({
          libId: libraryId,
          symbolData: symbolData2,
          isChip: false,
          hidePinNames: true,
          schematicComponent,
          description: this.getDescription(sourceComp),
          keywords: this.getKeywords(sourceComp),
          fpFilters: this.getFpFilters(sourceComp),
          footprintRef,
          referencePrefix: getReferencePrefixForComponent(sourceComp),
          symbolScale: this.ctx.kicadSchematicScaleFactor
        });
      }
    }
    const symbolName = schematicComponent.symbol_name || (sourceComp.ftype === "simple_chip" || sourceComp.ftype === "simple_pin_header" || sourceComp.ftype === "simple_connector" ? `generic_chip_${schematicComponent.source_component_id}` : null);
    if (!symbolName) return null;
    const symbolData = this.getSymbolData(symbolName, schematicComponent);
    if (!symbolData) return null;
    const footprintName = getKicadCompatibleComponentName(
      sourceComp,
      cadComponent
    );
    return this.createLibrarySymbol({
      libId: libraryId,
      symbolData,
      isChip,
      schematicComponent,
      description: this.getDescription(sourceComp),
      keywords: this.getKeywords(sourceComp),
      fpFilters: this.getFpFilters(sourceComp),
      footprintRef: footprintName ? `tscircuit:${footprintName}` : "",
      referencePrefix: getReferencePrefixForComponent(sourceComp),
      symbolScale: this.ctx.kicadSchematicScaleFactor
    });
  }
  /**
   * Create library symbol from a schematic_symbol element.
   * This handles custom symbols defined via JSX like:
   * <chip name="Q1" symbol={<symbol>...</symbol>} />
   *
   * Naming precedence:
   * 1. schematic_symbol.name (highest priority)
   * 2. manufacturer_part_number / footprinter_string
   * 3. Generated name based on ftype
   */
  createLibrarySymbolFromSchematicSymbol(schematicComponent, sourceComp, symbolContext) {
    const { cadComponent, schematicSymbol, schematicSymbolId, libraryId } = symbolContext;
    if (!schematicSymbol || !schematicSymbolId) {
      return null;
    }
    if (this.processedSymbolNames.has(libraryId)) {
      return null;
    }
    this.processedSymbolNames.add(libraryId);
    const symbolData = buildSymbolDataFromSchematicPrimitives({
      circuitJson: this.ctx.circuitJson,
      schematicSymbolId,
      schematicSymbol,
      schematicComponentId: schematicComponent.schematic_component_id,
      schematicComponentCenter: schematicComponent.center,
      schematicComponentSize: schematicComponent.size
    });
    const footprintName = getKicadCompatibleComponentName(
      sourceComp,
      cadComponent
    );
    return this.createLibrarySymbol({
      libId: libraryId,
      symbolData,
      isChip: false,
      // Custom symbols are not treated as generic chips
      schematicComponent,
      description: this.getDescription(sourceComp),
      keywords: this.getKeywords(sourceComp),
      fpFilters: this.getFpFilters(sourceComp, schematicSymbol.name),
      footprintRef: footprintName ? `tscircuit:${footprintName}` : "",
      referencePrefix: getReferencePrefixForComponent(sourceComp),
      symbolScale: this.ctx.kicadSchematicScaleFactor
    });
  }
  /**
   * Create library symbol for a schematic net label with symbol_name
   */
  createLibrarySymbolForNetLabel({
    netLabel,
    isPower,
    isGround
  }) {
    const symbolName = netLabel.symbol_name;
    if (!symbolName) return null;
    const symbolData = symbols3[symbolName];
    if (!symbolData) return null;
    const libId = `Custom:${symbolName}`;
    return this.createLibrarySymbol({
      libId,
      symbolData,
      isChip: false,
      schematicComponent: void 0,
      description: isPower ? "Power net label" : isGround ? "Ground net label" : "Net symbol",
      keywords: isPower ? "power net" : isGround ? "ground net" : "net",
      fpFilters: "",
      referencePrefix: libId.split(":")[1]?.[0] || "U",
      symbolScale: this.ctx.kicadSchematicScaleFactor
    });
  }
  /**
   * Get symbol data from schematic-symbols or generate for generic chips
   */
  getSymbolData(symbolName, schematicComponent) {
    if (symbolName.startsWith("generic_chip_")) {
      return createGenericChipSymbolData(schematicComponent, this.ctx.db);
    }
    return getSchematicSymbolData(symbolName) || null;
  }
  /**
   * Create a KiCad library symbol from symbol data
   * This is the core method that handles both components and net labels
   */
  createLibrarySymbol({
    libId,
    symbolData,
    isChip,
    hidePinNames = false,
    schematicComponent,
    description,
    keywords,
    fpFilters,
    footprintRef = "",
    referencePrefix,
    symbolScale
  }) {
    const symbol = new SchematicSymbol4({
      libraryId: libId,
      excludeFromSim: false,
      inBom: true,
      onBoard: true
    });
    const pinNumbers = new SymbolPinNumbers();
    pinNumbers.hide = !isChip;
    symbol._sxPinNumbers = pinNumbers;
    const pinNames = new SymbolPinNames();
    pinNames.offset = isChip ? 1.27 : 0;
    if (hidePinNames) pinNames.hide = true;
    symbol._sxPinNames = pinNames;
    addSymbolProperties({
      symbol,
      libId,
      description,
      keywords,
      fpFilters,
      footprintRef,
      referencePrefix
    });
    const drawingSymbol = createDrawingSubsymbol({
      libId,
      symbolData,
      isChip,
      c2kMatSchScale: symbolScale
    });
    symbol.subSymbols.push(drawingSymbol);
    const pinSymbol = createPinSubsymbol({
      libId,
      symbolData,
      isChip,
      schematicComponent,
      schematicPorts: this.ctx.db.schematic_port.list(),
      sourcePorts: this.ctx.db.source_port.list(),
      c2kMatSchScale: symbolScale
    });
    symbol.subSymbols.push(pinSymbol);
    symbol._sxEmbeddedFonts = new EmbeddedFonts(false);
    return symbol;
  }
  getDescription(sourceComp) {
    if (sourceComp?.ftype === "simple_resistor") return "Resistor";
    if (sourceComp?.ftype === "simple_capacitor") return "Capacitor";
    if (sourceComp?.ftype === "simple_chip") return "Integrated Circuit";
    if (sourceComp?.ftype === "simple_connector") return "Connector";
    return "Component";
  }
  getKeywords(sourceComp) {
    if (sourceComp?.ftype === "simple_resistor") return "R res resistor";
    if (sourceComp?.ftype === "simple_capacitor") return "C cap capacitor";
    if (sourceComp?.ftype === "simple_chip") return "U IC chip";
    if (sourceComp?.ftype === "simple_connector") return "connector";
    return "";
  }
  getFpFilters(sourceComp, symbolName) {
    if (symbolName) {
      return `${symbolName}*`;
    }
    if (sourceComp?.ftype === "simple_resistor") return "R_*";
    if (sourceComp?.ftype === "simple_capacitor") return "C_*";
    if (sourceComp?.ftype === "simple_chip") return "*";
    if (sourceComp?.ftype === "simple_connector") return "*";
    return "*";
  }
  getOutput() {
    if (!this.ctx.kicadSch) {
      throw new Error("kicadSch is not initialized");
    }
    return this.ctx.kicadSch;
  }
};

// lib/schematic/stages/AddSchematicGraphicsStage.ts
import {
  Polyline,
  Pts as Pts2,
  SchematicArc,
  SchematicRectangle,
  SchematicText,
  Stroke as Stroke3,
  SymbolArcFill,
  SymbolRectangleFill,
  TextEffects as TextEffects5,
  TextEffectsFont as TextEffectsFont5,
  TextEffectsJustify as TextEffectsJustify2,
  Uuid,
  Xy as Xy2
} from "kicadts";
import { applyToPoint as applyToPoint7 } from "transformation-matrix";

// lib/schematic/stages/utils/getTextJustificationFromAnchor.ts
var LEFT_ANCHORS = /* @__PURE__ */ new Set([
  "left",
  "top_left",
  "center_left",
  "middle_left",
  "bottom_left"
]);
var RIGHT_ANCHORS = /* @__PURE__ */ new Set([
  "right",
  "top_right",
  "center_right",
  "middle_right",
  "bottom_right"
]);
var TOP_ANCHORS = /* @__PURE__ */ new Set([
  "top",
  "top_left",
  "top_center",
  "top_right",
  "middle_top"
]);
var BOTTOM_ANCHORS = /* @__PURE__ */ new Set([
  "bottom",
  "bottom_left",
  "bottom_center",
  "bottom_right",
  "middle_bottom"
]);
var getTextJustificationFromAnchor = (anchor) => {
  if (!anchor) return void 0;
  const horizontal = LEFT_ANCHORS.has(anchor) ? "left" : RIGHT_ANCHORS.has(anchor) ? "right" : void 0;
  const vertical = TOP_ANCHORS.has(anchor) ? "top" : BOTTOM_ANCHORS.has(anchor) ? "bottom" : void 0;
  if (!horizontal && !vertical) return void 0;
  return { horizontal, vertical };
};

// lib/schematic/stages/AddSchematicGraphicsStage.ts
var DEFAULT_SECTION_TEXT_SIZE_MM = 1.27;
var DEFAULT_SECTION_LINE_COLOR = { r: 0, g: 0, b: 0, a: 1 };
var DEFAULT_SECTION_TEXT_COLOR = { r: 0, g: 0, b: 0, a: 1 };
var DEFAULT_SECTION_TEXT_PADDING_X_MM = 0.22;
var DEFAULT_SECTION_TEXT_PADDING_Y_MM = 0.18;
var isStandaloneSchematicElement = (element) => !element.schematic_component_id && !("schematic_symbol_id" in element && element.schematic_symbol_id);
var AddSchematicGraphicsStage = class extends ConverterStage {
  _step() {
    const { kicadSch, db } = this.ctx;
    if (!kicadSch) {
      throw new Error("KicadSch instance not initialized in context");
    }
    if (!this.ctx.c2kMatSch) {
      this.finished = true;
      return;
    }
    const schematicLines = (db.schematic_line?.list() || []).filter(
      isStandaloneSchematicElement
    );
    const schematicArcs = (db.schematic_arc?.list() || []).filter(
      isStandaloneSchematicElement
    );
    const schematicTexts = (db.schematic_text?.list() || []).filter(
      isStandaloneSchematicElement
    );
    const preserveStandaloneGraphics = db.schematic_component.list().some(
      (component) => hasComponentLevelSymbolPrimitives(this.ctx.circuitJson, component)
    );
    const schematicRects = preserveStandaloneGraphics ? (db.schematic_rect?.list() || []).filter(isStandaloneSchematicElement) : [];
    const schematicPaths = preserveStandaloneGraphics ? (db.schematic_path?.list() || []).filter(isStandaloneSchematicElement) : [];
    if (schematicLines.length === 0 && schematicArcs.length === 0 && schematicTexts.length === 0 && schematicRects.length === 0 && schematicPaths.length === 0) {
      this.finished = true;
      return;
    }
    if (schematicArcs.length > 0) {
      const arcs = kicadSch.arcs || [];
      for (const arc of schematicArcs) {
        const points = getSchematicArcPoints(arc);
        const start = applyToPoint7(this.ctx.c2kMatSch, points.start);
        const mid = applyToPoint7(this.ctx.c2kMatSch, points.mid);
        const end = applyToPoint7(this.ctx.c2kMatSch, points.end);
        const stroke = new Stroke3();
        stroke.width = (arc.stroke_width ?? 0) * (this.ctx.kicadSchematicScaleFactor ?? 1);
        stroke.type = arc.is_dashed ? "dash" : "default";
        stroke.color = preserveStandaloneGraphics ? parseColor(arc.color) ?? DEFAULT_SECTION_LINE_COLOR : DEFAULT_SECTION_LINE_COLOR;
        const fill = new SymbolArcFill();
        fill.type = "none";
        arcs.push(
          new SchematicArc({
            start,
            mid,
            end,
            stroke,
            fill,
            uuid: crypto.randomUUID()
          })
        );
      }
      kicadSch.arcs = arcs;
    }
    if (schematicLines.length > 0) {
      const polylines = kicadSch.polylines || [];
      for (const line of schematicLines) {
        const start = applyToPoint7(this.ctx.c2kMatSch, {
          x: line.x1,
          y: line.y1
        });
        const end = applyToPoint7(this.ctx.c2kMatSch, {
          x: line.x2,
          y: line.y2
        });
        const polyline = new Polyline();
        polyline.points = new Pts2([
          new Xy2(start.x, start.y),
          new Xy2(end.x, end.y)
        ]);
        const stroke = new Stroke3();
        stroke.width = 0;
        stroke.type = "default";
        stroke.color = preserveStandaloneGraphics ? parseColor(line.color) ?? DEFAULT_SECTION_LINE_COLOR : DEFAULT_SECTION_LINE_COLOR;
        polyline.stroke = stroke;
        polyline.uuid = new Uuid(crypto.randomUUID());
        polylines.push(polyline);
      }
      kicadSch.polylines = polylines;
    }
    if (schematicPaths.length > 0) {
      const polylines = kicadSch.polylines || [];
      for (const path of schematicPaths) {
        if (path.points.length < 2) continue;
        const stroke = new Stroke3();
        stroke.width = (path.stroke_width ?? 0) * (this.ctx.kicadSchematicScaleFactor ?? 1);
        stroke.type = path.is_dashed ? "dash" : "default";
        stroke.color = preserveStandaloneGraphics ? parseColor(path.stroke_color ?? "") ?? DEFAULT_SECTION_LINE_COLOR : DEFAULT_SECTION_LINE_COLOR;
        polylines.push(
          new Polyline({
            points: new Pts2(
              path.points.map((point) => {
                const transformed = applyToPoint7(this.ctx.c2kMatSch, point);
                return new Xy2(transformed.x, transformed.y);
              })
            ),
            stroke,
            uuid: crypto.randomUUID()
          })
        );
      }
      kicadSch.polylines = polylines;
    }
    if (schematicRects.length > 0) {
      const rectangles = kicadSch.rectangles || [];
      for (const rect of schematicRects) {
        const halfWidth = rect.width / 2;
        const halfHeight = rect.height / 2;
        const firstCorner = applyToPoint7(this.ctx.c2kMatSch, {
          x: rect.center.x - halfWidth,
          y: rect.center.y - halfHeight
        });
        const secondCorner = applyToPoint7(this.ctx.c2kMatSch, {
          x: rect.center.x + halfWidth,
          y: rect.center.y + halfHeight
        });
        const stroke = new Stroke3();
        stroke.width = (rect.stroke_width ?? 0) * (this.ctx.kicadSchematicScaleFactor ?? 1);
        stroke.type = rect.is_dashed ? "dash" : "default";
        stroke.color = preserveStandaloneGraphics ? parseColor(rect.color) ?? DEFAULT_SECTION_LINE_COLOR : DEFAULT_SECTION_LINE_COLOR;
        const fill = new SymbolRectangleFill();
        const fillColor = rect.fill_color ? parseColor(rect.fill_color) : void 0;
        fill.type = rect.is_filled ? fillColor ? "color" : "background" : "none";
        if (fillColor) fill.color = fillColor;
        rectangles.push(
          new SchematicRectangle({
            start: {
              x: Math.min(firstCorner.x, secondCorner.x),
              y: Math.min(firstCorner.y, secondCorner.y)
            },
            end: {
              x: Math.max(firstCorner.x, secondCorner.x),
              y: Math.max(firstCorner.y, secondCorner.y)
            },
            stroke,
            fill,
            uuid: crypto.randomUUID()
          })
        );
      }
      kicadSch.rectangles = rectangles;
    }
    if (schematicTexts.length > 0) {
      const texts = kicadSch.texts || [];
      for (const text of schematicTexts) {
        const isInlineTraceText = "source_trace_id" in text;
        const preserveText = preserveStandaloneGraphics && !isInlineTraceText;
        let sourceY = text.position?.y ?? 0;
        if (!isInlineTraceText && !preserveText && text.position?.y !== void 0 && text.position.y < 2) {
          sourceY = text.position.y - DEFAULT_SECTION_TEXT_PADDING_Y_MM;
        }
        const position = applyToPoint7(this.ctx.c2kMatSch, {
          x: (text.position?.x ?? 0) + (isInlineTraceText || preserveText ? 0 : DEFAULT_SECTION_TEXT_PADDING_X_MM),
          y: sourceY
        });
        const font = new TextEffectsFont5();
        const fontSize = preserveText ? Math.max(
          0.01,
          text.font_size * (this.ctx.kicadSchematicScaleFactor ?? 1)
        ) : DEFAULT_SECTION_TEXT_SIZE_MM;
        font.size = { height: fontSize, width: fontSize };
        font.color = preserveText ? parseColor(text.color) ?? DEFAULT_SECTION_TEXT_COLOR : DEFAULT_SECTION_TEXT_COLOR;
        const justify = isInlineTraceText || preserveText ? getTextJustificationFromAnchor(text.anchor) : void 0;
        const effects = new TextEffects5({
          font,
          hiddenText: false,
          justify: justify ? new TextEffectsJustify2(justify) : void 0
        });
        const schematicText = new SchematicText({
          value: text.text || "",
          at: [position.x, position.y, text.rotation || 0],
          excludeFromSim: false,
          effects,
          uuid: new Uuid(crypto.randomUUID())
        });
        texts.push(schematicText);
      }
      kicadSch.texts = texts;
    }
    this.finished = true;
  }
  getOutput() {
    return this.ctx.kicadSch;
  }
};

// lib/schematic/stages/AddSchematicNetLabelsStage.ts
import {
  SchematicSymbol as SchematicSymbol5,
  SymbolLibId,
  SymbolProperty as SymbolProperty2,
  SymbolPin as SymbolPin2,
  SymbolInstances,
  SymbolInstancesProject,
  SymbolInstancePath,
  TextEffects as TextEffects6,
  TextEffectsFont as TextEffectsFont6,
  TextEffectsJustify as TextEffectsJustify3,
  GlobalLabel
} from "kicadts";
import { applyToPoint as applyToPoint8 } from "transformation-matrix";
import { symbols as symbols4 } from "schematic-symbols";
var AddSchematicNetLabelsStage = class extends ConverterStage {
  _step() {
    const { kicadSch, db } = this.ctx;
    const netLabels = db.schematic_net_label?.list?.() || [];
    if (netLabels.length === 0) {
      this.finished = true;
      return;
    }
    if (!this.ctx.c2kMatSch) {
      this.finished = true;
      return;
    }
    const symbols5 = [];
    const globalLabels = [];
    for (const netLabel of netLabels) {
      const labelText = netLabel.text || "";
      const symbolName = netLabel.symbol_name;
      if (symbolName) {
        const symbol = this.createSymbolFromNetLabel(
          netLabel,
          labelText,
          symbolName
        );
        if (symbol) {
          symbols5.push(symbol);
        }
      } else {
        const label = this.createGlobalLabel(netLabel, labelText);
        if (label) {
          globalLabels.push(label);
        }
      }
    }
    if (kicadSch && symbols5.length > 0) {
      const existingSymbols = kicadSch.symbols || [];
      kicadSch.symbols = [...existingSymbols, ...symbols5];
    }
    if (kicadSch && globalLabels.length > 0) {
      kicadSch.globalLabels = [
        ...kicadSch.globalLabels || [],
        ...globalLabels
      ];
    }
    this.finished = true;
  }
  /**
   * Create a KiCad symbol instance from a net label with a symbol_name
   * These are treated like power/ground symbols (e.g., vcc_up, ground_down)
   * Uses anchor_position as the primary coordinate source
   */
  createSymbolFromNetLabel(netLabel, labelText, symbolName) {
    if (!this.ctx.c2kMatSch) return null;
    const anchorPoint = {
      x: netLabel.anchor_position?.x ?? netLabel.center?.x ?? 0,
      y: netLabel.anchor_position?.y ?? netLabel.center?.y ?? 0
    };
    const anchorInKicad = applyToPoint8(this.ctx.c2kMatSch, anchorPoint);
    let { x, y } = anchorInKicad;
    const symbolData = symbols4[symbolName];
    const port = symbolData?.ports?.[0];
    if (port) {
      const pinPosition = calculatePinPosition({
        port,
        center: symbolData.center,
        size: symbolData.size,
        isChip: false,
        schematicPorts: [],
        c2kMatSchScale: this.ctx.kicadSchematicScaleFactor ?? 1
      });
      x -= pinPosition.x;
      y += pinPosition.y;
    }
    const uuid = crypto.randomUUID();
    const symbol = new SchematicSymbol5({
      at: [x, y, 0],
      unit: 1,
      excludeFromSim: false,
      inBom: true,
      onBoard: true,
      dnp: false,
      uuid,
      fieldsAutoplaced: false
    });
    const libId = `Custom:${symbolName}`;
    const symLibId = new SymbolLibId(libId);
    symbol._sxLibId = symLibId;
    const isUpSymbol = symbolName.includes("_up") || symbolName.toLowerCase().includes("vcc");
    const referenceOffset = isUpSymbol ? -4 : 4;
    const valueOffset = isUpSymbol ? -6 : 6;
    const referenceProperty = new SymbolProperty2({
      key: "Reference",
      value: labelText,
      // Use the label text as the reference
      id: 0,
      at: [x, y + referenceOffset, 0],
      effects: this.createTextEffects(1.27, false)
    });
    const valueProperty = new SymbolProperty2({
      key: "Value",
      value: labelText,
      id: 1,
      at: [x, y + valueOffset, 0],
      effects: this.createTextEffects(1.27, true)
    });
    const footprintProperty = new SymbolProperty2({
      key: "Footprint",
      value: "",
      id: 2,
      at: [x - 1.778, y, 90],
      effects: this.createTextEffects(1.27, true)
    });
    const datasheetProperty = new SymbolProperty2({
      key: "Datasheet",
      value: "~",
      id: 3,
      at: [x, y, 0],
      effects: this.createTextEffects(1.27, true)
    });
    const descriptionProperty = new SymbolProperty2({
      key: "Description",
      value: `Power/Net symbol: ${labelText}`,
      id: 4,
      at: [x, y, 0],
      effects: this.createTextEffects(1.27, true)
    });
    symbol.properties.push(
      referenceProperty,
      valueProperty,
      footprintProperty,
      datasheetProperty,
      descriptionProperty
    );
    const pin = new SymbolPin2();
    pin.numberString = "1";
    pin.uuid = crypto.randomUUID();
    symbol.pins.push(pin);
    const { kicadSch } = this.ctx;
    const instances = new SymbolInstances();
    const project = new SymbolInstancesProject("");
    const instancePathPrefix = this.ctx.symbolInstancePathPrefix ?? `/${kicadSch?.uuid?.value || ""}`;
    const path = new SymbolInstancePath(instancePathPrefix);
    path.reference = labelText;
    path.unit = 1;
    project.paths.push(path);
    instances.projects.push(project);
    symbol._sxInstances = instances;
    return symbol;
  }
  /**
   * Create a KiCad global label from a schematic_net_label without a symbol_name
   * Uses anchor_position as the primary coordinate source for the arrow anchor point
   */
  createGlobalLabel(netLabel, labelText) {
    if (!this.ctx.c2kMatSch || !this.ctx.kicadSch) return null;
    const { x, y } = applyToPoint8(this.ctx.c2kMatSch, {
      x: netLabel.anchor_position?.x ?? netLabel.center?.x ?? 0,
      y: netLabel.anchor_position?.y ?? netLabel.center?.y ?? 0
    });
    const anchorSide = netLabel.anchor_side || "left";
    const orientationMap = {
      left: {
        angle: 0,
        shape: "input",
        justify: { horizontal: "left" }
      },
      right: {
        angle: 180,
        shape: "input",
        justify: { horizontal: "right" }
      },
      top: {
        angle: 270,
        shape: "input",
        justify: { horizontal: "right" }
      },
      bottom: {
        angle: 90,
        shape: "input",
        justify: { horizontal: "left" }
      }
    };
    const orientation = orientationMap[anchorSide] || orientationMap["left"];
    const effects = this.createTextEffects(1.27, false);
    if (Object.keys(orientation.justify).length > 0) {
      effects.justify = new TextEffectsJustify3(orientation.justify);
    }
    const globalLabel = new GlobalLabel({
      value: labelText,
      shape: orientation.shape,
      at: [x, y, orientation.angle],
      effects,
      uuid: crypto.randomUUID(),
      // Keep the label anchor supplied by Circuit JSON instead of allowing
      // KiCad to reposition it when the schematic is opened.
      fieldsAutoplaced: false
    });
    return globalLabel;
  }
  /**
   * Creates text effects for properties and labels
   */
  createTextEffects(size, hide = false) {
    const font = new TextEffectsFont6();
    font.size = { height: size, width: size };
    return new TextEffects6({
      font,
      hiddenText: hide
    });
  }
  getOutput() {
    if (!this.ctx.kicadSch) {
      throw new Error("kicadSch is not initialized");
    }
    return this.ctx.kicadSch;
  }
};

// lib/schematic/stages/AddSchematicSymbolsStage.ts
import { formatSiUnit } from "format-si-unit";
import {
  EmbeddedFonts as EmbeddedFonts2,
  SchematicSymbol as SchematicSymbol6,
  SymbolInstancePath as SymbolInstancePath2,
  SymbolInstances as SymbolInstances2,
  SymbolInstancesProject as SymbolInstancesProject2,
  SymbolLibId as SymbolLibId2,
  SymbolPin as SymbolPin3,
  SymbolPinNames as SymbolPinNames2,
  SymbolPinNumbers as SymbolPinNumbers2,
  SymbolProperty as SymbolProperty3,
  TextEffects as TextEffects7,
  TextEffectsFont as TextEffectsFont7,
  TextEffectsJustify as TextEffectsJustify4
} from "kicadts";
import { applyToPoint as applyToPoint9 } from "transformation-matrix";
var AddSchematicSymbolsStage = class extends ConverterStage {
  _step() {
    const { kicadSch, db } = this.ctx;
    const schematicComponents = db.schematic_component.list();
    if (schematicComponents.length === 0) {
      this.finished = true;
      return;
    }
    const symbols5 = [];
    for (const schematicComponent of schematicComponents) {
      const sourceComponent = schematicComponent.source_component_id ? db.source_component.get(schematicComponent.source_component_id) : null;
      if (!sourceComponent) continue;
      const symbolContext = resolveSchematicComponentSymbol({
        circuitJson: this.ctx.circuitJson,
        schematicComponent,
        sourceComponent,
        cadComponents: db.cad_component?.list?.() ?? []
      });
      const {
        schematicSymbol,
        schematicSymbolId,
        hasLinkedSymbolPrimitives,
        usesComponentLevelSymbolPrimitives,
        libraryId
      } = symbolContext;
      if (!this.ctx.c2kMatSch) continue;
      const { x, y } = applyToPoint9(this.ctx.c2kMatSch, {
        x: schematicComponent.center.x,
        y: schematicComponent.center.y
      });
      const uuid = crypto.randomUUID();
      const symbol = new SchematicSymbol6({
        at: [x, y, 0],
        unit: 1,
        excludeFromSim: false,
        inBom: true,
        onBoard: true,
        dnp: false,
        uuid,
        // Circuit JSON already supplies the intended field positions. Marking
        // these fields as autoplaced lets KiCad rearrange them on load and
        // breaks their alignment with pins and net labels.
        fieldsAutoplaced: false
      });
      const symLibId = new SymbolLibId2(libraryId);
      symbol._sxLibId = symLibId;
      const { reference, value, description } = this.getComponentMetadata(sourceComponent);
      const hasManufacturerValueForValuePlacement = (sourceComponent.ftype === "simple_chip" || sourceComponent.ftype === "simple_connector") && Boolean(sourceComponent.manufacturer_part_number);
      const { refTextPos, valTextPos, refJustify, valJustify } = this.getTextPositions({
        schematicComponent,
        placeValueAtNamePosition: hasManufacturerValueForValuePlacement,
        isCustomSymbol: hasLinkedSymbolPrimitives,
        reference,
        value
      });
      const symbolMetadata = schematicSymbol?.metadata?.kicad_symbol;
      const refMeta = symbolMetadata?.properties?.Reference;
      const hideGeneratedCustomReference = Boolean(schematicSymbolId) || usesComponentLevelSymbolPrimitives;
      const referenceProperty = new SymbolProperty3({
        key: "Reference",
        value: refMeta?.value ?? reference,
        id: 0,
        at: [refTextPos.x, refTextPos.y, 0],
        effects: this.createTextEffects(
          Number(refMeta?.effects?.font?.size?.x ?? 1.27),
          {
            hide: refMeta?.effects?.hide ?? hideGeneratedCustomReference,
            justify: refJustify
          }
        )
      });
      const hideValue = Boolean(schematicSymbolId) || usesComponentLevelSymbolPrimitives || sourceComponent.ftype === "simple_chip" && !hasManufacturerValueForValuePlacement || sourceComponent.ftype === "simple_diode" && !schematicComponent.symbol_display_value || sourceComponent.ftype === "simple_pin_header" || sourceComponent.ftype === "simple_test_point";
      const valMeta = symbolMetadata?.properties?.Value;
      const valueProperty = new SymbolProperty3({
        key: "Value",
        value: valMeta?.value ?? value,
        id: 1,
        at: [valTextPos.x, valTextPos.y, 0],
        effects: this.createTextEffects(
          Number(valMeta?.effects?.font?.size?.x ?? 1.27),
          { hide: valMeta?.effects?.hide ?? hideValue, justify: valJustify }
        )
      });
      const fpMeta = symbolMetadata?.properties?.Footprint;
      const footprintProperty = new SymbolProperty3({
        key: "Footprint",
        value: fpMeta?.value ?? "",
        id: 2,
        at: [x - 1.778, y, 90],
        effects: this.createTextEffects(1.27, {
          hide: fpMeta?.effects?.hide ?? true
        })
      });
      const dsMeta = symbolMetadata?.properties?.Datasheet;
      const datasheetProperty = new SymbolProperty3({
        key: "Datasheet",
        value: dsMeta?.value ?? "~",
        id: 3,
        at: [x, y, 0],
        effects: this.createTextEffects(1.27, {
          hide: dsMeta?.effects?.hide ?? true
        })
      });
      const descMeta = symbolMetadata?.properties?.Description;
      const descriptionProperty = new SymbolProperty3({
        key: "Description",
        value: descMeta?.value ?? description,
        id: 4,
        at: [x, y, 0],
        effects: this.createTextEffects(1.27, {
          hide: descMeta?.effects?.hide ?? true
        })
      });
      symbol.properties.push(
        referenceProperty,
        valueProperty,
        footprintProperty,
        datasheetProperty,
        descriptionProperty
      );
      const kwMeta = symbolMetadata?.properties?.ki_keywords;
      if (kwMeta?.value) {
        const keywordsProperty = new SymbolProperty3({
          key: "ki_keywords",
          value: kwMeta.value,
          id: 5,
          at: [x, y, 0],
          effects: this.createTextEffects(1.27, {
            hide: kwMeta.effects?.hide ?? true
          })
        });
        symbol.properties.push(keywordsProperty);
      }
      const fpFilterMeta = symbolMetadata?.properties?.ki_fp_filters;
      if (fpFilterMeta?.value) {
        const fpFiltersProperty = new SymbolProperty3({
          key: "ki_fp_filters",
          value: fpFilterMeta.value,
          id: 6,
          at: [x, y, 0],
          effects: this.createTextEffects(1.27, {
            hide: fpFilterMeta.effects?.hide ?? true
          })
        });
        symbol.properties.push(fpFiltersProperty);
      }
      if (symbolMetadata) {
        if (symbolMetadata.inBom !== void 0) {
          symbol.inBom = symbolMetadata.inBom;
        }
        if (symbolMetadata.onBoard !== void 0) {
          symbol.onBoard = symbolMetadata.onBoard;
        }
        if (symbolMetadata.excludeFromSim !== void 0) {
          symbol.excludeFromSim = symbolMetadata.excludeFromSim;
        }
        if (symbolMetadata.pinNames) {
          const pinNames = new SymbolPinNames2();
          if (symbolMetadata.pinNames.offset !== void 0) {
            pinNames.offset = Number(symbolMetadata.pinNames.offset);
          }
          if (symbolMetadata.pinNames.hide !== void 0) {
            pinNames.hide = symbolMetadata.pinNames.hide;
          }
          symbol.pinNames = pinNames;
        }
        if (symbolMetadata.pinNumbers) {
          const pinNumbers = new SymbolPinNumbers2();
          if (symbolMetadata.pinNumbers.hide !== void 0) {
            pinNumbers.hide = symbolMetadata.pinNumbers.hide;
          }
          symbol.pinNumbers = pinNumbers;
        }
        if (symbolMetadata.embeddedFonts !== void 0) {
          symbol._sxEmbeddedFonts = new EmbeddedFonts2(
            symbolMetadata.embeddedFonts
          );
        }
      }
      let schematicPorts = db.schematic_port.list().filter(
        (p) => p.schematic_component_id === schematicComponent.schematic_component_id
      );
      if (schematicSymbolId) {
        const customSymbolPorts = schematicPorts.filter(
          (p) => p.display_pin_label
        );
        if (customSymbolPorts.length > 0) {
          schematicPorts = customSymbolPorts;
        }
      }
      schematicPorts.sort(
        (a, b) => (a.pin_number || 0) - (b.pin_number || 0)
      );
      for (let i = 0; i < schematicPorts.length; i++) {
        const port = schematicPorts[i];
        if (!port) continue;
        const pin = new SymbolPin3();
        pin.numberString = `${port.pin_number || i + 1}`;
        pin.uuid = crypto.randomUUID();
        symbol.pins.push(pin);
      }
      const instances = new SymbolInstances2();
      const project = new SymbolInstancesProject2("");
      const instancePathPrefix = this.ctx.symbolInstancePathPrefix ?? `/${kicadSch?.uuid?.value || ""}`;
      const path = new SymbolInstancePath2(instancePathPrefix);
      path.reference = reference;
      path.unit = 1;
      project.paths.push(path);
      instances.projects.push(project);
      symbol._sxInstances = instances;
      symbols5.push(symbol);
    }
    if (kicadSch) {
      kicadSch.symbols = symbols5;
    }
    this.finished = true;
  }
  /**
   * Get text positions from schematic symbol definition or schematic_text elements
   */
  getTextPositions({
    schematicComponent,
    placeValueAtNamePosition,
    isCustomSymbol,
    reference,
    value
  }) {
    const c2kMatSch = this.ctx.c2kMatSch;
    const symbolKicadPos = applyToPoint9(c2kMatSch, {
      x: schematicComponent.center.x,
      y: schematicComponent.center.y
    });
    const bodyEdge = applyToPoint9(c2kMatSch, {
      x: schematicComponent.center.x,
      y: schematicComponent.center.y + (schematicComponent.size?.height || 1) / 2
    });
    const componentHeightMm = Math.abs(bodyEdge.y - symbolKicadPos.y) * 2;
    const referenceAboveBodyY = symbolKicadPos.y - componentHeightMm / 2 - 3;
    const valueBelowBodyY = symbolKicadPos.y + componentHeightMm / 2 + 3;
    if (isCustomSymbol) {
      const customHeightMm = (schematicComponent.size?.height || 1) * this.ctx.kicadSchematicScaleFactor;
      const refTextPos2 = {
        x: symbolKicadPos.x,
        y: symbolKicadPos.y - customHeightMm / 2 - 3
      };
      const valTextPos2 = {
        x: symbolKicadPos.x,
        y: symbolKicadPos.y + customHeightMm / 2 + 3
      };
      if (placeValueAtNamePosition) {
        return {
          refTextPos: refTextPos2,
          valTextPos: { x: symbolKicadPos.x, y: symbolKicadPos.y }
        };
      }
      return { refTextPos: refTextPos2, valTextPos: valTextPos2 };
    }
    const schematicTexts = this.ctx.db.schematic_text?.list?.()?.filter(
      (t) => t.schematic_component_id === schematicComponent.schematic_component_id
    ) || [];
    const referenceText = schematicTexts.find(
      (text) => reference.length > 0 && text.text === reference
    );
    const valueText = schematicTexts.find(
      (text) => value.length > 0 && value !== reference && text.text === value
    );
    const refTextPosFromCircuitJson = this.getTextPosition(referenceText);
    const valTextPosFromCircuitJson = this.getTextPosition(valueText);
    if (refTextPosFromCircuitJson || valTextPosFromCircuitJson) {
      return {
        refTextPos: refTextPosFromCircuitJson?.position ?? {
          x: symbolKicadPos.x,
          y: referenceAboveBodyY
        },
        valTextPos: valTextPosFromCircuitJson?.position ?? {
          x: symbolKicadPos.x,
          y: valueBelowBodyY
        },
        refJustify: refTextPosFromCircuitJson?.justify,
        valJustify: valTextPosFromCircuitJson?.justify
      };
    }
    const refText = schematicTexts.find((t) => t.text && t.text.length > 0);
    if (refText) {
      const nameTextPos = this.getTextPosition(refText).position;
      if (placeValueAtNamePosition) {
        return {
          refTextPos: { x: symbolKicadPos.x, y: referenceAboveBodyY },
          valTextPos: nameTextPos
        };
      }
      const refTextPos2 = nameTextPos;
      const valTextPos2 = { x: symbolKicadPos.x, y: valueBelowBodyY };
      return { refTextPos: refTextPos2, valTextPos: valTextPos2 };
    }
    const symbolName = schematicComponent.symbol_name;
    if (!symbolName) {
      return {
        refTextPos: { x: symbolKicadPos.x, y: referenceAboveBodyY },
        valTextPos: { x: symbolKicadPos.x, y: valueBelowBodyY }
      };
    }
    const symbol = getSchematicSymbolData(symbolName);
    if (!symbol) {
      return {
        refTextPos: { x: symbolKicadPos.x, y: referenceAboveBodyY },
        valTextPos: { x: symbolKicadPos.x, y: valueBelowBodyY }
      };
    }
    let refTextPrimitive = null;
    let valTextPrimitive = null;
    for (const primitive of symbol.primitives) {
      if (primitive.type === "text") {
        if (primitive.text === "{REF}") {
          refTextPrimitive = primitive;
        } else if (primitive.text === "{VAL}") {
          valTextPrimitive = primitive;
        }
      }
    }
    const symbolCenter = symbol.center || { x: 0, y: 0 };
    const refTextPos = refTextPrimitive ? applyToPoint9(c2kMatSch, {
      x: schematicComponent.center.x + (refTextPrimitive.x - symbolCenter.x),
      y: schematicComponent.center.y + (refTextPrimitive.y - symbolCenter.y)
    }) : { x: symbolKicadPos.x, y: referenceAboveBodyY };
    const valTextPos = valTextPrimitive ? applyToPoint9(c2kMatSch, {
      x: schematicComponent.center.x + (valTextPrimitive.x - symbolCenter.x),
      y: schematicComponent.center.y + (valTextPrimitive.y - symbolCenter.y)
    }) : { x: symbolKicadPos.x, y: valueBelowBodyY };
    return {
      refTextPos,
      valTextPos,
      refJustify: getTextJustificationFromAnchor(refTextPrimitive?.anchor),
      valJustify: getTextJustificationFromAnchor(valTextPrimitive?.anchor)
    };
  }
  getTextPosition(text) {
    if (!text) return void 0;
    return {
      position: applyToPoint9(this.ctx.c2kMatSch, text.position),
      justify: getTextJustificationFromAnchor(text.anchor)
    };
  }
  /**
   * Get component metadata (reference, value, description)
   */
  getComponentMetadata(sourceComp) {
    const name = sourceComp.name || "?";
    const reference = getReferenceDesignator(sourceComp);
    if (sourceComp.ftype === "simple_resistor") {
      return {
        reference,
        value: sourceComp.display_resistance || "R",
        description: "Resistor"
      };
    }
    if (sourceComp.ftype === "simple_capacitor") {
      return {
        reference,
        value: sourceComp.display_capacitance || "C",
        description: "Capacitor"
      };
    }
    if (sourceComp.ftype === "simple_inductor") {
      return {
        reference,
        value: sourceComp.display_inductance || "L",
        description: "Inductor"
      };
    }
    if (sourceComp.ftype === "simple_crystal") {
      const frequencyDisplay = `${formatSiUnit(sourceComp.frequency)}Hz`;
      const loadCapacitanceDisplay = sourceComp.load_capacitance ? ` / ${formatSiUnit(sourceComp.load_capacitance)}F` : "";
      return {
        reference,
        value: `${frequencyDisplay}${loadCapacitanceDisplay}`,
        description: "Crystal oscillator"
      };
    }
    if (sourceComp.ftype === "simple_diode") {
      return {
        reference,
        value: sourceComp.manufacturer_part_number || "",
        description: "Diode"
      };
    }
    if (sourceComp.ftype === "simple_chip") {
      return {
        reference,
        value: sourceComp.manufacturer_part_number || "",
        description: "Integrated Circuit"
      };
    }
    if (sourceComp.ftype === "simple_led") {
      return {
        reference,
        value: sourceComp.manufacturer_part_number || "",
        description: "LED"
      };
    }
    if (sourceComp.ftype === "simple_switch") {
      return {
        reference,
        value: sourceComp.manufacturer_part_number || "",
        description: "Switch"
      };
    }
    if (sourceComp.ftype === "simple_potentiometer") {
      return {
        reference,
        value: sourceComp.display_max_resistance || "",
        description: "Potentiometer"
      };
    }
    if (sourceComp.ftype === "simple_connector") {
      return {
        reference,
        value: sourceComp.manufacturer_part_number || "",
        description: "Connector"
      };
    }
    return {
      reference,
      value: name,
      description: "Component"
    };
  }
  /**
   * Creates text effects for properties
   */
  createTextEffects(size, {
    hide = false,
    justify
  } = {}) {
    const font = new TextEffectsFont7();
    font.size = { height: size, width: size };
    const justifyObj = justify ? new TextEffectsJustify4(justify) : void 0;
    const effects = new TextEffects7({
      font,
      hiddenText: hide,
      justify: justifyObj
    });
    return effects;
  }
  getOutput() {
    if (!this.ctx.kicadSch) {
      throw new Error("kicadSch is not initialized");
    }
    return this.ctx.kicadSch;
  }
};

// lib/schematic/stages/AddSchematicTracesStage.ts
import { Wire, Pts as Pts3, Xy as Xy3, Stroke as Stroke4, Junction } from "kicadts";
import { applyToPoint as applyToPoint10 } from "transformation-matrix";
var DEFAULT_LINE_WIDTH_MM = 0.254;
var AddSchematicTracesStage = class extends ConverterStage {
  _step() {
    const { kicadSch, db } = this.ctx;
    if (!kicadSch) {
      throw new Error("KicadSch instance not initialized in context");
    }
    const schematicTraces = db.schematic_trace.list();
    if (schematicTraces.length === 0) {
      this.finished = true;
      return;
    }
    const wires = [];
    const junctions = [];
    for (const schematicTrace of schematicTraces) {
      for (const edge of schematicTrace.edges) {
        const wire = this.createWireFromEdge(edge);
        wires.push(wire);
      }
      for (const junction of schematicTrace.junctions) {
        const kicadJunction = this.createJunction(junction);
        junctions.push(kicadJunction);
      }
    }
    kicadSch.wires = wires;
    kicadSch.junctions = junctions;
    this.finished = true;
  }
  /**
   * Create a KiCad wire from a schematic trace edge
   */
  createWireFromEdge(edge) {
    const wire = new Wire();
    if (!this.ctx.c2kMatSch) {
      throw new Error(
        "Schematic transformation matrix not initialized in context"
      );
    }
    const from = applyToPoint10(this.ctx.c2kMatSch, {
      x: edge.from.x,
      y: edge.from.y
    });
    const to = applyToPoint10(this.ctx.c2kMatSch, {
      x: edge.to.x,
      y: edge.to.y
    });
    const x1 = from.x;
    const y1 = from.y;
    const x2 = to.x;
    const y2 = to.y;
    const pts = new Pts3([new Xy3(x1, y1), new Xy3(x2, y2)]);
    wire.points = pts;
    const stroke = new Stroke4();
    stroke.width = DEFAULT_LINE_WIDTH_MM;
    stroke.type = "default";
    wire.stroke = stroke;
    wire.uuid = crypto.randomUUID();
    return wire;
  }
  /**
   * Create a KiCad junction from a circuit-json junction point
   */
  createJunction(junction) {
    if (!this.ctx.c2kMatSch) {
      throw new Error(
        "Schematic transformation matrix not initialized in context"
      );
    }
    const { x, y } = applyToPoint10(this.ctx.c2kMatSch, {
      x: junction.x,
      y: junction.y
    });
    const kicadJunction = new Junction({
      at: [x, y],
      diameter: 0
      // 0 means use default diameter
    });
    kicadJunction.uuid = crypto.randomUUID();
    return kicadJunction;
  }
  getOutput() {
    return this.ctx.kicadSch;
  }
};

// lib/schematic/stages/AddSheetInstancesStage.ts
import {
  SheetInstances,
  SheetInstancesRootPath,
  SheetInstancesRootPage,
  EmbeddedFonts as EmbeddedFonts3
} from "kicadts";
var AddSheetInstancesStage = class extends ConverterStage {
  _step() {
    const { kicadSch } = this.ctx;
    if (!kicadSch) {
      throw new Error("KicadSch instance not initialized in context");
    }
    const sheetInstances = new SheetInstances();
    const path = new SheetInstancesRootPath();
    path.value = "/";
    const page = new SheetInstancesRootPage("1");
    path.pages = [page];
    sheetInstances.paths = [path];
    kicadSch.sheetInstances = sheetInstances;
    kicadSch.embeddedFonts = new EmbeddedFonts3(false);
    this.finished = true;
  }
  getOutput() {
    return this.ctx.kicadSch;
  }
};

// lib/schematic/stages/InitializeSchematicStage.ts
import { Paper, Uuid as Uuid4 } from "kicadts";
var InitializeSchematicStage = class extends ConverterStage {
  _step() {
    const { kicadSch, schematicPaperSize } = this.ctx;
    if (!kicadSch) {
      throw new Error("KicadSch instance not initialized in context");
    }
    kicadSch.version = 20250114;
    const paper = new Paper();
    if (schematicPaperSize?.customSize) {
      paper.customSize = schematicPaperSize.customSize;
    } else {
      paper.size = schematicPaperSize?.name ?? "A4";
    }
    paper.isPortrait = schematicPaperSize?.isPortrait ?? false;
    kicadSch.paper = paper;
    kicadSch.uuid = new Uuid4(this.ctx.schematicFileUuid ?? crypto.randomUUID());
    this.finished = true;
  }
  getOutput() {
    return this.ctx.kicadSch;
  }
};

// lib/schematic/CircuitJsonToKicadSchConverter.ts
var DEFAULT_SCHEMATIC_SCALE_FACTOR = 15;
var COMPACT_LARGE_SHEET_MARGIN_MM = 15;
var TITLE_BLOCK_CONTENT_OFFSET_MM = 5;
var getSingleSheetSchematicLayout = (db) => {
  let measurement = getSchematicBoundsAndCenter(db);
  let contentWidthMm = (measurement.bounds.maxX - measurement.bounds.minX) * DEFAULT_SCHEMATIC_SCALE_FACTOR;
  let contentHeightMm = (measurement.bounds.maxY - measurement.bounds.minY) * DEFAULT_SCHEMATIC_SCALE_FACTOR;
  let paperSize = selectSchematicPaperSize(contentWidthMm, contentHeightMm);
  if (!measurement.hasComponentLevelSourceGeometry || paperSize.name === "A4" || paperSize.name === "A3") {
    return { ...measurement, paperSize };
  }
  measurement = getSchematicBoundsAndCenter(db, {
    useComponentLevelSourceGeometry: true
  });
  contentWidthMm = (measurement.bounds.maxX - measurement.bounds.minX) * DEFAULT_SCHEMATIC_SCALE_FACTOR;
  contentHeightMm = (measurement.bounds.maxY - measurement.bounds.minY) * DEFAULT_SCHEMATIC_SCALE_FACTOR;
  paperSize = selectSchematicPaperSize(
    contentWidthMm,
    contentHeightMm,
    COMPACT_LARGE_SHEET_MARGIN_MM
  );
  return { ...measurement, paperSize };
};
var getSchematicSheetOptions = ({
  options,
  schematicSheetId
}) => options.schematicSheets?.find(
  (sheetOptions) => (sheetOptions.schematicSheetId ?? null) === schematicSheetId
);
var createSchematicTransform = ({
  center,
  circuitOrigin,
  contentCenter,
  scaleFactor
}) => circuitOrigin ? compose2(
  translate2(circuitOrigin.x, circuitOrigin.y),
  scale(scaleFactor, -scaleFactor)
) : compose2(
  translate2(contentCenter.x, contentCenter.y),
  scale(scaleFactor, -scaleFactor),
  translate2(-center.x, -center.y)
);
var CircuitJsonToKicadSchConverter = class {
  ctx;
  pipeline;
  currentStageIndex = 0;
  finished = false;
  circuitJson;
  schematicSheetPlan;
  files = [];
  built = false;
  options;
  get currentStage() {
    return this.pipeline[this.currentStageIndex];
  }
  constructor(circuitJson, options = {}) {
    this.circuitJson = circuitJson;
    this.options = options;
    this.schematicSheetPlan = buildSchematicSheetPlan(circuitJson);
    const kicadSchematicScaleFactor = DEFAULT_SCHEMATIC_SCALE_FACTOR;
    const db = cju(circuitJson);
    const { center, paperSize: fittedPaperSize } = getSingleSheetSchematicLayout(db);
    const paperSize = options.paperSize ?? fittedPaperSize;
    const sheetOptions = getSchematicSheetOptions({
      options,
      schematicSheetId: null
    });
    const titleBlockContentOffsetMm = options.titleBlock ? TITLE_BLOCK_CONTENT_OFFSET_MM : 0;
    const contentCenter = {
      x: paperSize.width / 2,
      y: paperSize.height / 2 - titleBlockContentOffsetMm
    };
    this.ctx = {
      db,
      circuitJson,
      kicadSch: new KicadSch({
        generator: "circuit-json-to-kicad",
        generatorVersion: "0.0.1",
        titleBlock: createKicadSchematicTitleBlock(options.titleBlock)
      }),
      kicadSchematicScaleFactor,
      schematicPaperSize: paperSize,
      c2kMatSch: createSchematicTransform({
        center,
        circuitOrigin: sheetOptions?.circuitOrigin,
        contentCenter,
        scaleFactor: kicadSchematicScaleFactor
      })
    };
    this.pipeline = [
      new InitializeSchematicStage(circuitJson, this.ctx),
      new AddLibrarySymbolsStage(circuitJson, this.ctx),
      new AddSchematicSymbolsStage(circuitJson, this.ctx),
      new AddSchematicNetLabelsStage(circuitJson, this.ctx),
      new AddSchematicTracesStage(circuitJson, this.ctx),
      new AddSchematicGraphicsStage(circuitJson, this.ctx),
      new AddSheetInstancesStage(circuitJson, this.ctx)
    ];
  }
  step() {
    if (this.schematicSheetPlan.isHierarchical) {
      this.buildAll();
      this.finished = true;
      return;
    }
    if (!this.currentStage) {
      this.finished = true;
      return;
    }
    this.currentStage.step();
    if (this.currentStage.finished) {
      this.currentStageIndex++;
    }
  }
  runUntilFinished() {
    while (!this.finished) {
      this.step();
    }
  }
  getOutput() {
    if (this.schematicSheetPlan.isHierarchical) {
      this.buildAll();
      return this.files[0].kicadSch;
    }
    return this.ctx.kicadSch;
  }
  /**
   * Get the (root) schematic as a string.
   */
  getOutputString() {
    if (this.schematicSheetPlan.isHierarchical) {
      this.buildAll();
      return this.files[0].content;
    }
    return this.ctx.kicadSch.getString();
  }
  /**
   * Returns every KiCad schematic file produced by this converter.
   *
   * For a design with no `schematic_sheet` elements this is a single root file.
   * For a hierarchical design it is the root file (named by
   * `options.schematicFilename`) followed by one child `.kicad_sch` per sheet,
   * each named after its sheet and referenced by the root via `Sheetfile`.
   */
  getOutputFiles(options) {
    if (!this.schematicSheetPlan.isHierarchical) {
      return [
        {
          filename: options.schematicFilename,
          content: this.getOutputString()
        }
      ];
    }
    this.buildAll();
    return this.files.map((file, index) => ({
      filename: index === 0 ? options.schematicFilename : file.entry.filename,
      content: file.content
    }));
  }
  /** Builds the root + child `.kicad_sch` files for a hierarchical design. */
  buildAll() {
    if (this.built) return;
    this.built = true;
    const { rootUuid, root, children } = this.schematicSheetPlan;
    const { nodes: childSheetNodes, extentMm } = buildChildSheetNodes(
      children,
      rootUuid,
      this.options.schematicSheets
    );
    const rootSch = this.buildSheetFile({
      circuitJson: partitionCircuitJsonBySheet(this.circuitJson, null),
      schematicSheetId: null,
      fileUuid: rootUuid,
      symbolInstancePathPrefix: `/${rootUuid}`,
      emitSheetInstances: true,
      childSheetNodes,
      extraPaperExtentMm: extentMm
    });
    this.files.push({
      entry: root,
      kicadSch: rootSch,
      content: rootSch.getString()
    });
    for (const child of children) {
      const childSch = this.buildSheetFile({
        circuitJson: partitionCircuitJsonBySheet(
          this.circuitJson,
          child.schematicSheetId
        ),
        schematicSheetId: child.schematicSheetId,
        fileUuid: child.fileUuid,
        symbolInstancePathPrefix: `/${rootUuid}/${child.sheetNodeUuid}`,
        emitSheetInstances: false
      });
      this.files.push({
        entry: child,
        kicadSch: childSch,
        content: childSch.getString()
      });
    }
  }
  /** Builds one child/root `.kicad_sch` for a sheet, run to completion. */
  buildSheetFile(options) {
    const {
      circuitJson,
      schematicSheetId,
      fileUuid,
      symbolInstancePathPrefix,
      emitSheetInstances,
      childSheetNodes,
      extraPaperExtentMm
    } = options;
    const kicadSchematicScaleFactor = DEFAULT_SCHEMATIC_SCALE_FACTOR;
    const db = cju(circuitJson);
    const { center, bounds } = getSchematicBoundsAndCenter(db);
    const schematicWidthMm = (bounds.maxX - bounds.minX) * kicadSchematicScaleFactor;
    const schematicHeightMm = (bounds.maxY - bounds.minY) * kicadSchematicScaleFactor;
    const { paperSize: fittedPaperSize, contentCenter: fittedContentCenter } = getSchematicPageLayout({
      contentWidthMm: schematicWidthMm,
      contentHeightMm: schematicHeightMm,
      extraPaperExtentMm
    });
    const paperSize = this.options.paperSize ?? fittedPaperSize;
    const sheetOptions = getSchematicSheetOptions({
      options: this.options,
      schematicSheetId
    });
    const contentCenter = this.options.paperSize ? { x: paperSize.width / 2, y: paperSize.height / 2 } : fittedContentCenter;
    if (this.options.titleBlock) {
      contentCenter.y -= TITLE_BLOCK_CONTENT_OFFSET_MM;
    }
    const ctx = {
      db,
      circuitJson,
      kicadSch: new KicadSch({
        generator: "circuit-json-to-kicad",
        generatorVersion: "0.0.1",
        titleBlock: createKicadSchematicTitleBlock(this.options.titleBlock)
      }),
      kicadSchematicScaleFactor,
      schematicPaperSize: paperSize,
      c2kMatSch: createSchematicTransform({
        center,
        circuitOrigin: sheetOptions?.circuitOrigin,
        contentCenter,
        scaleFactor: kicadSchematicScaleFactor
      }),
      schematicFileUuid: fileUuid,
      symbolInstancePathPrefix
    };
    const stages = [
      new InitializeSchematicStage(circuitJson, ctx),
      new AddLibrarySymbolsStage(circuitJson, ctx),
      new AddSchematicSymbolsStage(circuitJson, ctx),
      new AddSchematicNetLabelsStage(circuitJson, ctx),
      new AddSchematicTracesStage(circuitJson, ctx),
      new AddSchematicGraphicsStage(circuitJson, ctx)
    ];
    if (emitSheetInstances) {
      stages.push(new AddSheetInstancesStage(circuitJson, ctx));
    }
    for (const stage of stages) stage.runUntilFinished();
    const kicadSch = ctx.kicadSch;
    if (childSheetNodes && childSheetNodes.length > 0) {
      kicadSch.sheets = childSheetNodes;
    }
    return kicadSch;
  }
};

// lib/pcb/CircuitJsonToKicadPcbConverter.ts
import { KicadPcb as KicadPcb2 } from "kicadts";
import { cju as cju2 } from "@tscircuit/circuit-json-util";
import { compose as compose7, translate as translate7, scale as scale5 } from "transformation-matrix";

// lib/pcb/stages/AddCopperPoursStage.ts
import earcut from "earcut";
import {
  Layer,
  Pts as Pts4,
  Xy as Xy4,
  Zone,
  ZoneConnectPads,
  ZoneFill,
  ZoneFilledPolygon,
  ZoneHatch,
  ZonePolygon
} from "kicadts";
import {
  applyToPoint as applyToPoint11,
  compose as compose3,
  rotate,
  translate as translate3
} from "transformation-matrix";

// lib/pcb/utils/layerMapping.ts
var circuitJsonLayerToKicadLayer = {
  top: "F.Cu",
  bottom: "B.Cu",
  inner1: "In1.Cu",
  inner2: "In2.Cu",
  inner3: "In3.Cu",
  inner4: "In4.Cu",
  inner5: "In5.Cu",
  inner6: "In6.Cu",
  inner7: "In7.Cu",
  inner8: "In8.Cu"
};
function getKicadLayer(circuitJsonLayer) {
  if (!circuitJsonLayer) return "F.Cu";
  const mappedLayer = circuitJsonLayerToKicadLayer[circuitJsonLayer];
  if (mappedLayer) return mappedLayer;
  const innerLayerMatch = circuitJsonLayer.match(/^inner(\d+)$/);
  if (innerLayerMatch?.[1]) return `In${innerLayerMatch[1]}.Cu`;
  return circuitJsonLayer;
}
function getKicadCopperLayerIndex(layerName, numLayers) {
  if (layerName === "F.Cu") return 0;
  if (layerName === "B.Cu") return 31;
  const match = layerName.match(/^In(\d+)\.Cu$/);
  if (match?.[1]) {
    return parseInt(match[1], 10);
  }
  return 0;
}
function getViaLayers(numLayers) {
  const layers = ["F.Cu"];
  for (let i = 1; i < numLayers - 1; i++) {
    layers.push(`In${i}.Cu`);
  }
  layers.push("B.Cu");
  return layers;
}
function getViaLayerSpan(kicadLayers, numLayers) {
  if (kicadLayers.length <= 1) return kicadLayers;
  let top = kicadLayers[0];
  let bottom = kicadLayers[0];
  let topIndex = getKicadCopperLayerIndex(top, numLayers);
  let bottomIndex = topIndex;
  for (const layer of kicadLayers) {
    const index = getKicadCopperLayerIndex(layer, numLayers);
    if (index < topIndex) {
      topIndex = index;
      top = layer;
    }
    if (index > bottomIndex) {
      bottomIndex = index;
      bottom = layer;
    }
  }
  return top === bottom ? [top] : [top, bottom];
}

// lib/pcb/stages/utils/generateDeterministicUuid.ts
function simpleHash(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash = hash & hash;
  }
  let result = "";
  for (let i = 0; i < 4; i++) {
    let h = hash;
    for (let j = 0; j < str.length; j++) {
      h = (h << 5) - h + str.charCodeAt(j) + i * 31;
      h = h & h;
    }
    result += Math.abs(h).toString(16).padStart(8, "0");
  }
  return result;
}
function generateDeterministicUuid(data) {
  const hash = simpleHash(data);
  return `${hash.slice(0, 8)}-${hash.slice(8, 12)}-${hash.slice(12, 16)}-${hash.slice(16, 20)}-${hash.slice(20, 32)}`;
}

// lib/pcb/stages/AddCopperPoursStage.ts
var isPcbCopperPour = (element) => element.type === "pcb_copper_pour";
var getCopperPours = (circuitJson) => circuitJson.filter(isPcbCopperPour);
var getCopperPourNetInfo = (pour, ctx) => {
  let connectivityKey = pour.source_net_id;
  if (connectivityKey) {
    const sourceNet = ctx.db.source_net?.get(connectivityKey);
    connectivityKey = sourceNet?.subcircuit_connectivity_map_key || sourceNet?.source_net_id;
  }
  if (!connectivityKey) return void 0;
  return ctx.pcbNetMap?.get(connectivityKey);
};
var convertPointsToKicadXy = (points, c2kMatPcb) => {
  return (points ?? []).map((point) => {
    const transformedPoint = applyToPoint11(c2kMatPcb, point);
    return new Xy4(transformedPoint.x, transformedPoint.y);
  });
};
var rotateRingToStartAtTopRight = (points) => {
  if (points.length < 2) return points;
  let startIndex = 0;
  for (let i = 1; i < points.length; i++) {
    const point = points[i];
    const startPoint = points[startIndex];
    if (!point || !startPoint) continue;
    if (point.x > startPoint.x || point.x === startPoint.x && point.y > startPoint.y) {
      startIndex = i;
    }
  }
  return [...points.slice(startIndex), ...points.slice(0, startIndex)];
};
var removeConsecutiveDuplicatePoints = (points) => {
  const dedupedPoints = [];
  for (const point of points) {
    const lastPoint = dedupedPoints[dedupedPoints.length - 1];
    if (lastPoint?.x === point.x && lastPoint.y === point.y) {
      continue;
    }
    dedupedPoints.push(point);
  }
  return dedupedPoints;
};
var removeRepeatedClosingPoint = (points) => {
  const dedupedPoints = [...points];
  const firstPoint = dedupedPoints[0];
  const lastPoint = dedupedPoints[dedupedPoints.length - 1];
  if (firstPoint && lastPoint && dedupedPoints.length > 1 && firstPoint.x === lastPoint.x && firstPoint.y === lastPoint.y) {
    dedupedPoints.pop();
  }
  return dedupedPoints;
};
var getRectRingPoints = (pour, c2kMatPcb) => {
  const ccwRotationDegrees = pour.rotation ?? 0;
  const cornerTransform = compose3(
    translate3(pour.center.x, pour.center.y),
    rotate(ccwRotationDegrees * Math.PI / 180)
  );
  const halfWidth = pour.width / 2;
  const halfHeight = pour.height / 2;
  const corners = [
    { x: -halfWidth, y: -halfHeight },
    { x: halfWidth, y: -halfHeight },
    { x: halfWidth, y: halfHeight },
    { x: -halfWidth, y: halfHeight }
  ].map((corner) => applyToPoint11(cornerTransform, corner));
  return convertPointsToKicadXy(corners, c2kMatPcb);
};
var getPolygonRingPoints = (pour, c2kMatPcb) => removeRepeatedClosingPoint(
  removeConsecutiveDuplicatePoints(
    rotateRingToStartAtTopRight(
      convertPointsToKicadXy(pour.points, c2kMatPcb)
    )
  )
);
var getBrepZoneRings = (pour, c2kMatPcb) => [
  removeRepeatedClosingPoint(
    removeConsecutiveDuplicatePoints(
      rotateRingToStartAtTopRight(
        convertPointsToKicadXy(pour.brep_shape.outer_ring.vertices, c2kMatPcb)
      )
    )
  ),
  pour.brep_shape.inner_rings.map(
    (ring) => removeRepeatedClosingPoint(
      removeConsecutiveDuplicatePoints(
        rotateRingToStartAtTopRight(
          convertPointsToKicadXy(ring.vertices, c2kMatPcb)
        )
      )
    )
  ).filter((ringPoints) => ringPoints.length >= 3)
];
var getCopperPourZoneRings = (pour, c2kMatPcb) => {
  switch (pour.shape) {
    case "rect":
      return [
        removeRepeatedClosingPoint(
          removeConsecutiveDuplicatePoints(
            rotateRingToStartAtTopRight(getRectRingPoints(pour, c2kMatPcb))
          )
        ),
        []
      ];
    case "polygon":
      return [getPolygonRingPoints(pour, c2kMatPcb), []];
    case "brep":
      return getBrepZoneRings(pour, c2kMatPcb);
  }
};
var createZonePolygons = (outerRing, innerRings) => {
  const polygons = [];
  if (outerRing.length >= 3) {
    polygons.push(new ZonePolygon(new Pts4(outerRing)));
  }
  for (const innerRing of innerRings) {
    if (innerRing.length < 3) continue;
    polygons.push(new ZonePolygon(new Pts4(innerRing)));
  }
  return polygons;
};
var getTriangleArea = (a, b, c) => Math.abs((a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y)) / 2);
var createZoneFilledPolygons = (outerRing, innerRings, kicadLayer) => {
  if (outerRing.length < 3) {
    return [];
  }
  const layer = new Layer([kicadLayer]);
  if (innerRings.length === 0) {
    return [
      new ZoneFilledPolygon({
        layer,
        pts: new Pts4(outerRing)
      })
    ];
  }
  const flattenedPoints = [];
  const holeIndices = [];
  let pointIndex = 0;
  const addRing = (ring) => {
    for (const point of ring) {
      flattenedPoints.push(point.x, point.y);
    }
    pointIndex += ring.length;
  };
  addRing(outerRing);
  for (const innerRing of innerRings) {
    holeIndices.push(pointIndex);
    addRing(innerRing);
  }
  const triangleIndices = earcut(flattenedPoints, holeIndices, 2);
  const filledPolygons = [];
  for (let i = 0; i < triangleIndices.length; i += 3) {
    const trianglePoints = [];
    for (let offset = 0; offset < 3; offset++) {
      const pointOffset = triangleIndices[i + offset] * 2;
      const x = flattenedPoints[pointOffset];
      const y = flattenedPoints[pointOffset + 1];
      if (x === void 0 || y === void 0) continue;
      trianglePoints.push(new Xy4(x, y));
    }
    if (trianglePoints.length !== 3 || getTriangleArea(
      trianglePoints[0],
      trianglePoints[1],
      trianglePoints[2]
    ) === 0) {
      continue;
    }
    filledPolygons.push(
      new ZoneFilledPolygon({
        layer,
        pts: new Pts4(trianglePoints)
      })
    );
  }
  return filledPolygons;
};
var AddCopperPoursStage = class extends ConverterStage {
  _step() {
    const { kicadPcb, c2kMatPcb } = this.ctx;
    if (!kicadPcb) {
      throw new Error("KicadPcb instance not initialized in context");
    }
    if (!c2kMatPcb) {
      throw new Error("PCB transformation matrix not initialized in context");
    }
    const copperPours = getCopperPours(this.input);
    for (const pour of copperPours) {
      const [outerRing, innerRings] = getCopperPourZoneRings(pour, c2kMatPcb);
      if (outerRing.length < 3) continue;
      const netInfo = getCopperPourNetInfo(pour, this.ctx);
      const kicadLayer = getKicadLayer(pour.layer);
      const zone = new Zone({
        net: netInfo?.id ?? 0,
        netName: netInfo?.name ?? "",
        layer: kicadLayer,
        uuid: generateDeterministicUuid(`zone:${pour.pcb_copper_pour_id}`),
        hatch: new ZoneHatch("edge", 0.5),
        connectPads: new ZoneConnectPads({ enabled: true, clearance: 0.15 }),
        minThickness: 0.25,
        filledAreasThickness: false,
        fill: new ZoneFill({
          filled: true,
          thermalGap: 0.5,
          thermalBridgeWidth: 0.5,
          islandRemovalMode: 0
        }),
        polygons: createZonePolygons(outerRing, innerRings),
        filledPolygons: createZoneFilledPolygons(
          outerRing,
          innerRings,
          kicadLayer
        )
      });
      const zones = kicadPcb.zones;
      zones.push(zone);
      kicadPcb.zones = zones;
    }
    this.finished = true;
  }
  getOutput() {
    return this.ctx.kicadPcb;
  }
};

// lib/pcb/stages/AddKeepoutsStage.ts
import { Pts as Pts5, Xy as Xy5, Zone as Zone2, ZoneKeepout, ZonePolygon as ZonePolygon2 } from "kicadts";
import { applyToPoint as applyToPoint12 } from "transformation-matrix";

// lib/pcb/stages/utils/circleToPolygon.ts
var CIRCLE_APPROX_SEGMENT_LENGTH = 0.2;
var CIRCLE_APPROX_MIN_STEPS = 16;
var CIRCLE_APPROX_MAX_STEPS = 128;
var circleToPolygon = (center, radius) => {
  const circumference = 2 * Math.PI * radius;
  let steps = Math.ceil(circumference / CIRCLE_APPROX_SEGMENT_LENGTH);
  steps = Math.max(
    CIRCLE_APPROX_MIN_STEPS,
    Math.min(CIRCLE_APPROX_MAX_STEPS, steps)
  );
  const pts = [];
  for (let i = 0; i < steps; i++) {
    const angle = i / steps * Math.PI * 2;
    pts.push([
      center.x + radius * Math.cos(angle),
      center.y + radius * Math.sin(angle)
    ]);
  }
  return pts;
};

// lib/pcb/stages/AddKeepoutsStage.ts
var isPcbKeepout = (element) => element.type === "pcb_keepout";
var getKeepouts = (circuitJson) => circuitJson.filter(isPcbKeepout);
var AddKeepoutsStage = class extends ConverterStage {
  _step() {
    const { kicadPcb, c2kMatPcb } = this.ctx;
    if (!kicadPcb)
      throw new Error("KicadPcb instance not initialized in context");
    if (!c2kMatPcb)
      throw new Error("PCB transformation matrix not initialized in context");
    const keepouts = getKeepouts(this.input);
    for (const keepout of keepouts) {
      const kicadLayers = keepout.layers.map(getKicadLayer);
      let rawPoints;
      if (keepout.shape === "rect") {
        const halfW = keepout.width / 2;
        const halfH = keepout.height / 2;
        rawPoints = [
          { x: keepout.center.x - halfW, y: keepout.center.y - halfH },
          { x: keepout.center.x + halfW, y: keepout.center.y - halfH },
          { x: keepout.center.x + halfW, y: keepout.center.y + halfH },
          { x: keepout.center.x - halfW, y: keepout.center.y + halfH }
        ];
      } else if (keepout.shape === "circle") {
        rawPoints = circleToPolygon(keepout.center, keepout.radius).map(
          ([x, y]) => ({ x, y })
        );
      } else {
        rawPoints = keepout.outline;
      }
      const kicadPoints = rawPoints.map((p) => {
        const t = applyToPoint12(c2kMatPcb, p);
        return new Xy5(t.x, t.y);
      });
      const zone = new Zone2({
        net: 0,
        netName: "",
        layers: kicadLayers,
        uuid: generateDeterministicUuid(`keepout:${keepout.pcb_keepout_id}`),
        keepout: new ZoneKeepout({
          tracks: "not_allowed",
          vias: "not_allowed",
          pads: "not_allowed",
          copperpour: "not_allowed",
          footprints: "not_allowed"
        }),
        polygons: [new ZonePolygon2(new Pts5(kicadPoints))]
      });
      const zones = kicadPcb.zones;
      zones.push(zone);
      kicadPcb.zones = zones;
    }
    this.finished = true;
  }
  getOutput() {
    return this.ctx.kicadPcb;
  }
};

// lib/pcb/stages/InitializePcbStage.ts
import {
  Paper as Paper2,
  PcbLayers,
  PcbLayerDefinition,
  PcbGeneral,
  Setup
} from "kicadts";
var InitializePcbStage = class extends ConverterStage {
  _step() {
    const { kicadPcb, db } = this.ctx;
    if (!kicadPcb) {
      throw new Error("KicadPcb instance not initialized in context");
    }
    const pcbBoard = db.pcb_board?.list()?.[0];
    const numLayers = pcbBoard?.num_layers ?? 2;
    this.ctx.numLayers = numLayers;
    kicadPcb.version = 20241229;
    const paper = new Paper2();
    paper.size = "A4";
    kicadPcb.paper = paper;
    const general = new PcbGeneral();
    general.thickness = pcbBoard?.thickness ?? 1.6;
    kicadPcb.general = general;
    const setup = new Setup();
    setup.padToMaskClearance = 0;
    kicadPcb.setup = setup;
    const layers = new PcbLayers();
    const layerDefinitions = [
      // Front copper layer
      new PcbLayerDefinition({ index: 0, name: "F.Cu", type: "signal" })
    ];
    for (let i = 1; i < numLayers - 1; i++) {
      layerDefinitions.push(
        new PcbLayerDefinition({ index: i, name: `In${i}.Cu`, type: "signal" })
      );
    }
    layerDefinitions.push(
      new PcbLayerDefinition({ index: 31, name: "B.Cu", type: "signal" })
    );
    layerDefinitions.push(
      new PcbLayerDefinition({ index: 32, name: "B.Adhes", type: "user" }),
      new PcbLayerDefinition({ index: 33, name: "F.Adhes", type: "user" }),
      new PcbLayerDefinition({ index: 34, name: "B.Paste", type: "user" }),
      new PcbLayerDefinition({ index: 35, name: "F.Paste", type: "user" }),
      new PcbLayerDefinition({ index: 36, name: "B.SilkS", type: "user" }),
      new PcbLayerDefinition({ index: 37, name: "F.SilkS", type: "user" }),
      new PcbLayerDefinition({ index: 38, name: "B.Mask", type: "user" }),
      new PcbLayerDefinition({ index: 39, name: "F.Mask", type: "user" }),
      // Drawing layers
      new PcbLayerDefinition({ index: 40, name: "Dwgs.User", type: "user" }),
      new PcbLayerDefinition({ index: 41, name: "Cmts.User", type: "user" }),
      new PcbLayerDefinition({ index: 42, name: "Eco1.User", type: "user" }),
      new PcbLayerDefinition({ index: 43, name: "Eco2.User", type: "user" }),
      new PcbLayerDefinition({ index: 44, name: "Edge.Cuts", type: "user" }),
      new PcbLayerDefinition({ index: 45, name: "Margin", type: "user" }),
      // Fabrication layers
      new PcbLayerDefinition({ index: 46, name: "B.CrtYd", type: "user" }),
      new PcbLayerDefinition({ index: 47, name: "F.CrtYd", type: "user" }),
      new PcbLayerDefinition({ index: 48, name: "B.Fab", type: "user" }),
      new PcbLayerDefinition({ index: 49, name: "F.Fab", type: "user" })
    );
    layers.definitions = layerDefinitions;
    kicadPcb.layers = layers;
    this.finished = true;
  }
  getOutput() {
    return this.ctx.kicadPcb;
  }
};

// lib/pcb/stages/AddNetsStage.ts
import { PcbNet } from "kicadts";
var AddNetsStage = class extends ConverterStage {
  _step() {
    const { kicadPcb } = this.ctx;
    if (!kicadPcb) {
      throw new Error("KicadPcb instance not initialized in context");
    }
    this.ctx.pcbNetMap = /* @__PURE__ */ new Map();
    const netNameByKey = /* @__PURE__ */ new Map();
    const sourceNets = this.ctx.db.source_net?.list() ?? [];
    for (const sourceNet of sourceNets) {
      const connectivityKey = sourceNet.subcircuit_connectivity_map_key || sourceNet.source_net_id;
      if (!connectivityKey) continue;
      const candidateName = sourceNet.name || sourceNet.source_net_id || "";
      const netName = candidateName && candidateName.trim().length > 0 ? candidateName : connectivityKey;
      netNameByKey.set(connectivityKey, netName);
    }
    const sourceTraces = this.ctx.db.source_trace?.list() ?? [];
    for (const sourceTrace of sourceTraces) {
      let connectivityKey = sourceTrace.subcircuit_connectivity_map_key;
      if (!connectivityKey && sourceTrace.connected_source_net_ids?.length) {
        for (const sourceNetId of sourceTrace.connected_source_net_ids) {
          const connectedNet = this.ctx.db.source_net?.get(sourceNetId);
          if (connectedNet?.subcircuit_connectivity_map_key && connectedNet.subcircuit_connectivity_map_key.length > 0) {
            connectivityKey = connectedNet.subcircuit_connectivity_map_key;
            break;
          }
        }
      }
      if (!connectivityKey) continue;
      if (!netNameByKey.has(connectivityKey)) {
        const candidateName = sourceTrace.display_name || sourceTrace.source_trace_id || "";
        const netName = candidateName && candidateName.trim().length > 0 ? candidateName : connectivityKey;
        netNameByKey.set(connectivityKey, netName);
      }
    }
    const sortedEntries = Array.from(netNameByKey.entries()).sort(
      (a, b) => a[0].localeCompare(b[0])
    );
    const nets = [];
    nets.push(new PcbNet(0, ""));
    let netNumber = 1;
    for (const [connectivityKey, netName] of sortedEntries) {
      const pcbNet = new PcbNet(netNumber, netName);
      nets.push(pcbNet);
      const netInfo = { id: netNumber, name: netName };
      this.ctx.pcbNetMap.set(connectivityKey, netInfo);
      netNumber++;
    }
    kicadPcb.nets = nets;
    this.finished = true;
  }
  getOutput() {
    return this.ctx.kicadPcb;
  }
};

// lib/pcb/stages/AddFootprintsStage.ts
import { Footprint as Footprint3, FootprintModel as FootprintModel4, FootprintAttr as FootprintAttr3 } from "kicadts";

// lib/kicad-library/stages/ExtractFootprintsStage.ts
import {
  parseKicadSexpr,
  KicadPcb,
  FootprintModel,
  At as At2,
  EmbeddedFonts as EmbeddedFonts4,
  FootprintAttr,
  Property,
  TextEffects as TextEffects8,
  TextEffectsFont as TextEffectsFont8
} from "kicadts";
var MODEL_CDN_BASE_URL = "https://modelcdn.tscircuit.com/jscad_models";
var KICAD_FP_VERSION = 20240108;
var KICAD_FP_GENERATOR = "pcbnew";
var KICAD_FP_GENERATOR_VERSION = "8.0";
function getBasename(filePath) {
  const parts = filePath.split(/[/\\]/);
  const base = parts[parts.length - 1] || filePath;
  return base.split("?")[0] || base;
}
var ExtractFootprintsStage = class extends ConverterStage {
  /**
   * Iterates cad_components to build:
   * - customFootprintNames: footprints WITHOUT footprinter_string (custom inline)
   * - footprinterStrings: map of footprint name -> footprinter_string (for CDN model fallback)
   */
  classifyFootprints() {
    const customFootprintNames = /* @__PURE__ */ new Set();
    const footprinterStrings = /* @__PURE__ */ new Map();
    const cadComponents = this.ctx.db.cad_component?.list() ?? [];
    const sourceComponents = this.ctx.db.source_component;
    for (const cadComponent of cadComponents) {
      const sourceComp = cadComponent.source_component_id ? sourceComponents?.get(cadComponent.source_component_id) : null;
      if (!sourceComp) continue;
      const footprintName = getKicadCompatibleComponentName(
        sourceComp,
        cadComponent
      );
      if (cadComponent.footprinter_string) {
        footprinterStrings.set(footprintName, cadComponent.footprinter_string);
      } else {
        customFootprintNames.add(footprintName);
        const pcbComp = this.ctx.circuitJson.find(
          (el) => el.type === "pcb_component" && el.source_component_id === cadComponent.source_component_id
        );
        if (pcbComp && pcbComp.type === "pcb_component" && pcbComp.metadata?.kicad_footprint?.footprintName) {
          customFootprintNames.add(
            pcbComp.metadata.kicad_footprint.footprintName
          );
        }
      }
    }
    return { customFootprintNames, footprinterStrings };
  }
  _step() {
    const kicadPcbString = this.ctx.kicadPcbString;
    const fpLibraryName = this.ctx.fpLibraryName ?? "tscircuit";
    if (!kicadPcbString) {
      throw new Error(
        "PCB content not available. Run GenerateKicadSchAndPcbStage first."
      );
    }
    const { customFootprintNames, footprinterStrings } = this.classifyFootprints();
    const uniqueFootprints = /* @__PURE__ */ new Map();
    try {
      const parsed = parseKicadSexpr(kicadPcbString);
      const pcb = parsed.find(
        (node) => node instanceof KicadPcb
      );
      if (!pcb) {
        this.ctx.footprintEntries = [];
        this.finished = true;
        return;
      }
      const footprints = pcb.footprints ?? [];
      for (const footprint of footprints) {
        const footprintEntry = this.sanitizeFootprint({
          footprint,
          fpLibraryName,
          customFootprintNames,
          footprinterStrings
        });
        if (!uniqueFootprints.has(footprintEntry.footprintName)) {
          uniqueFootprints.set(footprintEntry.footprintName, footprintEntry);
        }
      }
    } catch (error) {
      console.warn("Failed to parse PCB for footprint extraction:", error);
    }
    this.ctx.footprintEntries = Array.from(uniqueFootprints.values());
    this.finished = true;
  }
  sanitizeFootprint({
    footprint,
    fpLibraryName,
    customFootprintNames,
    footprinterStrings
  }) {
    const libraryLink = footprint.libraryLink ?? "footprint";
    const parts = libraryLink.split(":");
    const footprintName = (parts.length > 1 ? parts[1] : parts[0])?.replace(/[\\\/]/g, "-").trim() || "footprint";
    const isBuiltin = !customFootprintNames.has(footprintName);
    footprint.libraryLink = footprintName;
    footprint.position = At2.from([0, 0, 0]);
    footprint.locked = false;
    footprint.placed = false;
    footprint.version = KICAD_FP_VERSION;
    footprint.generator = KICAD_FP_GENERATOR;
    footprint.generatorVersion = KICAD_FP_GENERATOR_VERSION;
    if (!footprint.descr) {
      footprint.descr = "";
    }
    if (!footprint.tags) {
      footprint.tags = "";
    }
    if (!footprint.embeddedFonts) {
      footprint.embeddedFonts = new EmbeddedFonts4(false);
    }
    if (!footprint.attr) {
      const attr = new FootprintAttr();
      const padTypes = (footprint.fpPads ?? []).map((pad) => pad.padType);
      if (padTypes.some((padType) => padType.includes("thru_hole"))) {
        attr.type = "through_hole";
      } else if (padTypes.some((padType) => padType.includes("smd"))) {
        attr.type = "smd";
      }
      footprint.attr = attr;
    }
    footprint.uuid = void 0;
    footprint.path = void 0;
    footprint.sheetfile = void 0;
    footprint.sheetname = void 0;
    const defaultFont = new TextEffectsFont8();
    defaultFont.size = { width: 1.27, height: 1.27 };
    defaultFont.thickness = 0.15;
    const defaultEffects = new TextEffects8({ font: defaultFont });
    const fpPads = footprint.fpPads ?? [];
    let minY = 0;
    let maxY = 0;
    for (const pad of fpPads) {
      const at = pad.at;
      const size = pad.size;
      if (at && size) {
        const padY = at.y ?? 0;
        const padHeight = size.height ?? 0;
        const padTop = padY - padHeight / 2;
        const padBottom = padY + padHeight / 2;
        minY = Math.min(minY, padTop);
        maxY = Math.max(maxY, padBottom);
      }
    }
    const refY = minY - 0.5;
    const valY = maxY + 0.5;
    footprint.properties = [
      new Property({
        key: "Reference",
        value: "REF**",
        position: [0, refY, 0],
        layer: "F.SilkS",
        uuid: generateDeterministicUuid(`${footprintName}-property-Reference`),
        effects: defaultEffects
      }),
      new Property({
        key: "Value",
        value: "Val**",
        position: [0, valY, 0],
        layer: "F.Fab",
        uuid: generateDeterministicUuid(`${footprintName}-property-Value`),
        effects: defaultEffects
      }),
      new Property({
        key: "Datasheet",
        value: "",
        position: [0, 0, 0],
        layer: "F.Fab",
        hidden: true,
        uuid: generateDeterministicUuid(`${footprintName}-property-Datasheet`),
        effects: defaultEffects
      }),
      new Property({
        key: "Description",
        value: "",
        position: [0, 0, 0],
        layer: "F.Fab",
        hidden: true,
        uuid: generateDeterministicUuid(
          `${footprintName}-property-Description`
        ),
        effects: defaultEffects
      })
    ];
    const texts = footprint.fpTexts ?? [];
    for (const text of texts) {
      text.uuid = void 0;
      if (text.type === "reference") {
        text.text = "REF**";
      } else if (text.type === "value" && text.text.trim().length === 0) {
        text.text = footprintName;
      }
    }
    footprint.fpTexts = texts;
    const pads = footprint.fpPads ?? [];
    for (let i = 0; i < pads.length; i++) {
      const pad = pads[i];
      if (pad) {
        pad.uuid = generateDeterministicUuid(
          `${footprintName}-pad-${pad.number ?? i}`
        );
        pad.net = void 0;
      }
    }
    footprint.fpPads = pads;
    const models = footprint.models ?? [];
    const updatedModels = [];
    const modelFiles = [];
    for (const model of models) {
      if (model.path) {
        const modelFilename = getBasename(model.path);
        const isRemote = model.path.startsWith("http://modelcdn.tscircuit.com") || model.path.startsWith("https://modelcdn.tscircuit.com");
        const shapesFolder = isRemote ? "tscircuit_builtin" : fpLibraryName;
        const newPath = `../../3dmodels/${shapesFolder}.3dshapes/${modelFilename}`;
        const newModel = new FootprintModel(newPath);
        if (model.offset) newModel.offset = model.offset;
        if (model.scale) newModel.scale = model.scale;
        if (model.rotate) newModel.rotate = model.rotate;
        updatedModels.push(newModel);
        modelFiles.push(model.path.split("?")[0] ?? model.path);
      }
    }
    if (updatedModels.length === 0) {
      const footprinterString = footprinterStrings.get(footprintName);
      if (footprinterString) {
        const cdnUrl = `${MODEL_CDN_BASE_URL}/${footprinterString}.step`;
        const cdnModelFilename = getBasename(cdnUrl);
        const newPath = `../../3dmodels/tscircuit_builtin.3dshapes/${cdnModelFilename}`;
        updatedModels.push(new FootprintModel(newPath));
        modelFiles.push(cdnUrl);
      }
    }
    footprint.models = updatedModels;
    return {
      footprintName,
      kicadModString: footprint.getString(),
      model3dSourcePaths: modelFiles,
      isBuiltin
    };
  }
  getOutput() {
    return this.ctx.libraryOutput;
  }
};

// lib/pcb/stages/AddFootprintsStage.ts
import { applyToPoint as applyToPoint23 } from "transformation-matrix";

// lib/pcb/stages/utils/applyMetadataToFootprint.ts
import {
  Property as Property2,
  TextEffects as TextEffects9,
  TextEffectsFont as TextEffectsFont9,
  EmbeddedFonts as EmbeddedFonts5,
  FootprintModel as FootprintModel2,
  FootprintAttr as FootprintAttr2
} from "kicadts";
function createTextEffects2(metadataEffects) {
  const font = new TextEffectsFont9();
  if (metadataEffects?.font?.size) {
    font.size = {
      width: Number(metadataEffects.font.size.x),
      height: Number(metadataEffects.font.size.y)
    };
  } else {
    font.size = { width: 1.27, height: 1.27 };
  }
  if (metadataEffects?.font?.thickness !== void 0) {
    font.thickness = Number(metadataEffects.font.thickness);
  } else {
    font.thickness = 0.15;
  }
  return new TextEffects9({ font });
}
function applyMetadataToFootprint({
  footprint,
  metadata,
  componentProperty
}) {
  let newProperties = [];
  const refMeta = metadata?.properties?.Reference;
  newProperties.push(
    new Property2({
      key: "Reference",
      value: refMeta?.value ?? componentProperty.reference,
      position: refMeta?.at ? [
        Number(refMeta.at.x),
        Number(refMeta.at.y),
        Number(refMeta.at.rotation ?? 0)
      ] : [0, -3, 0],
      layer: refMeta?.layer ?? "F.SilkS",
      uuid: generateDeterministicUuid(
        `${componentProperty.reference}-property-Reference`
      ),
      effects: createTextEffects2(refMeta?.effects),
      hidden: refMeta?.hide ?? true
    })
  );
  const valMeta = metadata?.properties?.Value;
  const valueText = valMeta?.value ?? componentProperty.kicadComponentValue ?? "";
  newProperties.push(
    new Property2({
      key: "Value",
      value: valueText,
      position: valMeta?.at ? [
        Number(valMeta.at.x),
        Number(valMeta.at.y),
        Number(valMeta.at.rotation ?? 0)
      ] : [0, 3, 0],
      layer: valMeta?.layer ?? "F.Fab",
      uuid: generateDeterministicUuid(
        `${componentProperty.reference}-property-Value`
      ),
      effects: createTextEffects2(valMeta?.effects),
      hidden: valMeta?.hide ?? true
    })
  );
  const dsMeta = metadata?.properties?.Datasheet;
  newProperties.push(
    new Property2({
      key: "Datasheet",
      value: dsMeta?.value ?? "",
      position: dsMeta?.at ? [
        Number(dsMeta.at.x),
        Number(dsMeta.at.y),
        Number(dsMeta.at.rotation ?? 0)
      ] : [0, 0, 0],
      layer: dsMeta?.layer ?? "F.Fab",
      uuid: generateDeterministicUuid(
        `${componentProperty.reference}-property-Datasheet`
      ),
      effects: createTextEffects2(dsMeta?.effects),
      hidden: dsMeta?.hide ?? true
    })
  );
  const descMeta = metadata?.properties?.Description;
  newProperties.push(
    new Property2({
      key: "Description",
      value: descMeta?.value ?? "",
      position: descMeta?.at ? [
        Number(descMeta.at.x),
        Number(descMeta.at.y),
        Number(descMeta.at.rotation ?? 0)
      ] : [0, 0, 0],
      layer: descMeta?.layer ?? "F.Fab",
      uuid: generateDeterministicUuid(
        `${componentProperty.reference}-property-Description`
      ),
      effects: createTextEffects2(descMeta?.effects),
      hidden: descMeta?.hide ?? true
    })
  );
  newProperties.push(
    new Property2({
      key: "Supplier Part Number",
      value: componentProperty.supplierPartNumber,
      position: [0, 0, 0],
      layer: "F.Fab",
      uuid: generateDeterministicUuid(
        `${componentProperty.reference}-property-SupplierPartNumber`
      ),
      effects: createTextEffects2(),
      hidden: true
    })
  );
  if (componentProperty.manufacturerPartNumber) {
    newProperties.push(
      new Property2({
        key: "MPN",
        value: componentProperty.manufacturerPartNumber,
        position: [0, 0, 0],
        layer: "F.Fab",
        uuid: generateDeterministicUuid(
          `${componentProperty.reference}-property-MPN`
        ),
        effects: createTextEffects2(),
        hidden: true
      })
    );
  }
  footprint.properties = newProperties;
  if (metadata?.attributes) {
    if (!footprint.attr) {
      footprint.attr = new FootprintAttr2();
    }
    if (metadata.attributes.through_hole) {
      footprint.attr.type = "through_hole";
    } else if (metadata.attributes.smd) {
      footprint.attr.type = "smd";
    }
    if (metadata.attributes.exclude_from_pos_files !== void 0) {
      footprint.attr.excludeFromPosFiles = metadata.attributes.exclude_from_pos_files;
    }
    if (metadata.attributes.exclude_from_bom !== void 0) {
      footprint.attr.excludeFromBom = metadata.attributes.exclude_from_bom;
    }
  }
  if (metadata?.footprintName) {
    footprint.libraryLink = metadata.footprintName;
  }
  if (metadata?.layer) {
    footprint.layer = metadata.layer;
  }
  if (metadata?.embeddedFonts !== void 0) {
    footprint.embeddedFonts = new EmbeddedFonts5(metadata.embeddedFonts);
  }
  if (metadata?.model) {
    const model = new FootprintModel2(metadata.model.path);
    if (metadata.model.offset) {
      model.offset = {
        x: Number(metadata.model.offset.x),
        y: Number(metadata.model.offset.y),
        z: Number(metadata.model.offset.z)
      };
    }
    if (metadata.model.scale) {
      model.scale = {
        x: Number(metadata.model.scale.x),
        y: Number(metadata.model.scale.y),
        z: Number(metadata.model.scale.z)
      };
    }
    if (metadata.model.rotate) {
      model.rotate = {
        x: Number(metadata.model.rotate.x),
        y: Number(metadata.model.rotate.y),
        z: Number(metadata.model.rotate.z)
      };
    }
    const existingModels = footprint.models || [];
    footprint.models = [model, ...existingModels];
  }
}

// lib/pcb/stages/utils/getKicadComponentProperty.ts
function getJlcpcbSupplierPartNumber(sourceComp) {
  const jlcpcbPartNumbers = sourceComp.supplier_part_numbers?.jlcpcb;
  return jlcpcbPartNumbers && jlcpcbPartNumbers.length > 0 ? jlcpcbPartNumbers.join(", ") : void 0;
}
function getkicadComponentProperty(sourceComp) {
  const name = sourceComp.name || "?";
  const reference = getReferenceDesignator(sourceComp);
  const supplierPartNumber = getJlcpcbSupplierPartNumber(sourceComp);
  const manufacturerPartNumber = sourceComp.manufacturer_part_number;
  if (sourceComp.ftype === "simple_resistor") {
    const resistor = sourceComp;
    return {
      reference,
      kicadComponentValue: resistor.display_resistance || "R",
      supplierPartNumber,
      manufacturerPartNumber
    };
  }
  if (sourceComp.ftype === "simple_capacitor") {
    const capacitor = sourceComp;
    return {
      reference,
      kicadComponentValue: capacitor.display_capacitance || "C",
      supplierPartNumber,
      manufacturerPartNumber
    };
  }
  if (sourceComp.ftype === "simple_inductor") {
    const inductor = sourceComp;
    return {
      reference,
      kicadComponentValue: inductor.display_inductance || "L",
      supplierPartNumber,
      manufacturerPartNumber
    };
  }
  if (sourceComp.ftype === "simple_diode") {
    return {
      reference,
      kicadComponentValue: "D",
      supplierPartNumber,
      manufacturerPartNumber
    };
  }
  if (sourceComp.ftype === "simple_chip") {
    return {
      reference,
      kicadComponentValue: sourceComp?.manufacturer_part_number,
      supplierPartNumber,
      manufacturerPartNumber
    };
  }
  if (sourceComp.ftype === "simple_led") {
    return {
      reference,
      kicadComponentValue: sourceComp.manufacturer_part_number || "LED",
      supplierPartNumber,
      manufacturerPartNumber
    };
  }
  if (sourceComp.ftype === "simple_switch") {
    return {
      reference,
      kicadComponentValue: sourceComp.manufacturer_part_number || "SW",
      supplierPartNumber,
      manufacturerPartNumber
    };
  }
  if (sourceComp.ftype === "simple_potentiometer") {
    const potentiometer = sourceComp;
    return {
      reference,
      kicadComponentValue: potentiometer.display_max_resistance || "POT",
      supplierPartNumber,
      manufacturerPartNumber
    };
  }
  return {
    reference,
    kicadComponentValue: name,
    supplierPartNumber,
    manufacturerPartNumber
  };
}

// lib/pcb/stages/footprints-stage-converters/convertSilkscreenCircles.ts
import { FpCircle, Stroke as Stroke5 } from "kicadts";
import { applyToPoint as applyToPoint13, identity, rotate as rotate2 } from "transformation-matrix";
function convertSilkscreenCircles(silkscreenCircles, { componentCenter, componentRotation = 0 }) {
  const fpCircles = [];
  const rotationMatrix = componentRotation !== 0 ? rotate2(componentRotation * Math.PI / 180) : identity();
  for (const circle of silkscreenCircles) {
    const relativeCenter = applyToPoint13(rotationMatrix, {
      x: circle.center.x - componentCenter.x,
      y: -(circle.center.y - componentCenter.y)
    });
    const layerMap = {
      top: "F.SilkS",
      bottom: "B.SilkS"
    };
    const kicadLayer = layerMap[circle.layer] || circle.layer || "F.SilkS";
    const fpCircle = new FpCircle({
      center: relativeCenter,
      end: { x: relativeCenter.x + circle.radius, y: relativeCenter.y },
      layer: kicadLayer,
      stroke: new Stroke5(),
      fill: false
    });
    if (fpCircle.stroke) {
      fpCircle.stroke.width = circle.stroke_width || 0.05;
      fpCircle.stroke.type = "default";
    }
    fpCircles.push(fpCircle);
  }
  return fpCircles;
}

// lib/pcb/stages/footprints-stage-converters/convertCourtyardCircles.ts
import { FpCircle as FpCircle2, Stroke as Stroke6 } from "kicadts";
function convertCourtyardCircles(courtyardCircles, componentCenter) {
  const fpCircles = [];
  for (const circle of courtyardCircles) {
    const relX = circle.center.x - componentCenter.x;
    const relY = -(circle.center.y - componentCenter.y);
    const layerMap = {
      top: "F.CrtYd",
      bottom: "B.CrtYd"
    };
    const kicadLayer = layerMap[circle.layer] || "F.CrtYd";
    const fpCircle = new FpCircle2({
      center: { x: relX, y: relY },
      end: { x: relX + circle.radius, y: relY },
      layer: kicadLayer,
      stroke: new Stroke6(),
      fill: false
    });
    if (fpCircle.stroke) {
      fpCircle.stroke.width = 0.05;
      fpCircle.stroke.type = "default";
    }
    fpCircles.push(fpCircle);
  }
  return fpCircles;
}

// lib/pcb/stages/footprints-stage-converters/convertFabricationNoteRects.ts
import { FpRect, Stroke as Stroke7 } from "kicadts";
function convertFabricationNoteRects(fabRects, componentCenter) {
  const fpRects = [];
  for (const rect of fabRects) {
    const relX = rect.center.x - componentCenter.x;
    const relY = -(rect.center.y - componentCenter.y);
    const halfW = rect.width / 2;
    const halfH = rect.height / 2;
    const layerMap = {
      top: "F.Fab",
      bottom: "B.Fab"
    };
    const kicadLayer = layerMap[rect.layer] || rect.layer || "F.Fab";
    const fpRect = new FpRect({
      start: { x: relX - halfW, y: relY - halfH },
      end: { x: relX + halfW, y: relY + halfH },
      layer: kicadLayer,
      stroke: new Stroke7(),
      fill: false
    });
    if (fpRect.stroke) {
      fpRect.stroke.width = rect.stroke_width || 0.1;
      fpRect.stroke.type = "default";
    }
    fpRects.push(fpRect);
  }
  return fpRects;
}

// lib/pcb/stages/footprints-stage-converters/convertNoteRects.ts
import { FpRect as FpRect2, Stroke as Stroke8 } from "kicadts";
function convertNoteRects(noteRects, componentCenter) {
  const fpRects = [];
  for (const rect of noteRects) {
    const relX = rect.center.x - componentCenter.x;
    const relY = -(rect.center.y - componentCenter.y);
    const halfW = rect.width / 2;
    const halfH = rect.height / 2;
    const kicadLayer = "F.Fab";
    const fpRect = new FpRect2({
      start: { x: relX - halfW, y: relY - halfH },
      end: { x: relX + halfW, y: relY + halfH },
      layer: kicadLayer,
      stroke: new Stroke8(),
      fill: false
    });
    if (fpRect.stroke) {
      fpRect.stroke.width = rect.stroke_width || 0.1;
      fpRect.stroke.type = "default";
    }
    fpRects.push(fpRect);
  }
  return fpRects;
}

// lib/pcb/stages/footprints-stage-converters/convertCourtyardRects.ts
import { FpRect as FpRect3, Stroke as Stroke9 } from "kicadts";
function convertCourtyardRects(courtyardRects, componentCenter) {
  const fpRects = [];
  for (const rect of courtyardRects) {
    const relX = rect.center.x - componentCenter.x;
    const relY = -(rect.center.y - componentCenter.y);
    const halfW = rect.width / 2;
    const halfH = rect.height / 2;
    const layerMap = {
      top: "F.CrtYd",
      bottom: "B.CrtYd"
    };
    const kicadLayer = layerMap[rect.layer] || "F.CrtYd";
    const fpRect = new FpRect3({
      start: { x: relX - halfW, y: relY - halfH },
      end: { x: relX + halfW, y: relY + halfH },
      layer: kicadLayer,
      stroke: new Stroke9(),
      fill: false
    });
    if (fpRect.stroke) {
      fpRect.stroke.width = 0.05;
      fpRect.stroke.type = "default";
    }
    fpRects.push(fpRect);
  }
  return fpRects;
}

// lib/pcb/stages/footprints-stage-converters/convertCourtyardOutlines.ts
import { FpPoly, Pts as Pts6, Stroke as Stroke10, Xy as Xy6 } from "kicadts";
import {
  applyToPoint as applyToPoint14,
  compose as compose4,
  rotate as rotate3,
  scale as scale2,
  translate as translate4
} from "transformation-matrix";
function convertCourtyardOutlines(params) {
  const { courtyardOutlines, componentCenter, componentRotation = 0 } = params;
  const fpPolys = [];
  const cj2kicadMatrix = compose4(
    componentRotation !== 0 ? rotate3(componentRotation * Math.PI / 180) : { a: 1, b: 0, c: 0, d: 1, e: 0, f: 0 },
    scale2(1, -1),
    translate4(-componentCenter.x, -componentCenter.y)
  );
  for (const outline of courtyardOutlines) {
    if (!outline.outline || outline.outline.length < 2) continue;
    const layerMap = {
      top: "F.CrtYd",
      bottom: "B.CrtYd"
    };
    const kicadLayer = layerMap[outline.layer] || "F.CrtYd";
    const xyPoints = outline.outline.map((point) => {
      const transformedPoint = applyToPoint14(cj2kicadMatrix, point);
      return new Xy6(transformedPoint.x, transformedPoint.y);
    });
    const fpPoly = new FpPoly();
    fpPoly.points = new Pts6(xyPoints);
    fpPoly.layer = kicadLayer;
    fpPoly.fill = false;
    fpPoly.uuid = generateDeterministicUuid(outline.pcb_courtyard_outline_id);
    const stroke = new Stroke10();
    stroke.width = 0.05;
    stroke.type = "default";
    fpPoly.stroke = stroke;
    fpPolys.push(fpPoly);
  }
  return fpPolys;
}

// lib/pcb/stages/footprints-stage-converters/convertSilkscreenTexts.ts
import "kicadts";

// lib/pcb/stages/utils/CreateFpTextFromCircuitJson.ts
import { FpText, TextEffects as TextEffects10, TextEffectsFont as TextEffectsFont10 } from "kicadts";
import { applyToPoint as applyToPoint15, rotate as rotate4, identity as identity2 } from "transformation-matrix";

// lib/pcb/stages/utils/CreatePcbTextJustify.ts
import { TextEffectsJustify as TextEffectsJustify5 } from "kicadts";
function createPcbTextJustify({
  anchorAlignment = "center",
  kicadLayer,
  isMirrored
}) {
  const justify = new TextEffectsJustify5();
  switch (anchorAlignment) {
    case "top_center":
      justify.vertical = "top";
      break;
    case "top_left":
      justify.horizontal = "left";
      justify.vertical = "top";
      break;
    case "top_right":
      justify.horizontal = "right";
      justify.vertical = "top";
      break;
    case "center_left":
      justify.horizontal = "left";
      break;
    case "center":
      break;
    case "center_right":
      justify.horizontal = "right";
      break;
    case "bottom_center":
      justify.vertical = "bottom";
      break;
    case "bottom_left":
      justify.horizontal = "left";
      justify.vertical = "bottom";
      break;
    case "bottom_right":
      justify.horizontal = "right";
      justify.vertical = "bottom";
      break;
  }
  const shouldMirror = isMirrored ?? kicadLayer.startsWith("B.");
  if (shouldMirror) {
    justify.mirror = true;
  }
  if (!justify.horizontal && !justify.vertical && !justify.mirror) {
    return void 0;
  }
  return justify;
}

// lib/pcb/stages/utils/CreateFpTextFromCircuitJson.ts
function createFpTextFromCircuitJson({
  textElement,
  componentCenter,
  componentRotation = 0
}) {
  if (!textElement.text || !textElement.anchor_position) {
    return null;
  }
  const relativeX = textElement.anchor_position.x - componentCenter.x;
  const relativeY = -(textElement.anchor_position.y - componentCenter.y);
  const rotationMatrix = componentRotation !== 0 ? rotate4(componentRotation * Math.PI / 180) : identity2();
  const rotatedPos = applyToPoint15(rotationMatrix, {
    x: relativeX,
    y: relativeY
  });
  const relativePosition = {
    x: rotatedPos.x,
    y: rotatedPos.y
  };
  const layerMap = {
    top: "F.SilkS",
    bottom: "B.SilkS"
  };
  const kicadLayer = layerMap[textElement.layer] || textElement.layer || "F.SilkS";
  const kicadLayerNames = textElement.is_knockout ? [kicadLayer, "knockout"] : kicadLayer;
  const font = new TextEffectsFont10();
  font.size = {
    width: textElement.font_size || 1,
    height: textElement.font_size || 1
  };
  font.thickness = 0.15;
  const textEffects = new TextEffects10({ font });
  const justify = createPcbTextJustify({
    anchorAlignment: textElement.anchor_alignment,
    kicadLayer,
    isMirrored: textElement.is_mirrored
  });
  if (justify) {
    textEffects.justify = justify;
  }
  const rotation = textElement.ccw_rotation || 0;
  return new FpText({
    type: "user",
    text: textElement.text,
    position: {
      x: relativePosition.x,
      y: relativePosition.y,
      angle: rotation
    },
    layer: kicadLayerNames,
    effects: textEffects
  });
}

// lib/pcb/stages/footprints-stage-converters/convertSilkscreenTexts.ts
function convertSilkscreenTexts(params) {
  const {
    silkscreenTexts,
    componentCenter,
    componentRotation,
    sourceComponentName
  } = params;
  const fpTexts = [];
  for (const textElement of silkscreenTexts) {
    const fpText = createFpTextFromCircuitJson({
      textElement,
      componentCenter,
      componentRotation
    });
    if (fpText) {
      if (sourceComponentName && textElement.text === sourceComponentName) {
        fpText.type = "reference";
      }
      fpTexts.push(fpText);
    }
  }
  return fpTexts;
}

// lib/pcb/stages/footprints-stage-converters/convertSilkscreenPaths.ts
import { FpLine, Stroke as Stroke11 } from "kicadts";
import { applyToPoint as applyToPoint16, identity as identity3, rotate as rotate5 } from "transformation-matrix";
function convertSilkscreenPaths(silkscreenPaths, { componentCenter, componentRotation = 0 }) {
  const fpLines = [];
  const rotationMatrix = componentRotation !== 0 ? rotate5(componentRotation * Math.PI / 180) : identity3();
  for (const path of silkscreenPaths) {
    if (!path.route || path.route.length < 2) continue;
    const layerMap = {
      top: "F.SilkS",
      bottom: "B.SilkS"
    };
    const kicadLayer = layerMap[path.layer] || path.layer || "F.SilkS";
    for (let i = 0; i < path.route.length - 1; i++) {
      const startPoint = path.route[i];
      const endPoint = path.route[i + 1];
      if (!startPoint || !endPoint) continue;
      const startRelative = applyToPoint16(rotationMatrix, {
        x: startPoint.x - componentCenter.x,
        y: -(startPoint.y - componentCenter.y)
      });
      const endRelative = applyToPoint16(rotationMatrix, {
        x: endPoint.x - componentCenter.x,
        y: -(endPoint.y - componentCenter.y)
      });
      const fpLine = new FpLine({
        start: { x: startRelative.x, y: startRelative.y },
        end: { x: endRelative.x, y: endRelative.y },
        layer: kicadLayer,
        stroke: new Stroke11()
      });
      if (fpLine.stroke) {
        fpLine.stroke.width = path.stroke_width || 0.15;
        fpLine.stroke.type = "default";
      }
      fpLines.push(fpLine);
    }
  }
  return fpLines;
}

// lib/pcb/stages/footprints-stage-converters/convertSilkscreenRects.ts
import { FpPoly as FpPoly2, Stroke as Stroke12 } from "kicadts";
import {
  applyToPoint as applyToPoint17,
  compose as compose5,
  rotate as rotate6,
  scale as scale3,
  translate as translate5
} from "transformation-matrix";
var getRectanglePoints = (rect) => {
  const halfWidth = rect.width / 2;
  const halfHeight = rect.height / 2;
  const radius = Math.min(
    Math.max(rect.corner_radius ?? 0, 0),
    halfWidth,
    halfHeight
  );
  if (radius === 0) {
    return [
      { x: -halfWidth, y: -halfHeight },
      { x: halfWidth, y: -halfHeight },
      { x: halfWidth, y: halfHeight },
      { x: -halfWidth, y: halfHeight }
    ];
  }
  const corners = [
    { x: halfWidth - radius, y: halfHeight - radius, start: 0 },
    { x: -halfWidth + radius, y: halfHeight - radius, start: 90 },
    { x: -halfWidth + radius, y: -halfHeight + radius, start: 180 },
    { x: halfWidth - radius, y: -halfHeight + radius, start: 270 }
  ];
  return corners.flatMap(
    (corner) => Array.from({ length: 9 }, (_, index) => {
      const angle = (corner.start + index * 90 / 8) * Math.PI / 180;
      return {
        x: corner.x + radius * Math.cos(angle),
        y: corner.y + radius * Math.sin(angle)
      };
    })
  );
};
function convertSilkscreenRects({
  silkscreenRects,
  componentCenter,
  componentRotation = 0
}) {
  const toLocal = compose5(
    rotate6(componentRotation * Math.PI / 180),
    scale3(1, -1),
    translate5(-componentCenter.x, -componentCenter.y)
  );
  return silkscreenRects.flatMap((rect) => {
    const hasStroke = rect.has_stroke ?? rect.stroke_width > 0;
    if (!hasStroke && !rect.is_filled) return [];
    const fromRectCenter = compose5(
      translate5(rect.center.x, rect.center.y),
      rotate6((rect.ccw_rotation ?? 0) * Math.PI / 180)
    );
    const points = getRectanglePoints(rect).map(
      (point) => applyToPoint17(toLocal, applyToPoint17(fromRectCenter, point))
    );
    const stroke = hasStroke ? new Stroke12() : void 0;
    if (stroke) {
      stroke.width = rect.stroke_width;
      stroke.type = rect.is_stroke_dashed ? "dash" : "default";
    }
    return [
      new FpPoly2({
        points,
        layer: rect.layer === "bottom" ? "B.SilkS" : "F.SilkS",
        stroke,
        fill: rect.is_filled ?? false,
        uuid: generateDeterministicUuid(rect.pcb_silkscreen_rect_id)
      })
    ];
  });
}

// lib/pcb/stages/footprints-stage-converters/convertNoteTexts.ts
import { FpText as FpText3, TextEffects as TextEffects11, TextEffectsFont as TextEffectsFont11 } from "kicadts";
import { applyToPoint as applyToPoint18, rotate as rotate7, identity as identity4 } from "transformation-matrix";
function convertNoteTexts(params) {
  const { noteTexts, componentCenter, componentRotation } = params;
  const fpTexts = [];
  for (const textElement of noteTexts) {
    const relX = textElement.anchor_position.x - componentCenter.x;
    const relY = -(textElement.anchor_position.y - componentCenter.y);
    const rotationMatrix = componentRotation !== 0 ? rotate7(componentRotation * Math.PI / 180) : identity4();
    const rotatedPos = applyToPoint18(rotationMatrix, { x: relX, y: relY });
    const fontSize = textElement.font_size || 1;
    const font = new TextEffectsFont11();
    font.size = { width: fontSize, height: fontSize };
    const textEffects = new TextEffects11({ font });
    const fpText = new FpText3({
      type: "user",
      text: textElement.text,
      position: { x: rotatedPos.x, y: rotatedPos.y, angle: 0 },
      layer: "F.Fab",
      effects: textEffects
    });
    fpTexts.push(fpText);
  }
  return fpTexts;
}

// lib/pcb/stages/footprints-stage-converters/create3DModelsFromCadComponent.ts
import { FootprintModel as FootprintModel3 } from "kicadts";

// lib/pcb/stages/footprints-stage-converters/getKicadFootprintLocalModelTransform.ts
var degreesToRadians = (degrees) => degrees * Math.PI / 180;
function rotatePointAroundAxis(point, axis, degrees) {
  const c = Math.cos(degreesToRadians(degrees));
  const s = Math.sin(degreesToRadians(degrees));
  const { x, y, z } = point;
  if (axis === "x") return { x, y: c * y - s * z, z: s * y + c * z };
  if (axis === "y") return { x: c * x + s * z, y, z: -s * x + c * z };
  return { x: c * x - s * y, y: s * x + c * y, z };
}
function applyCadRotationToPoint(point, rotation) {
  const rotatedAroundZ = rotatePointAroundAxis(point, "z", rotation.z);
  const rotatedAroundX = rotatePointAroundAxis(rotatedAroundZ, "x", -rotation.x);
  return rotatePointAroundAxis(rotatedAroundX, "y", -rotation.y);
}
function getKicadFootprintLocalModelTransform(cadComponent, {
  componentCenter,
  footprintRotation,
  boardLayerZOffset,
  layer
}) {
  const position = cadComponent.position;
  const rotation = cadComponent.rotation ?? {
    x: layer === "bottom" ? 180 : 0,
    y: 0,
    z: 0
  };
  const origin = cadComponent.model_origin_position ?? { x: 0, y: 0, z: 0 };
  const toLocal = (point) => {
    const p = rotatePointAroundAxis(point, "z", -footprintRotation);
    return layer === "bottom" ? { x: p.x, y: -p.y, z: -p.z } : p;
  };
  const modelToLocal = (point) => toLocal(applyCadRotationToPoint(point, rotation));
  const x = modelToLocal({ x: 1, y: 0, z: 0 });
  const y = modelToLocal({ x: 0, y: 1, z: 0 });
  const z = modelToLocal({ x: 0, y: 0, z: 1 });
  const singular = Math.hypot(x.x, x.y) < 1e-10;
  const degrees = (angle) => {
    return Math.round(angle * 180 / Math.PI * 1e10) / 1e10 || 0;
  };
  const localRotation = {
    x: singular ? 0 : degrees(-Math.atan2(y.z, z.z)),
    y: degrees(Math.atan2(x.z, Math.hypot(x.x, x.y))),
    z: degrees(singular ? Math.atan2(y.x, y.y) : -Math.atan2(x.y, x.x))
  };
  const localPosition = toLocal({
    x: position.x - componentCenter.x,
    y: position.y - componentCenter.y,
    z: position.z - boardLayerZOffset
  });
  const localOrigin = modelToLocal(origin);
  return {
    offset: {
      x: localPosition.x - localOrigin.x,
      y: localPosition.y - localOrigin.y,
      z: localPosition.z - localOrigin.z
    },
    rotation: localRotation
  };
}

// lib/pcb/stages/footprints-stage-converters/create3DModelsFromCadComponent.ts
var getEasyedaModelCdnStepUrl = (objUrl) => {
  if (!objUrl) return void 0;
  try {
    const url = new URL(objUrl);
    if (url.hostname !== "modelcdn.tscircuit.com") return void 0;
    const assetMatch = url.pathname.match(
      /^\/easyeda_models\/assets\/([^/]+)\.obj$/
    );
    const partNumber = assetMatch?.[1] ?? url.searchParams.get("pn");
    const isLegacyDownload = url.pathname === "/easyeda_models/download";
    if (!partNumber || !assetMatch && !isLegacyDownload) return void 0;
    const stepUrl = new URL(
      `/easyeda_models/assets/${encodeURIComponent(partNumber)}.step`,
      url.origin
    );
    const uuid = url.searchParams.get("uuid");
    if (uuid) stepUrl.searchParams.set("uuid", uuid);
    return stepUrl.toString();
  } catch {
    return void 0;
  }
};
function create3DModelsFromCadComponent(cadComponent, componentCenter, options) {
  const models = [];
  const modelUrl = cadComponent.model_step_url || cadComponent.model_wrl_url || getEasyedaModelCdnStepUrl(cadComponent.model_obj_url);
  if (!modelUrl) return models;
  const model = new FootprintModel3(modelUrl);
  const boardLayerZOffset = options.boardLayerZOffset ?? 0;
  const transform = getKicadFootprintLocalModelTransform(cadComponent, {
    componentCenter,
    footprintRotation: options.footprintRotation,
    boardLayerZOffset,
    layer: options.layer
  });
  model.offset = transform.offset;
  model.rotate = transform.rotation;
  if (cadComponent.model_unit_to_mm_scale_factor) {
    const scale6 = cadComponent.model_unit_to_mm_scale_factor;
    model.scale = { x: scale6, y: scale6, z: scale6 };
  }
  models.push(model);
  return models;
}

// lib/pcb/stages/utils/CreateSmdPadFromCircuitJson.ts
import {
  FootprintPad,
  PadPrimitives,
  PadPrimitiveGrPoly,
  Pts as Pts7,
  Xy as Xy7,
  PadOptions,
  PadNet
} from "kicadts";
import {
  applyToPoint as applyToPoint19,
  compose as compose6,
  translate as translate6,
  scale as scale4,
  rotate as rotate8
} from "transformation-matrix";
function createSmdPadFromCircuitJson({
  pcbPad,
  componentCenter,
  padNumber,
  componentRotation = 0,
  netInfo,
  componentId
}) {
  let padX;
  let padY;
  if ("x" in pcbPad && "y" in pcbPad) {
    padX = pcbPad.x;
    padY = pcbPad.y;
  } else if ("points" in pcbPad && Array.isArray(pcbPad.points)) {
    const points = pcbPad.points;
    padX = points.reduce((sum, p) => sum + p.x, 0) / points.length;
    padY = points.reduce((sum, p) => sum + p.y, 0) / points.length;
  } else {
    throw new Error("Pad must have either x/y coordinates or points array");
  }
  const cj2kicadMatrix = compose6(
    componentRotation !== 0 ? rotate8(componentRotation * Math.PI / 180) : { a: 1, b: 0, c: 0, d: 1, e: 0, f: 0 },
    scale4(1, -1),
    // Flip Y-axis
    translate6(-componentCenter.x, -componentCenter.y)
  );
  const rotatedPos = applyToPoint19(cj2kicadMatrix, {
    x: padX,
    y: padY
  });
  const layerMap = {
    top: "F.Cu",
    bottom: "B.Cu"
  };
  const padLayer = layerMap[pcbPad.layer] || "F.Cu";
  let padShape;
  let padSize;
  let padOptions;
  let padPrimitives;
  let roundrect_rratio;
  let rotation = 0;
  if (pcbPad.shape === "circle") {
    padShape = "circle";
    padSize = [
      "radius" in pcbPad ? pcbPad.radius * 2 : 0.5,
      "radius" in pcbPad ? pcbPad.radius * 2 : 0.5
    ];
  } else if (pcbPad.shape === "polygon" && "points" in pcbPad) {
    const points = pcbPad.points;
    const pointTransformMatrix = compose6(
      scale4(1, -1),
      // Flip Y-axis
      translate6(-padX, -padY)
    );
    const relativePoints = points.map((p) => {
      const transformed = applyToPoint19(pointTransformMatrix, { x: p.x, y: p.y });
      return new Xy7(transformed.x, transformed.y);
    });
    const grPoly = new PadPrimitiveGrPoly();
    grPoly.contours = [new Pts7(relativePoints)];
    grPoly.width = 0;
    grPoly.filled = true;
    padPrimitives = new PadPrimitives();
    padPrimitives.addGraphic(grPoly);
    padShape = "custom";
    padOptions = new PadOptions();
    padOptions.anchor = "circle";
    padSize = [0.2, 0.2];
  } else if (pcbPad.shape === "rotated_rect") {
    const cornerRadius = pcbPad.corner_radius ?? pcbPad.rect_border_radius;
    if (cornerRadius) {
      padShape = "roundrect";
      roundrect_rratio = cornerRadius / Math.min(pcbPad.width, pcbPad.height);
    } else {
      padShape = "rect";
    }
    padSize = [pcbPad.width, pcbPad.height];
    rotation = pcbPad.ccw_rotation;
  } else if (pcbPad.shape === "pill") {
    padShape = "roundrect";
    padSize = [pcbPad.width, pcbPad.height];
    roundrect_rratio = pcbPad.radius / Math.min(pcbPad.width, pcbPad.height);
  } else if (pcbPad.shape === "rotated_pill") {
    padShape = "roundrect";
    padSize = [pcbPad.width, pcbPad.height];
    roundrect_rratio = pcbPad.radius / Math.min(pcbPad.width, pcbPad.height);
    rotation = pcbPad.ccw_rotation;
  } else if (pcbPad.shape === "rect") {
    const cornerRadius = pcbPad.corner_radius ?? pcbPad.rect_border_radius;
    if (cornerRadius) {
      padShape = "roundrect";
      roundrect_rratio = cornerRadius / Math.min(pcbPad.width, pcbPad.height);
    } else {
      padShape = "rect";
    }
    padSize = [pcbPad.width, pcbPad.height];
  }
  const padData = `pad:${componentId}:${padNumber}:${rotatedPos.x},${rotatedPos.y}`;
  const pad = new FootprintPad({
    number: String(padNumber),
    padType: "smd",
    shape: padShape,
    at: [rotatedPos.x, rotatedPos.y, rotation],
    size: padSize,
    layers: [
      `${padLayer}`,
      ...pcbPad.is_covered_with_solder_mask ? [] : [`${padLayer === "F.Cu" ? "F" : "B"}.Paste`],
      `${padLayer === "F.Cu" ? "F" : "B"}.Mask`
    ],
    solderMaskMargin: pcbPad.soldermask_margin,
    roundrectRatio: roundrect_rratio,
    uuid: generateDeterministicUuid(padData)
  });
  if (padOptions) {
    pad.options = padOptions;
  }
  if (padPrimitives) {
    pad.primitives = padPrimitives;
  }
  if (netInfo) {
    pad.net = new PadNet(netInfo.id, netInfo.name);
  }
  return pad;
}

// lib/pcb/stages/footprints-stage-converters/convertSmdPads.ts
function convertSmdPads({
  pcbPads,
  componentCenter,
  componentRotation,
  componentId,
  startPadNumber,
  getNetInfo
}, ctx) {
  const pads = [];
  let padNumber = startPadNumber;
  for (const pcbPad of pcbPads) {
    const netInfo = getNetInfo(pcbPad.pcb_port_id);
    const pcbPort = pcbPad.pcb_port_id ? ctx.db.pcb_port?.get(pcbPad.pcb_port_id) : void 0;
    const sourcePort = pcbPort?.source_port_id ? ctx.db.source_port?.get(pcbPort.source_port_id) : void 0;
    const pinHint = pcbPad.port_hints?.find(
      (h) => /^pin[A-Za-z0-9_]+$/i.test(h)
    );
    const gridHint = pcbPad.port_hints?.find(
      (h) => /^[A-Za-z]?\d+[A-Za-z0-9_]*$/.test(h)
    );
    const resolvedPadNumber = sourcePort?.pin_number != null ? String(sourcePort.pin_number) : pinHint ? pinHint.replace(/^pin/i, "") : gridHint ?? String(padNumber);
    const pad = createSmdPadFromCircuitJson({
      pcbPad,
      componentCenter,
      padNumber: resolvedPadNumber,
      componentRotation,
      netInfo,
      componentId
    });
    pads.push(pad);
    padNumber++;
  }
  return { pads, nextPadNumber: padNumber };
}

// lib/pcb/stages/utils/CreateThruHolePadFromCircuitJson.ts
import { FootprintPad as FootprintPad2, PadDrill, PadNet as PadNet2 } from "kicadts";
import { applyToPoint as applyToPoint20, rotate as rotate9, identity as identity5 } from "transformation-matrix";
function createThruHolePadFromCircuitJson({
  platedHole,
  componentCenter,
  padNumber,
  componentRotation = 0,
  netInfo,
  componentId
}) {
  if (!("x" in platedHole && "y" in platedHole)) {
    return null;
  }
  const relativeX = platedHole.x - componentCenter.x;
  const relativeY = -(platedHole.y - componentCenter.y);
  const rotationMatrix = componentRotation !== 0 ? rotate9(componentRotation * Math.PI / 180) : identity5();
  const rotatedPos = applyToPoint20(rotationMatrix, {
    x: relativeX,
    y: relativeY
  });
  let padShape = "circle";
  let padSize;
  let drill;
  let rotation = 0;
  const hasHoleOffset = "hole_offset_x" in platedHole || "hole_offset_y" in platedHole;
  let drillOffset;
  if (hasHoleOffset) {
    const rawOffset = {
      x: platedHole.hole_offset_x ?? 0,
      y: platedHole.hole_offset_y ?? 0
    };
    if (rawOffset.x !== 0 || rawOffset.y !== 0) {
      const rotatedOffset = applyToPoint20(rotationMatrix, {
        x: -rawOffset.x,
        y: rawOffset.y
      });
      drillOffset = rotatedOffset;
    }
  }
  if (platedHole.shape === "circle") {
    padShape = "circle";
    padSize = [platedHole.outer_diameter, platedHole.outer_diameter];
    drill = new PadDrill({
      diameter: platedHole.hole_diameter,
      offset: drillOffset
    });
  } else if (platedHole.shape === "pill" || platedHole.shape === "oval") {
    padShape = "oval";
    rotation = platedHole.ccw_rotation || 0;
    padSize = [platedHole.outer_width, platedHole.outer_height];
    drill = new PadDrill({
      oval: true,
      diameter: platedHole.hole_width,
      width: platedHole.hole_height,
      offset: drillOffset
    });
  } else if (platedHole.shape === "pill_hole_with_rect_pad") {
    padShape = "rect";
    padSize = [platedHole.rect_pad_width, platedHole.rect_pad_height];
    drill = new PadDrill({
      oval: true,
      diameter: platedHole.hole_width,
      width: platedHole.hole_height,
      offset: drillOffset
    });
  } else if (platedHole.shape === "circular_hole_with_rect_pad") {
    padShape = "rect";
    padSize = [platedHole.rect_pad_width, platedHole.rect_pad_height];
    drill = new PadDrill({
      diameter: platedHole.hole_diameter,
      offset: drillOffset
    });
    rotation = platedHole.rect_ccw_rotation || 0;
  } else if (platedHole.shape === "rotated_pill_hole_with_rect_pad") {
    padShape = "rect";
    padSize = [platedHole.rect_pad_width, platedHole.rect_pad_height];
    drill = new PadDrill({
      oval: true,
      diameter: platedHole.hole_width,
      width: platedHole.hole_height,
      offset: drillOffset
    });
    rotation = platedHole.rect_ccw_rotation || 0;
  } else {
    padShape = "circle";
    padSize = [1.6, 1.6];
    drill = new PadDrill({ diameter: 0.8, offset: drillOffset });
  }
  const padData = `thruhole:${componentId}:${padNumber}:${rotatedPos.x},${rotatedPos.y}`;
  const pad = new FootprintPad2({
    number: String(padNumber),
    padType: "thru_hole",
    shape: padShape,
    at: [rotatedPos.x, rotatedPos.y, rotation],
    size: padSize,
    drill,
    layers: ["*.Cu", "*.Mask"],
    removeUnusedLayers: false,
    uuid: generateDeterministicUuid(padData)
  });
  if (netInfo) {
    pad.net = new PadNet2(netInfo.id, netInfo.name);
  }
  return pad;
}

// lib/pcb/stages/footprints-stage-converters/convertPlatedHoles.ts
function convertPlatedHoles({
  platedHoles,
  componentCenter,
  componentRotation,
  componentId,
  startPadNumber,
  getNetInfo
}, ctx) {
  const pads = [];
  let padNumber = startPadNumber;
  for (const platedHole of platedHoles) {
    const netInfo = getNetInfo(platedHole.pcb_port_id);
    const pcbPort = platedHole.pcb_port_id ? ctx.db.pcb_port?.get(platedHole.pcb_port_id) : void 0;
    const sourcePort = pcbPort?.source_port_id ? ctx.db.source_port?.get(pcbPort.source_port_id) : void 0;
    const pinHint = platedHole.port_hints?.find(
      (h) => /^pin[A-Za-z0-9_]+$/i.test(h)
    );
    const gridHint = platedHole.port_hints?.find(
      (h) => /^[A-Za-z]?\d+[A-Za-z0-9_]*$/.test(h)
    );
    const resolvedPadNumber = sourcePort?.pin_number != null ? String(sourcePort.pin_number) : pinHint ? pinHint.replace(/^pin/i, "") : gridHint ?? String(padNumber);
    const pad = createThruHolePadFromCircuitJson({
      platedHole,
      componentCenter,
      padNumber: resolvedPadNumber,
      componentRotation,
      netInfo,
      componentId
    });
    if (pad) {
      pads.push(pad);
      padNumber++;
    }
  }
  return { pads, nextPadNumber: padNumber };
}

// lib/pcb/stages/utils/CreateNpthPadFromCircuitJson.ts
import { FootprintPad as FootprintPad3, PadDrill as PadDrill2 } from "kicadts";
import { applyToPoint as applyToPoint21, rotate as rotate10, identity as identity6 } from "transformation-matrix";
function createNpthPadFromCircuitJson({
  pcbHole,
  componentCenter,
  componentRotation = 0
}) {
  if (!("x" in pcbHole && "y" in pcbHole)) {
    return null;
  }
  const relativeX = pcbHole.x - componentCenter.x;
  const relativeY = -(pcbHole.y - componentCenter.y);
  const rotationMatrix = componentRotation !== 0 ? rotate10(componentRotation * Math.PI / 180) : identity6();
  const rotatedPos = applyToPoint21(rotationMatrix, {
    x: relativeX,
    y: relativeY
  });
  let padShape = "circle";
  let padSize;
  let drill;
  let rotation = 0;
  if (pcbHole.hole_shape === "circle") {
    padShape = "circle";
    const diameter = pcbHole.hole_diameter;
    padSize = [diameter, diameter];
    drill = new PadDrill2({
      diameter
    });
  } else if (pcbHole.hole_shape === "oval" || pcbHole.hole_shape === "pill") {
    padShape = "oval";
    const width = pcbHole.hole_width;
    const height = pcbHole.hole_height;
    padSize = [width, height];
    drill = new PadDrill2({
      oval: true,
      diameter: width,
      width: height
    });
  } else if (pcbHole.hole_shape === "rotated_pill") {
    padShape = "oval";
    const width = pcbHole.hole_width;
    const height = pcbHole.hole_height;
    padSize = [width, height];
    drill = new PadDrill2({
      oval: true,
      diameter: width,
      width: height
    });
    rotation = pcbHole.ccw_rotation || 0;
  } else {
    padShape = "circle";
    const diameter = "hole_diameter" in pcbHole ? pcbHole.hole_diameter : 1;
    padSize = [diameter, diameter];
    drill = new PadDrill2({ diameter });
  }
  return new FootprintPad3({
    number: "",
    // Non-plated holes have no pad number
    padType: "np_thru_hole",
    shape: padShape,
    at: [rotatedPos.x, rotatedPos.y, rotation],
    size: padSize,
    drill,
    layers: ["*.Cu", "*.Mask"],
    removeUnusedLayers: false,
    uuid: crypto.randomUUID()
  });
}

// lib/pcb/stages/footprints-stage-converters/convertNpthHoles.ts
function convertNpthHoles(params) {
  const { pcbHoles, componentCenter, componentRotation } = params;
  const pads = [];
  for (const pcbHole of pcbHoles) {
    const pad = createNpthPadFromCircuitJson({
      pcbHole,
      componentCenter,
      componentRotation
    });
    if (pad) {
      pads.push(pad);
    }
  }
  return pads;
}

// lib/pcb/stages/footprints-stage-converters/convertFabricationNotePaths.ts
import { FpLine as FpLine2, Stroke as Stroke13 } from "kicadts";
import { applyToPoint as applyToPoint22, identity as identity7, rotate as rotate11 } from "transformation-matrix";
function convertFabricationNotePaths(fabricationNotePaths, {
  componentCenter,
  componentRotation = 0
}) {
  const fpLines = [];
  const rotationMatrix = componentRotation !== 0 ? rotate11(componentRotation * Math.PI / 180) : identity7();
  for (const fabricationNotePath of fabricationNotePaths) {
    if (fabricationNotePath.route.length < 2) continue;
    const kicadLayer = fabricationNotePath.layer === "bottom" ? "B.Fab" : "F.Fab";
    for (let index = 0; index < fabricationNotePath.route.length - 1; index++) {
      const startPoint = fabricationNotePath.route[index];
      const endPoint = fabricationNotePath.route[index + 1];
      if (!startPoint || !endPoint) continue;
      const startRelative = applyToPoint22(rotationMatrix, {
        x: startPoint.x - componentCenter.x,
        y: -(startPoint.y - componentCenter.y)
      });
      const endRelative = applyToPoint22(rotationMatrix, {
        x: endPoint.x - componentCenter.x,
        y: -(endPoint.y - componentCenter.y)
      });
      const stroke = new Stroke13();
      stroke.width = fabricationNotePath.stroke_width || 0.1;
      stroke.type = "default";
      fpLines.push(
        new FpLine2({
          start: startRelative,
          end: endRelative,
          layer: kicadLayer,
          stroke
        })
      );
    }
  }
  return fpLines;
}

// lib/pcb/stages/AddFootprintsStage.ts
var AddFootprintsStage = class extends ConverterStage {
  componentsProcessed = 0;
  pcbComponents = [];
  includeBuiltin3dModels;
  sourcePortNetKeys = /* @__PURE__ */ Object.create(null);
  getNetInfoForPcbPort(pcbPortId) {
    if (!pcbPortId) return void 0;
    const pcbPort = this.ctx.db.pcb_port?.get(pcbPortId);
    if (!pcbPort) return void 0;
    const sourcePortId = pcbPort.source_port_id;
    if (!sourcePortId) return void 0;
    const sourcePort = this.ctx.db.source_port?.get(sourcePortId);
    if (!sourcePort) return void 0;
    const connected = /* @__PURE__ */ new Set([sourcePortId]);
    const pending = [sourcePortId];
    while (pending.length) {
      const current = pending.pop();
      for (const internal of this.ctx.db.source_component_internal_connection.list()) {
        if (!internal.source_port_ids.includes(current)) continue;
        for (const id of internal.source_port_ids) {
          const port = this.ctx.db.source_port.get(id);
          if (!port || port.source_component_id !== sourcePort.source_component_id || internal.source_component_id !== sourcePort.source_component_id) {
            throw new Error(`Invalid internal connection for ${sourcePortId}: ${id}`);
          }
          if (!connected.has(id)) {
            connected.add(id);
            pending.push(id);
          }
        }
      }
    }
    const keys = [...connected].flatMap((id) => [
      ...this.sourcePortNetKeys[id] ?? [],
      this.ctx.db.source_port.get(id)?.subcircuit_connectivity_map_key
    ]);
    const nets = [];
    for (const key of keys) {
      const net = key ? this.ctx.pcbNetMap?.get(key) : void 0;
      if (net && !nets.some((existing) => existing.id === net.id)) {
        nets.push(net);
      }
    }
    if (nets.length > 1) {
      const component = sourcePort.source_component_id ? this.ctx.db.source_component.get(sourcePort.source_component_id) : void 0;
      const reference = component?.name || sourcePort.source_component_id || pcbPort.pcb_component_id;
      throw new Error(
        `Cannot export ${reference} pad ${sourcePort.pin_number ?? sourcePort.name}: multiple KiCad nets (${nets.map((net) => net.name).join(", ")})`
      );
    }
    return nets[0];
  }
  getCadComponentForPcbComponent(pcbComponentId) {
    const cadComponents = this.ctx.db.cad_component?.list() || [];
    return cadComponents.find(
      (cad) => cad.pcb_component_id === pcbComponentId
    );
  }
  constructor(input, ctx, options) {
    super(input, ctx);
    this.pcbComponents = this.ctx.db.pcb_component.list();
    this.includeBuiltin3dModels = options?.includeBuiltin3dModels ?? false;
    for (const trace of ctx.db.source_trace.list()) {
      const keys = [
        trace.subcircuit_connectivity_map_key,
        ...(trace.connected_source_net_ids ?? []).map((id) => {
          const net = ctx.db.source_net.get(id);
          return net?.subcircuit_connectivity_map_key || net?.source_net_id;
        })
      ].filter((key) => Boolean(key));
      for (const portId of trace.connected_source_port_ids ?? []) {
        this.sourcePortNetKeys[portId] ??= [];
        this.sourcePortNetKeys[portId].push(...keys);
      }
    }
  }
  _step() {
    const { kicadPcb, c2kMatPcb } = this.ctx;
    if (!kicadPcb) {
      throw new Error("KicadPcb instance not initialized in context");
    }
    if (!c2kMatPcb) {
      throw new Error("PCB transformation matrix not initialized in context");
    }
    if (this.componentsProcessed >= this.pcbComponents.length) {
      this.finished = true;
      return;
    }
    const component = this.pcbComponents[this.componentsProcessed];
    const sourceComponent = component.source_component_id ? this.ctx.db.source_component.get(component.source_component_id) : null;
    const cadComponent = this.getCadComponentForPcbComponent(
      component.pcb_component_id
    );
    const footprintName = sourceComponent ? getKicadCompatibleComponentName(
      sourceComponent,
      cadComponent
    ) : "Unknown";
    const transformedPos = applyToPoint23(c2kMatPcb, {
      x: component.center.x,
      y: component.center.y
    });
    const footprintData = `footprint:${component.pcb_component_id}:${transformedPos.x},${transformedPos.y}`;
    const footprint = new Footprint3({
      libraryLink: `tscircuit:${footprintName}`,
      layer: component.layer === "bottom" ? "B.Cu" : "F.Cu",
      at: [transformedPos.x, transformedPos.y, component.rotation || 0],
      uuid: generateDeterministicUuid(footprintData)
    });
    const fpTexts = footprint.fpTexts;
    const pcbSilkscreenTexts = this.ctx.db.pcb_silkscreen_text?.list().filter(
      (text) => text.pcb_component_id === component.pcb_component_id
    ) || [];
    fpTexts.push(
      ...convertSilkscreenTexts({
        silkscreenTexts: pcbSilkscreenTexts,
        componentCenter: component.center,
        componentRotation: component.rotation || 0,
        sourceComponentName: sourceComponent?.name
      })
    );
    const pcbNoteTexts = this.ctx.db.pcb_note_text?.list().filter(
      (text) => text.pcb_component_id === component.pcb_component_id
    ) || [];
    fpTexts.push(
      ...convertNoteTexts({
        noteTexts: pcbNoteTexts,
        componentCenter: component.center,
        componentRotation: component.rotation || 0
      })
    );
    footprint.fpTexts = fpTexts;
    const pcbSilkscreenPaths = this.ctx.db.pcb_silkscreen_path?.list().filter(
      (path) => path.pcb_component_id === component.pcb_component_id
    ) || [];
    const fpLines = footprint.fpLines ?? [];
    fpLines.push(
      ...convertSilkscreenPaths(pcbSilkscreenPaths, {
        componentCenter: component.center,
        componentRotation: component.rotation || 0
      })
    );
    const fabricationNotePaths = this.ctx.db.pcb_fabrication_note_path?.list().filter(
      (path) => path.pcb_component_id === component.pcb_component_id
    ) || [];
    fpLines.push(
      ...convertFabricationNotePaths(fabricationNotePaths, {
        componentCenter: component.center,
        componentRotation: component.rotation || 0
      })
    );
    footprint.fpLines = fpLines;
    const fpPads = footprint.fpPads;
    const getNetInfo = (pcbPortId) => this.getNetInfoForPcbPort(pcbPortId);
    const pcbPads = this.ctx.db.pcb_smtpad?.list().filter(
      (pad) => pad.pcb_component_id === component.pcb_component_id
    ) || [];
    const { pads: smdPads, nextPadNumber } = convertSmdPads(
      {
        pcbPads,
        componentCenter: component.center,
        componentRotation: component.rotation || 0,
        componentId: component.pcb_component_id,
        startPadNumber: 1,
        getNetInfo
      },
      this.ctx
    );
    fpPads.push(...smdPads);
    const pcbPlatedHoles = this.ctx.db.pcb_plated_hole?.list().filter(
      (hole) => hole.pcb_component_id === component.pcb_component_id
    ) || [];
    const { pads: thruHolePads } = convertPlatedHoles(
      {
        platedHoles: pcbPlatedHoles,
        componentCenter: component.center,
        componentRotation: component.rotation || 0,
        componentId: component.pcb_component_id,
        startPadNumber: nextPadNumber,
        getNetInfo
      },
      this.ctx
    );
    fpPads.push(...thruHolePads);
    const pcbHoles = this.ctx.db.pcb_hole?.list().filter(
      (hole) => hole.pcb_component_id === component.pcb_component_id
    ) || [];
    const npthPads = convertNpthHoles({
      pcbHoles,
      componentCenter: component.center,
      componentRotation: component.rotation || 0
    });
    fpPads.push(...npthPads);
    footprint.fpPads = fpPads;
    const pcbSilkscreenCircles = this.ctx.db.pcb_silkscreen_circle?.list().filter(
      (circle) => circle.pcb_component_id === component.pcb_component_id
    ) || [];
    const fpCircles = footprint.fpCircles ?? [];
    fpCircles.push(
      ...convertSilkscreenCircles(pcbSilkscreenCircles, {
        componentCenter: component.center,
        componentRotation: component.rotation || 0
      })
    );
    const pcbCourtyardCircles = this.ctx.db.pcb_courtyard_circle?.list().filter(
      (circle) => circle.pcb_component_id === component.pcb_component_id
    ) || [];
    fpCircles.push(
      ...convertCourtyardCircles(pcbCourtyardCircles, component.center)
    );
    footprint.fpCircles = fpCircles;
    const pcbFabRects = this.ctx.db.pcb_fabrication_note_rect?.list().filter(
      (rect) => rect.pcb_component_id === component.pcb_component_id
    ) || [];
    const fpRects = footprint.fpRects ?? [];
    fpRects.push(...convertFabricationNoteRects(pcbFabRects, component.center));
    const pcbNoteRects = this.ctx.db.pcb_note_rect?.list().filter(
      (rect) => rect.pcb_component_id === component.pcb_component_id
    ) || [];
    fpRects.push(...convertNoteRects(pcbNoteRects, component.center));
    const pcbCourtyardRects = this.ctx.db.pcb_courtyard_rect?.list().filter(
      (rect) => rect.pcb_component_id === component.pcb_component_id
    ) || [];
    fpRects.push(...convertCourtyardRects(pcbCourtyardRects, component.center));
    footprint.fpRects = fpRects;
    const pcbCourtyardOutlines = this.ctx.db.pcb_courtyard_outline?.list().filter(
      (outline) => outline.pcb_component_id === component.pcb_component_id
    ) || [];
    const fpPolys = convertCourtyardOutlines({
      courtyardOutlines: pcbCourtyardOutlines,
      componentCenter: component.center,
      componentRotation: component.rotation || 0
    });
    const pcbSilkscreenRects = this.ctx.db.pcb_silkscreen_rect?.list().filter(
      (rect) => rect.pcb_component_id === component.pcb_component_id
    ) || [];
    fpPolys.push(
      ...convertSilkscreenRects({
        silkscreenRects: pcbSilkscreenRects,
        componentCenter: component.center,
        componentRotation: component.rotation || 0
      })
    );
    if (fpPolys.length > 0) {
      footprint.fpPolys = fpPolys;
    }
    if (cadComponent) {
      const pcbBoard = this.ctx.db.pcb_board?.list()[0];
      const boardThickness = pcbBoard?.thickness ?? 0;
      const boardLayerZOffset = component.layer === "bottom" ? -(boardThickness / 2) : boardThickness / 2;
      const models = create3DModelsFromCadComponent(
        cadComponent,
        component.center,
        {
          boardLayerZOffset,
          footprintRotation: component.rotation || 0,
          layer: component.layer
        }
      );
      const KICAD_3D_BASE = "${KIPRJMOD}/3dmodels";
      if (models.length > 0) {
        if (this.includeBuiltin3dModels) {
          footprint.models = models.map((model) => {
            if (!model.path) return model;
            const filename = getBasename(model.path);
            const isRemote = model.path.startsWith("http://modelcdn.tscircuit.com") || model.path.startsWith("https://modelcdn.tscircuit.com");
            const folderName = isRemote ? "tscircuit_builtin" : this.ctx.projectName ?? filename.replace(/\.[^.]+$/, "");
            const newModel = new FootprintModel4(
              `${KICAD_3D_BASE}/${folderName}.3dshapes/${filename}`
            );
            if (model.offset) newModel.offset = model.offset;
            if (model.scale) newModel.scale = model.scale;
            if (model.rotate) newModel.rotate = model.rotate;
            const sourcePath = model.path?.split("?")[0];
            if (sourcePath && !this.ctx.pcbModel3dSourcePaths?.includes(sourcePath)) {
              this.ctx.pcbModel3dSourcePaths?.push(sourcePath);
            }
            return newModel;
          });
        } else {
          footprint.models = models;
        }
      } else if (cadComponent.footprinter_string && this.includeBuiltin3dModels) {
        const { footprinter_string } = cadComponent;
        const modelPath = `${KICAD_3D_BASE}/tscircuit_builtin.3dshapes/${footprinter_string}.step`;
        footprint.models = [new FootprintModel4(modelPath)];
        const cdnUrl = `${MODEL_CDN_BASE_URL}/${footprinter_string}.step`;
        if (!this.ctx.pcbModel3dSourcePaths?.includes(cdnUrl)) {
          this.ctx.pcbModel3dSourcePaths?.push(cdnUrl);
        }
      }
    }
    const footprintMetadata = component.metadata?.kicad_footprint;
    if (sourceComponent) {
      const kicadComponentProperty = getkicadComponentProperty(sourceComponent);
      applyMetadataToFootprint({
        footprint,
        metadata: footprintMetadata,
        componentProperty: kicadComponentProperty
      });
    }
    if (component.do_not_place) {
      footprint.attr ??= new FootprintAttr3();
      footprint.attr.dnp = true;
    }
    const footprints = kicadPcb.footprints;
    footprints.push(footprint);
    kicadPcb.footprints = footprints;
    this.componentsProcessed++;
  }
  getOutput() {
    return this.ctx.kicadPcb;
  }
};

// lib/pcb/stages/AddTracesStage.ts
import { Segment, SegmentNet } from "kicadts";
import { applyToPoint as applyToPoint24 } from "transformation-matrix";
function getRoutePointLayer(point, pointRoleInSegment) {
  if ("layer" in point) {
    return point.layer;
  }
  if (point.route_type === "through_pad") {
    if (pointRoleInSegment === "start") {
      return point.end_layer;
    }
    return point.start_layer;
  }
  return void 0;
}
function getRoutePointWidth(point) {
  if ("width" in point) {
    return point.width;
  }
  return void 0;
}
var AddTracesStage = class extends ConverterStage {
  tracesProcessed = 0;
  pcbTraces = [];
  constructor(input, ctx) {
    super(input, ctx);
    this.pcbTraces = this.ctx.db.pcb_trace.list();
  }
  getRoutePointPosition(point, pointRoleInSegment) {
    if ("x" in point && "y" in point) {
      return { x: point.x, y: point.y };
    }
    if (point.route_type !== "through_pad") {
      return null;
    }
    if (pointRoleInSegment === "start") {
      return { x: point.end.x, y: point.end.y };
    }
    return { x: point.start.x, y: point.start.y };
  }
  _step() {
    const { kicadPcb, c2kMatPcb, pcbNetMap } = this.ctx;
    if (!kicadPcb) {
      throw new Error("KicadPcb instance not initialized in context");
    }
    if (!c2kMatPcb) {
      throw new Error("PCB transformation matrix not initialized in context");
    }
    if (this.tracesProcessed >= this.pcbTraces.length) {
      this.finished = true;
      return;
    }
    const trace = this.pcbTraces[this.tracesProcessed];
    const route = trace.route;
    if (!route || route.length < 2) {
      this.tracesProcessed++;
      return;
    }
    let lastKnownLayer = getRoutePointLayer(
      route[0],
      "start"
    );
    for (let i = 0; i < route.length - 1; i++) {
      const startPoint = route[i];
      const endPoint = route[i + 1];
      const startPosition = this.getRoutePointPosition(startPoint, "start");
      const endPosition = this.getRoutePointPosition(endPoint, "end");
      if (!startPosition || !endPosition) {
        throw new Error(
          `Unable to convert pcb_trace route segment ${trace.pcb_trace_id ?? this.tracesProcessed}:${i} to KiCad segment`
        );
      }
      const transformedStart = applyToPoint24(c2kMatPcb, startPosition);
      const transformedEnd = applyToPoint24(c2kMatPcb, endPosition);
      if (transformedStart.x === transformedEnd.x && transformedStart.y === transformedEnd.y) {
        continue;
      }
      let netInfo;
      if (pcbNetMap) {
        let connectivityKey = trace.subcircuit_connectivity_map_key;
        if (!connectivityKey && trace.source_trace_id) {
          const sourceTrace = this.ctx.db.source_trace?.get(
            trace.source_trace_id
          );
          if (sourceTrace) {
            connectivityKey = sourceTrace.subcircuit_connectivity_map_key;
            if (!connectivityKey && sourceTrace.connected_source_net_ids?.length) {
              for (const sourceNetId of sourceTrace.connected_source_net_ids) {
                const sourceNet = this.ctx.db.source_net?.get(sourceNetId);
                if (sourceNet) {
                  connectivityKey = sourceNet.subcircuit_connectivity_map_key || sourceNet.source_net_id;
                  break;
                }
              }
            }
          }
        }
        if (!connectivityKey && typeof trace.connection_name === "string") {
          const sourceNet = this.ctx.db.source_net?.get(trace.connection_name);
          if (sourceNet) {
            connectivityKey = sourceNet.subcircuit_connectivity_map_key || sourceNet.source_net_id;
          }
        }
        if (connectivityKey) {
          netInfo = pcbNetMap.get(connectivityKey);
        }
      }
      const segmentLayerSource = getRoutePointLayer(startPoint, "start") ?? getRoutePointLayer(endPoint, "end") ?? lastKnownLayer;
      const kicadLayer = getKicadLayer(segmentLayerSource);
      const segmentData = `segment:${transformedStart.x},${transformedStart.y}:${transformedEnd.x},${transformedEnd.y}:${kicadLayer}:${netInfo?.id ?? 0}`;
      const segment = new Segment({
        start: { x: transformedStart.x, y: transformedStart.y },
        end: { x: transformedEnd.x, y: transformedEnd.y },
        layer: kicadLayer,
        width: getRoutePointWidth(startPoint) ?? getRoutePointWidth(endPoint) ?? trace.width ?? 0.25,
        net: new SegmentNet(netInfo?.id ?? 0),
        uuid: generateDeterministicUuid(segmentData)
      });
      const segments = kicadPcb.segments;
      segments.push(segment);
      kicadPcb.segments = segments;
      const startLayer = getRoutePointLayer(startPoint, "start");
      const endLayer = getRoutePointLayer(endPoint, "end");
      if (startLayer) {
        lastKnownLayer = startLayer;
      }
      if (endLayer) {
        lastKnownLayer = endLayer;
      }
    }
    this.tracesProcessed++;
  }
  getOutput() {
    return this.ctx.kicadPcb;
  }
};

// lib/pcb/stages/AddViasStage.ts
import { Via, ViaNet } from "kicadts";
import { applyToPoint as applyToPoint25 } from "transformation-matrix";
var AddViasStage = class extends ConverterStage {
  viasProcessed = 0;
  pcbVias = [];
  constructor(input, ctx) {
    super(input, ctx);
    this.pcbVias = this.collectPcbVias();
  }
  collectPcbVias() {
    const standaloneVias = this.ctx.db.pcb_via?.list() || [];
    const seenViaKeys = new Set(
      standaloneVias.map((via) => this.getViaDedupeKey(via))
    );
    const routeDefinedVias = (this.ctx.db.pcb_trace?.list() || []).flatMap(
      (trace) => (trace.route || []).filter((point) => point.route_type === "via").map(
        (point) => ({
          x: point.x,
          y: point.y,
          outer_diameter: point.outer_diameter ?? point.via_diameter,
          hole_diameter: point.hole_diameter ?? point.via_hole_diameter,
          from_layer: point.from_layer,
          to_layer: point.to_layer,
          pcb_trace_id: trace.pcb_trace_id,
          subcircuit_connectivity_map_key: trace.subcircuit_connectivity_map_key,
          connection_name: trace.connection_name
        })
      ).filter((via) => {
        const viaKey = this.getViaDedupeKey(via);
        if (seenViaKeys.has(viaKey)) {
          return false;
        }
        seenViaKeys.add(viaKey);
        return true;
      })
    );
    return [...standaloneVias, ...routeDefinedVias];
  }
  getViaDedupeKey(via) {
    const span = [...this.getKicadViaLayers(via)].sort().join(",");
    return `${via.x}:${via.y}:${span}`;
  }
  getRawViaLayers(via) {
    if (via.layers?.length) {
      return [...via.layers];
    }
    return [via.from_layer, via.to_layer].filter(
      (layer) => Boolean(layer)
    );
  }
  getKicadViaLayers(via) {
    const rawLayers = this.getRawViaLayers(via);
    const numLayers = this.ctx.numLayers ?? 2;
    const kicadLayers = rawLayers.length > 0 ? rawLayers.map((layer) => getKicadLayer(layer)) : getViaLayers(numLayers);
    return getViaLayerSpan(kicadLayers, numLayers);
  }
  _step() {
    const { kicadPcb, c2kMatPcb, pcbNetMap } = this.ctx;
    if (!kicadPcb) {
      throw new Error("KicadPcb instance not initialized in context");
    }
    if (!c2kMatPcb) {
      throw new Error("PCB transformation matrix not initialized in context");
    }
    if (this.viasProcessed >= this.pcbVias.length) {
      this.finished = true;
      return;
    }
    const via = this.pcbVias[this.viasProcessed];
    if (!via) {
      this.finished = true;
      return;
    }
    const transformedPos = applyToPoint25(c2kMatPcb, {
      x: via.x,
      y: via.y
    });
    let netInfo;
    if (pcbNetMap) {
      let connectivityKey = via.subcircuit_connectivity_map_key;
      if (!connectivityKey && via.source_net_id) {
        const sourceNet = this.ctx.db.source_net?.get(via.source_net_id);
        if (sourceNet) {
          connectivityKey = sourceNet.subcircuit_connectivity_map_key || sourceNet.source_net_id;
        }
      }
      if (!connectivityKey && via.pcb_trace_id) {
        const pcbTrace = this.ctx.db.pcb_trace?.get(via.pcb_trace_id);
        if (pcbTrace) {
          if ("subcircuit_connectivity_map_key" in pcbTrace) {
            connectivityKey = pcbTrace.subcircuit_connectivity_map_key;
          }
          if (!connectivityKey && pcbTrace.source_trace_id) {
            const sourceTrace = this.ctx.db.source_trace?.get(
              pcbTrace.source_trace_id
            );
            if (sourceTrace) {
              if ("subcircuit_connectivity_map_key" in sourceTrace) {
                connectivityKey = sourceTrace.subcircuit_connectivity_map_key;
              }
              if (!connectivityKey && sourceTrace.connected_source_net_ids?.length) {
                for (const sourceNetId of sourceTrace.connected_source_net_ids) {
                  const sourceNet = this.ctx.db.source_net?.get(sourceNetId);
                  if (sourceNet) {
                    connectivityKey = sourceNet.subcircuit_connectivity_map_key || sourceNet.source_net_id;
                    break;
                  }
                }
              }
            }
            if (!connectivityKey) {
              const sourceNet = this.ctx.db.source_net?.get(
                pcbTrace.source_trace_id
              );
              if (sourceNet) {
                connectivityKey = sourceNet.subcircuit_connectivity_map_key || sourceNet.source_net_id;
              }
            }
          }
        }
      }
      if (!connectivityKey && via.connection_name) {
        const sourceNet = this.ctx.db.source_net?.get(via.connection_name);
        if (sourceNet) {
          connectivityKey = sourceNet.subcircuit_connectivity_map_key || sourceNet.source_net_id;
        }
      }
      if (connectivityKey) {
        netInfo = pcbNetMap.get(connectivityKey);
      }
    }
    const viaLayers = this.getKicadViaLayers(via);
    const viaSize = via.outer_diameter ?? 0.8;
    const viaDrill = via.hole_diameter ?? 0.4;
    const viaData = `via:${transformedPos.x},${transformedPos.y}:${viaSize}:${viaDrill}:${netInfo?.id ?? 0}`;
    const kicadVia = new Via({
      at: [transformedPos.x, transformedPos.y],
      size: viaSize,
      drill: viaDrill,
      layers: viaLayers,
      net: new ViaNet(netInfo?.id ?? 0),
      uuid: generateDeterministicUuid(viaData)
    });
    const vias = kicadPcb.vias;
    vias.push(kicadVia);
    kicadPcb.vias = vias;
    this.viasProcessed++;
  }
  getOutput() {
    return this.ctx.kicadPcb;
  }
};

// lib/pcb/stages/AddStandalonePcbElements.ts
import { Footprint as Footprint4 } from "kicadts";
import { applyToPoint as applyToPoint26 } from "transformation-matrix";
var AddStandalonePcbElements = class extends ConverterStage {
  unprocessedElements = [];
  constructor(input, ctx) {
    super(input, ctx);
    this.unprocessedElements = [
      ...this.ctx.db.pcb_hole.list().filter(
        (hole) => !hole.pcb_component_id
      ),
      ...this.ctx.db.pcb_plated_hole.list().filter(
        (hole) => !hole.pcb_component_id
      ),
      ...this.ctx.db.pcb_smtpad.list().filter(
        (pad) => !pad.pcb_component_id
      )
    ];
  }
  _step() {
    const { kicadPcb, c2kMatPcb } = this.ctx;
    if (!kicadPcb) {
      throw new Error("KicadPcb instance not initialized in context");
    }
    if (!c2kMatPcb) {
      throw new Error("PCB transformation matrix not initialized in context");
    }
    const elm = this.unprocessedElements.shift();
    if (!elm) {
      this.finished = true;
      return;
    }
    if (elm.type === "pcb_smtpad") {
      const pcbPad = elm;
      const padCenter = this.getPcbSmtPadCenter(pcbPad);
      const footprintSeed = `standalone_smtpad:${pcbPad.pcb_smtpad_id}:${padCenter.x},${padCenter.y}`;
      const kicadPos = applyToPoint26(c2kMatPcb, padCenter);
      const footprint = new Footprint4({
        libraryLink: this.getSmtPadLibraryLink(pcbPad),
        layer: "F.Cu",
        at: [kicadPos.x, kicadPos.y, 0],
        uuid: generateDeterministicUuid(footprintSeed)
      });
      footprint.fpPads = [
        createSmdPadFromCircuitJson({
          pcbPad,
          componentCenter: padCenter,
          padNumber: 1,
          componentRotation: 0,
          componentId: pcbPad.pcb_smtpad_id
        })
      ];
      const footprints = kicadPcb.footprints;
      footprints.push(footprint);
      kicadPcb.footprints = footprints;
    } else if (elm.type === "pcb_hole") {
      const hole = elm;
      const footprintSeed = `standalone_hole:${hole.pcb_hole_id}:${hole.x},${hole.y}`;
      const kicadPos = applyToPoint26(c2kMatPcb, { x: hole.x, y: hole.y });
      const libraryLink = this.getHoleLibraryLink(hole);
      const footprint = new Footprint4({
        libraryLink,
        layer: "F.Cu",
        at: [kicadPos.x, kicadPos.y, 0],
        uuid: generateDeterministicUuid(footprintSeed)
      });
      const ccwRotationDegrees = 0;
      const npthPads = convertNpthHoles({
        pcbHoles: [hole],
        componentCenter: { x: hole.x, y: hole.y },
        // Use hole center for negative offset
        componentRotation: ccwRotationDegrees
      });
      if (npthPads.length > 0) {
        footprint.fpPads = npthPads;
        const footprints = kicadPcb.footprints;
        footprints.push(footprint);
        kicadPcb.footprints = footprints;
      }
    } else if (elm.type === "pcb_plated_hole") {
      const hole = elm;
      const footprintSeed = `standalone_plated_hole:${hole.pcb_plated_hole_id}:${hole.x},${hole.y}`;
      const kicadPos = applyToPoint26(c2kMatPcb, { x: hole.x, y: hole.y });
      const libraryLink = this.getPlatedHoleLibraryLink(hole);
      const footprint = new Footprint4({
        libraryLink,
        layer: "F.Cu",
        at: [kicadPos.x, kicadPos.y, 0],
        uuid: generateDeterministicUuid(footprintSeed)
      });
      const pad = createThruHolePadFromCircuitJson({
        platedHole: hole,
        componentCenter: { x: hole.x, y: hole.y },
        padNumber: 1,
        componentRotation: 0
      });
      if (pad) {
        footprint.fpPads = [pad];
        const footprints = kicadPcb.footprints;
        footprints.push(footprint);
        kicadPcb.footprints = footprints;
      }
    }
  }
  getHoleLibraryLink(hole) {
    const { hole_shape: shape } = hole;
    if (shape === "circle") {
      return `tscircuit:hole_${shape}_holeDiameter${hole.hole_diameter}mm`;
    }
    if (shape === "pill" || shape === "oval") {
      const h = hole;
      return `tscircuit:hole_${shape}_holeWidth${h.hole_width}mm_holeHeight${h.hole_height}mm`;
    }
    if (shape === "rotated_pill") {
      return `tscircuit:hole_${shape}_holeWidth${hole.hole_width}mm_holeHeight${hole.hole_height}mm_ccwRotation${hole.ccw_rotation}deg`;
    }
    return "tscircuit:hole";
  }
  getPlatedHoleLibraryLink(hole) {
    const shape = hole.shape;
    if (shape === "circle") {
      return `tscircuit:platedhole_${shape}_holeDiameter${hole.hole_diameter}mm_outerDiameter${hole.outer_diameter}mm`;
    }
    if (shape === "pill" || shape === "oval") {
      const h = hole;
      return `tscircuit:platedhole_${shape}_holeWidth${h.hole_width}mm_holeHeight${h.hole_height}mm_outerWidth${h.outer_width}mm_outerHeight${h.outer_height}mm`;
    }
    if (shape === "pill_hole_with_rect_pad") {
      const h = hole;
      return `tscircuit:platedhole_${shape}_holeWidth${h.hole_width}mm_holeHeight${h.hole_height}mm_rectPadWidth${h.rect_pad_width}mm_rectPadHeight${h.rect_pad_height}mm`;
    }
    if (shape === "circular_hole_with_rect_pad") {
      const h = hole;
      let link = `tscircuit:platedhole_${shape}_holeDiameter${h.hole_diameter}mm_rectPadWidth${h.rect_pad_width}mm_rectPadHeight${h.rect_pad_height}mm`;
      if (h.rect_ccw_rotation) {
        link += `_ccwRotation${h.rect_ccw_rotation}deg`;
      }
      return link;
    }
    if (shape === "rotated_pill_hole_with_rect_pad") {
      const h = hole;
      let link = `tscircuit:platedhole_${shape}_holeWidth${h.hole_width}mm_holeHeight${h.hole_height}mm_rectPadWidth${h.rect_pad_width}mm_rectPadHeight${h.rect_pad_height}mm`;
      if (h.rect_ccw_rotation) {
        link += `_ccwRotation${h.rect_ccw_rotation}deg`;
      }
      return link;
    }
    return "tscircuit:platedhole";
  }
  getPcbSmtPadCenter(pcbPad) {
    if ("x" in pcbPad && "y" in pcbPad) {
      return { x: pcbPad.x, y: pcbPad.y };
    }
    const points = pcbPad.points;
    return {
      x: points.reduce((sum, point) => sum + point.x, 0) / points.length,
      y: points.reduce((sum, point) => sum + point.y, 0) / points.length
    };
  }
  getSmtPadLibraryLink(pcbPad) {
    if (pcbPad.shape === "circle" && "radius" in pcbPad) {
      return `tscircuit:smtpad_circle_diameter${pcbPad.radius * 2}mm`;
    }
    if ((pcbPad.shape === "rect" || pcbPad.shape === "rotated_rect") && "width" in pcbPad && "height" in pcbPad) {
      return `tscircuit:smtpad_${pcbPad.shape}_width${pcbPad.width}mm_height${pcbPad.height}mm`;
    }
    return "tscircuit:smtpad";
  }
  getOutput() {
    return this.ctx.kicadPcb;
  }
};

// lib/pcb/stages/AddGraphicsStage.ts
import { GrLine } from "kicadts";

// lib/pcb/stages/utils/CreateFabricationNoteTextFromCircuitJson.ts
import {
  At as At3,
  GrText,
  TextEffects as TextEffects12,
  TextEffectsFont as TextEffectsFont12,
  TextEffectsJustify as TextEffectsJustify6
} from "kicadts";
import { applyToPoint as applyToPoint27 } from "transformation-matrix";
function createFabricationNoteTextFromCircuitJson({
  textElement,
  c2kMatPcb
}) {
  if (!textElement.text || !textElement.anchor_position) {
    return null;
  }
  const transformedPos = applyToPoint27(c2kMatPcb, {
    x: textElement.anchor_position.x,
    y: textElement.anchor_position.y
  });
  const layerMap = {
    top: "F.Fab",
    bottom: "B.Fab"
  };
  const kicadLayer = layerMap[textElement.layer] || textElement.layer || "F.Fab";
  const justify = new TextEffectsJustify6();
  const anchorAlignment = textElement.anchor_alignment || "center";
  switch (anchorAlignment) {
    case "top_left":
      justify.horizontal = "left";
      justify.vertical = "top";
      break;
    case "top_right":
      justify.horizontal = "right";
      justify.vertical = "top";
      break;
    case "bottom_left":
      justify.horizontal = "left";
      justify.vertical = "bottom";
      break;
    case "bottom_right":
      justify.horizontal = "right";
      justify.vertical = "bottom";
      break;
    case "center":
      break;
  }
  const font = new TextEffectsFont12();
  font.size = {
    width: textElement.font_size || 1,
    height: textElement.font_size || 1
  };
  font.thickness = 0.15;
  const textEffects = new TextEffects12({ font });
  if (anchorAlignment !== "center") {
    textEffects.justify = justify;
  }
  const position = new At3([transformedPos.x, transformedPos.y, 0]);
  const grText = new GrText({
    text: textElement.text,
    layer: kicadLayer,
    effects: textEffects,
    uuid: generateDeterministicUuid(
      textElement.pcb_fabrication_note_text_id ?? textElement.text
    )
  });
  grText.position = position;
  return grText;
}

// lib/pcb/stages/AddGraphicsStage.ts
import { applyToPoint as applyToPoint29, rotate as rotate12 } from "transformation-matrix";

// lib/pcb/stages/utils/CreateGrTextFromCircuitJson.ts
import { GrText as GrText2, TextEffects as TextEffects13, TextEffectsFont as TextEffectsFont13, At as At4 } from "kicadts";
import { applyToPoint as applyToPoint28 } from "transformation-matrix";
function createGrTextFromCircuitJson({
  textElement,
  c2kMatPcb
}) {
  if (!textElement.text || !textElement.anchor_position) {
    return null;
  }
  const transformedPos = applyToPoint28(c2kMatPcb, {
    x: textElement.anchor_position.x,
    y: textElement.anchor_position.y
  });
  const layerMap = {
    top: "F.SilkS",
    bottom: "B.SilkS"
  };
  const kicadLayer = layerMap[textElement.layer] || textElement.layer || "F.SilkS";
  const kicadLayerNames = textElement.is_knockout ? [kicadLayer, "knockout"] : kicadLayer;
  const font = new TextEffectsFont13();
  const fontSize = textElement.font_size || 1;
  font.size = {
    width: fontSize,
    height: fontSize
  };
  font.thickness = fontSize > 1 ? Math.min(0.3, fontSize * 0.2) : 0.15;
  const textEffects = new TextEffects13({ font });
  const justify = createPcbTextJustify({
    anchorAlignment: textElement.anchor_alignment,
    kicadLayer,
    isMirrored: textElement.is_mirrored
  });
  if (justify) {
    textEffects.justify = justify;
  }
  const rotation = textElement.ccw_rotation || 0;
  const position = new At4([transformedPos.x, transformedPos.y, rotation]);
  const grText = new GrText2({
    text: textElement.text,
    layer: kicadLayerNames,
    effects: textEffects,
    uuid: generateDeterministicUuid(
      textElement.pcb_silkscreen_text_id ?? textElement.text
    )
  });
  grText.position = position;
  return grText;
}

// lib/pcb/stages/AddGraphicsStage.ts
import polygonClipping from "polygon-clipping";
var pointsAreEqual = (a, b) => !!a && !!b && a.x === b.x && a.y === b.y;
var normalizeOutlineCorners = (corners) => {
  const dedupedCorners = [];
  for (const corner of corners) {
    const previousCorner = dedupedCorners[dedupedCorners.length - 1];
    if (pointsAreEqual(previousCorner, corner)) continue;
    dedupedCorners.push(corner);
  }
  while (dedupedCorners.length > 1 && pointsAreEqual(dedupedCorners[0], dedupedCorners[dedupedCorners.length - 1])) {
    dedupedCorners.pop();
  }
  return dedupedCorners;
};
var DEFAULT_EDGE_CUTS_WIDTH = 0.1;
var appendGraphicLine = (kicadPcb, grLine) => {
  const graphicLines = kicadPcb.graphicLines;
  graphicLines.push(grLine);
  kicadPcb.graphicLines = graphicLines;
};
var rotatePointAroundOrigin = (point, rotationDegrees = 0) => {
  if (!rotationDegrees) return point;
  return applyToPoint29(rotate12(rotationDegrees * Math.PI / 180), point);
};
var getRectCutoutCorners = (cutout) => {
  const halfWidth = cutout.width / 2;
  const halfHeight = cutout.height / 2;
  const localCorners = [
    { x: -halfWidth, y: -halfHeight },
    { x: halfWidth, y: -halfHeight },
    { x: halfWidth, y: halfHeight },
    { x: -halfWidth, y: halfHeight }
  ];
  return localCorners.map((point) => {
    const rotatedPoint = rotatePointAroundOrigin(point, cutout.rotation);
    return {
      x: rotatedPoint.x + cutout.center.x,
      y: rotatedPoint.y + cutout.center.y
    };
  });
};
var AddGraphicsStage = class extends ConverterStage {
  _step() {
    const { kicadPcb, c2kMatPcb } = this.ctx;
    const edgeCutsWidth = this.ctx.edgeCutsWidth ?? DEFAULT_EDGE_CUTS_WIDTH;
    if (!kicadPcb) {
      throw new Error("KicadPcb instance not initialized in context");
    }
    if (!c2kMatPcb) {
      throw new Error("PCB transformation matrix not initialized in context");
    }
    const pcbSilkscreenPaths = this.ctx.db.pcb_silkscreen_path?.list().filter((path) => !path.pcb_component_id) || [];
    for (const path of pcbSilkscreenPaths) {
      if (!path.route || path.route.length < 2) continue;
      for (let i = 0; i < path.route.length - 1; i++) {
        const startPoint = path.route[i];
        const endPoint = path.route[i + 1];
        if (!startPoint || !endPoint) continue;
        const transformedStart = applyToPoint29(c2kMatPcb, {
          x: startPoint.x,
          y: startPoint.y
        });
        const transformedEnd = applyToPoint29(c2kMatPcb, {
          x: endPoint.x,
          y: endPoint.y
        });
        const layerMap = {
          top: "F.SilkS",
          bottom: "B.SilkS"
        };
        const kicadLayer = layerMap[path.layer] || path.layer || "F.SilkS";
        const grLine = new GrLine({
          start: { x: transformedStart.x, y: transformedStart.y },
          end: { x: transformedEnd.x, y: transformedEnd.y },
          layer: kicadLayer,
          width: path.stroke_width || 0.15
        });
        appendGraphicLine(kicadPcb, grLine);
      }
    }
    const standaloneSilkscreenTexts = this.ctx.db.pcb_silkscreen_text?.list().filter((text) => !text.pcb_component_id) || [];
    for (const textElement of standaloneSilkscreenTexts) {
      const grText = createGrTextFromCircuitJson({
        textElement,
        c2kMatPcb
      });
      if (grText) {
        const graphicTexts = kicadPcb.graphicTexts;
        graphicTexts.push(grText);
        kicadPcb.graphicTexts = graphicTexts;
      }
    }
    const fabricationNoteTexts = this.ctx.db.pcb_fabrication_note_text?.list() || [];
    for (const textElement of fabricationNoteTexts) {
      const grText = createFabricationNoteTextFromCircuitJson({
        textElement,
        c2kMatPcb
      });
      if (grText) {
        const graphicTexts = kicadPcb.graphicTexts;
        graphicTexts.push(grText);
        kicadPcb.graphicTexts = graphicTexts;
      }
    }
    const pcbBoards = this.ctx.db.pcb_board?.list() || [];
    if (pcbBoards.length > 0) {
      const board = pcbBoards[0];
      if (!board) {
        this.finished = true;
        return;
      }
      let corners;
      if (board.outline && board.outline.length > 0) {
        corners = normalizeOutlineCorners(board.outline);
      } else {
        const halfWidth = board.width ? board.width / 2 : 0;
        const halfHeight = board.height ? board.height / 2 : 0;
        corners = [
          { x: board.center.x - halfWidth, y: board.center.y - halfHeight },
          { x: board.center.x + halfWidth, y: board.center.y - halfHeight },
          { x: board.center.x + halfWidth, y: board.center.y + halfHeight },
          { x: board.center.x - halfWidth, y: board.center.y + halfHeight }
        ];
      }
      const pcbCutouts2 = this.ctx.db.pcb_cutout?.list() || [];
      const cutoutPolys = [];
      for (const cutout of pcbCutouts2) {
        if (cutout.shape === "rect") {
          const cutoutCorners = getRectCutoutCorners(cutout);
          cutoutPolys.push([[cutoutCorners.map((c) => [c.x, c.y])]]);
        } else if (cutout.shape === "circle") {
          cutoutPolys.push([[circleToPolygon(cutout.center, cutout.radius)]]);
        } else if (cutout.shape === "polygon") {
          cutoutPolys.push([[cutout.points.map((c) => [c.x, c.y])]]);
        }
      }
      let boardGeom = [[corners.map((c) => [c.x, c.y])]];
      if (cutoutPolys.length > 0) {
        boardGeom = polygonClipping.difference(boardGeom, ...cutoutPolys);
      }
      for (const poly of boardGeom) {
        for (const ring of poly) {
          const transformedRing = ring.map(
            (point) => applyToPoint29(c2kMatPcb, { x: point[0], y: point[1] })
          );
          for (let i = 0; i < transformedRing.length; i++) {
            const start = transformedRing[i];
            const end = transformedRing[(i + 1) % transformedRing.length];
            if (!start || !end) continue;
            if (pointsAreEqual(start, end)) continue;
            const edgeLine = new GrLine({
              start: { x: start.x, y: start.y },
              end: { x: end.x, y: end.y },
              layer: "Edge.Cuts",
              width: edgeCutsWidth
            });
            appendGraphicLine(kicadPcb, edgeLine);
          }
        }
      }
    }
    const pcbCutouts = this.ctx.db.pcb_cutout?.list() || [];
    for (const cutout of pcbCutouts) {
      if (cutout.shape === "path") {
        if (!cutout.route || cutout.route.length < 2) continue;
        for (let i = 0; i < cutout.route.length - 1; i++) {
          const startPoint = cutout.route[i];
          const endPoint = cutout.route[i + 1];
          if (!startPoint || !endPoint) continue;
          const transformedStart = applyToPoint29(c2kMatPcb, startPoint);
          const transformedEnd = applyToPoint29(c2kMatPcb, endPoint);
          appendGraphicLine(
            kicadPcb,
            new GrLine({
              start: transformedStart,
              end: transformedEnd,
              layer: "Edge.Cuts",
              width: edgeCutsWidth
            })
          );
        }
      }
    }
    this.finished = true;
  }
  getOutput() {
    return this.ctx.kicadPcb;
  }
};

// lib/pcb/CircuitJsonToKicadPcbConverter.ts
var CircuitJsonToKicadPcbConverter = class {
  ctx;
  pipeline;
  currentStageIndex = 0;
  finished = false;
  get currentStage() {
    return this.pipeline[this.currentStageIndex];
  }
  constructor(circuitJson, options) {
    const CIRCUIT_JSON_TO_MM_SCALE = 1;
    const KICAD_PCB_CENTER_X = 100;
    const KICAD_PCB_CENTER_Y = 100;
    this.ctx = {
      db: cju2(circuitJson),
      circuitJson,
      kicadPcb: new KicadPcb2({
        generator: "circuit-json-to-kicad",
        generatorVersion: "0.0.1"
      }),
      c2kMatPcb: compose7(
        translate7(KICAD_PCB_CENTER_X, KICAD_PCB_CENTER_Y),
        scale5(CIRCUIT_JSON_TO_MM_SCALE, -CIRCUIT_JSON_TO_MM_SCALE)
      ),
      projectName: options?.projectName,
      edgeCutsWidth: options?.edgeCutsWidth,
      pcbModel3dSourcePaths: []
    };
    this.pipeline = [
      new InitializePcbStage(circuitJson, this.ctx),
      new AddNetsStage(circuitJson, this.ctx),
      new AddFootprintsStage(circuitJson, this.ctx, {
        includeBuiltin3dModels: options?.includeBuiltin3dModels
      }),
      new AddTracesStage(circuitJson, this.ctx),
      new AddViasStage(circuitJson, this.ctx),
      new AddCopperPoursStage(circuitJson, this.ctx),
      new AddKeepoutsStage(circuitJson, this.ctx),
      new AddStandalonePcbElements(circuitJson, this.ctx),
      new AddGraphicsStage(circuitJson, this.ctx)
    ];
  }
  step() {
    if (!this.currentStage) {
      this.finished = true;
      return;
    }
    this.currentStage.step();
    if (this.currentStage.finished) {
      this.currentStageIndex++;
    }
  }
  runUntilFinished() {
    while (!this.finished) {
      this.step();
    }
  }
  getOutput() {
    return this.ctx.kicadPcb;
  }
  /**
   * Get the output as a string
   */
  getOutputString() {
    return this.ctx.kicadPcb.getString();
  }
  /**
   * Returns CDN URLs for 3D model files needed by builtin footprints in this PCB.
   * The CLI can use these to download and include the models in the project zip.
   */
  getModel3dSourcePaths() {
    return this.ctx.pcbModel3dSourcePaths ?? [];
  }
};

// lib/project/CircuitJsonToKicadProConverter.ts
import { cju as cju3 } from "@tscircuit/circuit-json-util";
var CircuitJsonToKicadProConverter = class {
  ctx;
  project;
  createBaseNetClass(params) {
    return {
      name: params.name,
      track_width: params.trackWidth,
      via_diameter: params.viaDiameter,
      via_drill: params.viaDrill,
      clearance: params.clearance
    };
  }
  constructor(circuitJson, options = {}) {
    const projectName = options.projectName ?? // @ts-expect-error project metadata is optional in circuit json
    circuitJson?.project?.name ?? "circuit-json-project";
    const schematicFilename = options.schematicFilename ?? `${projectName}.kicad_sch`;
    const pcbFilename = options.pcbFilename ?? `${projectName}.kicad_pcb`;
    const timestamp = (/* @__PURE__ */ new Date()).toISOString();
    this.ctx = {
      db: cju3(circuitJson),
      circuitJson
    };
    const pcbBoard = circuitJson.filter(
      (component) => component.type === "pcb_board"
    )[0];
    const schematicSheetPlan = options.schematicSheetPlan ?? buildSchematicSheetPlan(circuitJson);
    const sheets = [[schematicSheetPlan.rootUuid, "Root"]];
    for (const child of schematicSheetPlan.children) {
      sheets.push([child.sheetNodeUuid, child.sheetName]);
    }
    const minViaDiameter = pcbBoard?.min_via_pad_diameter ?? 0.3;
    const minViaDrill = pcbBoard?.min_via_hole_diameter ?? 0.2;
    const minViaAnnularWidth = (minViaDiameter - minViaDrill) / 2;
    const minTraceToPadClearance = pcbBoard?.min_trace_to_pad_edge_clearance ?? 0.1;
    const minTrackWidth = pcbBoard?.min_trace_width ?? 0.1;
    const netClasses = [
      this.createBaseNetClass({
        name: "Default",
        viaDiameter: minViaDiameter,
        viaDrill: minViaDrill,
        clearance: minTraceToPadClearance,
        trackWidth: minTrackWidth
      })
    ];
    this.project = {
      version: 1,
      head: {
        generator: "circuit-json-to-kicad",
        generator_version: "0.0.1",
        project_name: projectName,
        created: timestamp,
        modified: timestamp
      },
      meta: {
        version: 1
      },
      text_variables: {},
      libraries: {
        pinned_symbol_libs: [],
        pinned_footprint_libs: []
      },
      boards: [],
      cvpcb: {
        meta: {
          version: 0
        }
      },
      erc: {
        meta: {
          version: 0
        },
        erc_exclusions: []
      },
      net_settings: {
        meta: {
          version: 1
        },
        last_net_id: netClasses.length - 1,
        classes: netClasses
      },
      pcbnew: {
        page_layout_descr_file: "",
        last_paths: {}
      },
      schematic: {
        meta: {
          version: 1
        },
        page_layout_descr_file: "",
        last_opened_files: [schematicFilename]
      },
      board: {
        meta: {
          version: 1
        },
        design_settings: {
          rules: {
            min_via_annular_width: minViaAnnularWidth,
            min_hole_clearance: minTraceToPadClearance,
            min_via_diameter: minViaDiameter,
            min_track_width: minTrackWidth,
            min_through_hole_diameter: minViaDrill
            // Minimum Drill Size in kicad ui constraints
          }
        },
        last_opened_board: pcbFilename
      },
      sheets
    };
  }
  runUntilFinished() {
  }
  getOutput() {
    return this.project;
  }
  getOutputString() {
    return `${JSON.stringify(this.project, null, 2)}
`;
  }
};

// lib/kicad-library/CircuitJsonToKicadLibraryConverter.ts
import { cju as cju4 } from "@tscircuit/circuit-json-util";

// lib/kicad-library/stages/GenerateKicadSchAndPcbStage.ts
var GenerateKicadSchAndPcbStage = class extends ConverterStage {
  _step() {
    const schConverter = new CircuitJsonToKicadSchConverter(
      this.ctx.circuitJson
    );
    schConverter.runUntilFinished();
    this.ctx.kicadSchString = schConverter.getOutputString();
    const pcbConverter = new CircuitJsonToKicadPcbConverter(
      this.ctx.circuitJson
    );
    pcbConverter.runUntilFinished();
    this.ctx.kicadPcbString = pcbConverter.getOutputString();
    this.finished = true;
  }
  getOutput() {
    return this.ctx.libraryOutput;
  }
};

// lib/kicad-library/stages/ExtractSymbolsStage.ts
import { parseKicadSexpr as parseKicadSexpr2, KicadSch as KicadSch2 } from "kicadts";
var ExtractSymbolsStage = class extends ConverterStage {
  /**
   * Checks if a symbol is custom (user-specified symbol={<symbol>...</symbol>}).
   * Custom symbols have libraryId starting with "Custom:".
   */
  isCustomSymbol(libraryId) {
    return libraryId?.startsWith("Custom:") ?? false;
  }
  _step() {
    const schContent = this.ctx.kicadSchString;
    const fpLibraryName = this.ctx.fpLibraryName ?? "tscircuit";
    if (!schContent) {
      throw new Error(
        "Schematic content not available. Run GenerateKicadSchAndPcbStage first."
      );
    }
    const uniqueSymbols = /* @__PURE__ */ new Map();
    try {
      const parsed = parseKicadSexpr2(schContent);
      const sch = parsed.find(
        (node) => node instanceof KicadSch2
      );
      if (!sch) {
        this.ctx.symbolEntries = [];
        this.finished = true;
        return;
      }
      const libSymbols = sch.libSymbols;
      if (!libSymbols) {
        this.ctx.symbolEntries = [];
        this.finished = true;
        return;
      }
      const symbols5 = libSymbols.symbols ?? [];
      for (const symbol of symbols5) {
        const isCustom = this.isCustomSymbol(symbol.libraryId);
        const symbolName = this.sanitizeSymbolName(symbol.libraryId);
        if (!uniqueSymbols.has(symbolName)) {
          symbol.libraryId = symbolName;
          this.updateFootprintProperty(symbol, fpLibraryName);
          if (!isCustom) {
            this.snapPinPositionsToGrid(symbol);
          }
          uniqueSymbols.set(symbolName, {
            symbolName,
            symbol,
            isBuiltin: !isCustom
          });
        }
      }
    } catch (error) {
      console.warn("Failed to parse schematic for symbol extraction:", error);
    }
    this.ctx.symbolEntries = Array.from(uniqueSymbols.values());
    this.finished = true;
  }
  /**
   * Updates the Footprint property in a symbol to use the correct library name.
   * Changes "tscircuit:footprint_name" to "fpLibraryName:footprint_name"
   */
  updateFootprintProperty(symbol, fpLibraryName) {
    const properties = symbol.properties ?? [];
    for (const prop of properties) {
      if (prop.key === "Footprint" && prop.value) {
        const parts = prop.value.split(":");
        if (parts.length > 1) {
          prop.value = `${fpLibraryName}:${parts[1]}`;
        } else if (prop.value.trim()) {
          prop.value = `${fpLibraryName}:${prop.value}`;
        }
      }
    }
  }
  sanitizeSymbolName(libraryId) {
    if (!libraryId) return "symbol";
    const parts = libraryId.split(":");
    const name = parts.length > 1 ? parts[1] : parts[0];
    return name?.replace(/[\\\/]/g, "-").trim() || "symbol";
  }
  /**
   * Snap pin positions to KiCad's 1.27mm grid.
   * This is necessary for library symbols so users can connect wires in KiCad.
   * Done post-extraction so schematic trace alignment in the snapshots isn't affected.
   */
  snapPinPositionsToGrid(symbol) {
    const KICAD_GRID = 1.27;
    for (const subSymbol of symbol.subSymbols ?? []) {
      for (const pin of subSymbol.pins ?? []) {
        if (pin.at) {
          pin.at.x = Math.round(pin.at.x / KICAD_GRID) * KICAD_GRID;
          pin.at.y = Math.round(pin.at.y / KICAD_GRID) * KICAD_GRID;
        }
      }
      for (const polyline of subSymbol.polylines ?? []) {
        if (polyline.points?.points) {
          for (const pt of polyline.points.points) {
            if ("x" in pt && "y" in pt) {
              pt.x = Math.round(pt.x / KICAD_GRID) * KICAD_GRID;
              pt.y = Math.round(pt.y / KICAD_GRID) * KICAD_GRID;
            }
          }
        }
      }
    }
  }
  getOutput() {
    return this.ctx.libraryOutput;
  }
};

// lib/kicad-library/stages/GenerateSymbolLibraryStage.ts
import { KicadSymbolLib } from "kicadts";
var KICAD_SYM_LIB_VERSION = 20211014;
var GENERATOR = "circuit-json-to-kicad";
var GenerateSymbolLibraryStage = class extends ConverterStage {
  _step() {
    const symbolEntries = this.ctx.symbolEntries ?? [];
    const symbolLibrary = this.generateSymbolLibrary(symbolEntries);
    if (!this.ctx.libraryOutput) {
      this.ctx.libraryOutput = {
        kicadSymString: "",
        symbols: [],
        footprints: [],
        fpLibTableString: "",
        symLibTableString: "",
        model3dSourcePaths: []
      };
    }
    this.ctx.libraryOutput.kicadSymString = symbolLibrary;
    this.finished = true;
  }
  generateSymbolLibrary(symbolEntries) {
    const symbolLib = new KicadSymbolLib({
      version: KICAD_SYM_LIB_VERSION,
      generator: GENERATOR,
      symbols: symbolEntries.map((entry) => entry.symbol)
    });
    return symbolLib.getString();
  }
  getOutput() {
    return this.ctx.libraryOutput;
  }
};

// lib/kicad-library/stages/GenerateLibraryTablesStage.ts
var GenerateLibraryTablesStage = class extends ConverterStage {
  _step() {
    const libraryName = this.ctx.libraryName ?? "tscircuit";
    const fpLibraryName = this.ctx.fpLibraryName ?? "tscircuit";
    const footprintEntries = this.ctx.footprintEntries ?? [];
    const symbolEntries = this.ctx.symbolEntries ?? [];
    const model3dSourcePathsSet = /* @__PURE__ */ new Set();
    for (const fp of footprintEntries) {
      for (const modelPath of fp.model3dSourcePaths) {
        model3dSourcePathsSet.add(modelPath);
      }
    }
    const fpLibTableString = this.generateFpLibTable(fpLibraryName);
    const symLibTableString = this.generateSymLibTable(libraryName);
    if (!this.ctx.libraryOutput) {
      this.ctx.libraryOutput = {
        kicadSymString: "",
        symbols: [],
        footprints: [],
        fpLibTableString: "",
        symLibTableString: "",
        model3dSourcePaths: []
      };
    }
    this.ctx.libraryOutput.symbols = symbolEntries;
    this.ctx.libraryOutput.footprints = footprintEntries;
    this.ctx.libraryOutput.fpLibTableString = fpLibTableString;
    this.ctx.libraryOutput.symLibTableString = symLibTableString;
    this.ctx.libraryOutput.model3dSourcePaths = Array.from(
      model3dSourcePathsSet
    );
    this.finished = true;
  }
  generateFpLibTable(fpLibraryName) {
    return `(fp_lib_table
  (version 7)
  (lib (name "${fpLibraryName}") (type "KiCad") (uri "\${KIPRJMOD}/${fpLibraryName}.pretty") (options "") (descr "Generated by circuit-json-to-kicad"))
)
`;
  }
  generateSymLibTable(libraryName) {
    return `(sym_lib_table
  (version 7)
  (lib (name "${libraryName}") (type "KiCad") (uri "\${KIPRJMOD}/${libraryName}.kicad_sym") (options "") (descr "Generated by circuit-json-to-kicad"))
)
`;
  }
  getOutput() {
    return this.ctx.libraryOutput;
  }
};

// lib/kicad-library/CircuitJsonToKicadLibraryConverter.ts
var CircuitJsonToKicadLibraryConverter = class {
  ctx;
  pipeline;
  currentStageIndex = 0;
  finished = false;
  get currentStage() {
    return this.pipeline[this.currentStageIndex];
  }
  constructor(circuitJson, options = {}) {
    this.ctx = {
      db: cju4(circuitJson),
      circuitJson,
      libraryName: options.libraryName ?? "tscircuit",
      fpLibraryName: options.footprintLibraryName ?? "tscircuit"
    };
    this.pipeline = [
      new GenerateKicadSchAndPcbStage(circuitJson, this.ctx),
      new ExtractSymbolsStage(circuitJson, this.ctx),
      new ExtractFootprintsStage(circuitJson, this.ctx),
      new GenerateSymbolLibraryStage(circuitJson, this.ctx),
      new GenerateLibraryTablesStage(circuitJson, this.ctx)
    ];
  }
  step() {
    if (!this.currentStage) {
      this.finished = true;
      return;
    }
    this.currentStage.step();
    if (this.currentStage.finished) {
      this.currentStageIndex++;
    }
  }
  runUntilFinished() {
    while (!this.finished) {
      this.step();
    }
  }
  getOutput() {
    if (!this.ctx.libraryOutput) {
      throw new Error("Converter has not been run yet");
    }
    return this.ctx.libraryOutput;
  }
  getSymbolLibraryString() {
    return this.getOutput().kicadSymString;
  }
  getFootprints() {
    return this.getOutput().footprints;
  }
  getFpLibTableString() {
    return this.getOutput().fpLibTableString;
  }
  getSymLibTableString() {
    return this.getOutput().symLibTableString;
  }
  getModel3dSourcePaths() {
    return this.getOutput().model3dSourcePaths;
  }
};

// lib/footprint/CircuitJsonToKicadModConverter.ts
var CircuitJsonToKicadModConverter = class {
  libraryConverter;
  footprintName;
  constructor(circuitJson, options = {}) {
    this.footprintName = options.footprintName;
    this.libraryConverter = new CircuitJsonToKicadLibraryConverter(
      circuitJson,
      {
        libraryName: options.libraryName,
        footprintLibraryName: options.footprintLibraryName
      }
    );
  }
  get finished() {
    return this.libraryConverter.finished;
  }
  get currentStage() {
    return this.libraryConverter.currentStage;
  }
  step() {
    this.libraryConverter.step();
  }
  runUntilFinished() {
    this.libraryConverter.runUntilFinished();
  }
  getOutput() {
    const footprints = this.libraryConverter.getFootprints();
    if (this.footprintName) {
      const matchingFootprint = footprints.find(
        (footprint) => footprint.footprintName === this.footprintName
      );
      if (matchingFootprint) {
        return matchingFootprint;
      }
      throw new Error(
        `Footprint "${this.footprintName}" not found. Available footprints: ${footprints.map((footprint) => footprint.footprintName).join(", ")}`
      );
    }
    if (footprints.length === 1) {
      return footprints[0];
    }
    const customFootprints = footprints.filter(
      (footprint) => !footprint.isBuiltin
    );
    if (customFootprints.length === 1) {
      return customFootprints[0];
    }
    throw new Error(
      `Multiple footprints were generated. Pass footprintName to CircuitJsonToKicadModConverter. Available footprints: ${footprints.map((footprint) => footprint.footprintName).join(", ")}`
    );
  }
  getOutputString() {
    return this.getOutput().kicadModString;
  }
  getModel3dSourcePaths() {
    return this.getOutput().model3dSourcePaths;
  }
};

// lib/utils/resolveAndLoadKicad3dModelFiles.ts
var isRemotePath = (modelPath) => modelPath.startsWith("http://") || modelPath.startsWith("https://");
var isBuiltinModelPath = (modelPath) => modelPath.startsWith("http://modelcdn.tscircuit.com") || modelPath.startsWith("https://modelcdn.tscircuit.com");
var getModelFileName = (modelPath) => {
  const modelPathWithoutQuery = modelPath.split("?")[0] || modelPath;
  const modelPathWithoutHash = modelPathWithoutQuery.split("#")[0] || modelPathWithoutQuery;
  const normalizedModelPath = modelPathWithoutHash.replaceAll("\\", "/");
  return normalizedModelPath.split("/").pop() || modelPath;
};
var resolveAndLoadKicad3dModelFiles = async ({
  model3dSourcePaths,
  projectName,
  fetch,
  readFile,
  onModelFile,
  onError
}) => {
  for (const sourcePath of model3dSourcePaths) {
    let shapesDir = `${projectName}.3dshapes`;
    if (isBuiltinModelPath(sourcePath)) {
      shapesDir = "tscircuit_builtin.3dshapes";
    }
    const outputPath = `3dmodels/${shapesDir}/${getModelFileName(sourcePath)}`;
    let content;
    try {
      if (isRemotePath(sourcePath)) {
        const response = await fetch(sourcePath);
        if (!response.ok) {
          throw new Error(`Failed to fetch 3D model from ${sourcePath}`);
        }
        content = new Uint8Array(await response.arrayBuffer());
      } else {
        if (!readFile) {
          throw new Error(
            `Cannot read local 3D model without readFile: ${sourcePath}`
          );
        }
        const fileContent = await readFile(sourcePath);
        if (fileContent instanceof Uint8Array) {
          content = fileContent;
        } else {
          content = new Uint8Array(fileContent);
        }
      }
    } catch (error) {
      if (!onError) {
        throw error;
      }
      await onError({ sourcePath, error });
      continue;
    }
    await onModelFile({ sourcePath, outputPath, content });
  }
};

// lib/kicad-library/kicad-library-converter-utils/renameKicadFootprint.ts
import { parseKicadMod } from "kicadts";
var KICAD_3RD_PARTY_PLACEHOLDER = "${KICAD_3RD_PARTY}";
function renameKicadFootprint(params) {
  const {
    kicadFootprint,
    newKicadFootprintName,
    kicadLibraryName,
    isPcm,
    kicadPcmPackageId
  } = params;
  const footprint = parseKicadMod(kicadFootprint.kicadModString);
  footprint.libraryLink = newKicadFootprintName;
  for (const model of footprint.models) {
    const currentPath = model.path;
    const usesProjectPath = currentPath.includes("${KIPRJMOD}/") || /3dmodels[\\/]/.test(currentPath);
    if (usesProjectPath) {
      const filename = currentPath.split(/[\\/]/).pop() ?? "";
      const isBuiltinPath = currentPath.includes("tscircuit_builtin.3dshapes");
      const targetFolder = isBuiltinPath ? "tscircuit_builtin" : kicadLibraryName;
      if (isPcm && kicadPcmPackageId) {
        model.path = `${KICAD_3RD_PARTY_PLACEHOLDER}/3dmodels/${kicadPcmPackageId}/${targetFolder}.3dshapes/${filename}`;
      } else {
        model.path = `../../3dmodels/${targetFolder}.3dshapes/${filename}`;
      }
    }
  }
  return {
    footprintName: newKicadFootprintName,
    kicadModString: footprint.getString(),
    model3dSourcePaths: kicadFootprint.model3dSourcePaths
  };
}

// lib/kicad-library/kicad-library-converter-utils/applyKicadFootprintMetadata.ts
import {
  parseKicadSexpr as parseKicadSexpr3,
  Footprint as Footprint5,
  Property as Property3,
  TextEffects as TextEffects14,
  TextEffectsFont as TextEffectsFont14
} from "kicadts";
function createTextEffects3(metadataEffects) {
  const font = new TextEffectsFont14();
  if (metadataEffects?.font?.size) {
    font.size = {
      width: Number(metadataEffects.font.size.x),
      height: Number(metadataEffects.font.size.y)
    };
  } else {
    font.size = { width: 1.27, height: 1.27 };
  }
  if (metadataEffects?.font?.thickness !== void 0) {
    font.thickness = Number(metadataEffects.font.thickness);
  } else {
    font.thickness = 0.15;
  }
  return new TextEffects14({ font });
}
function applyKicadFootprintMetadata(kicadModString, metadata, footprintName) {
  try {
    const parsed = parseKicadSexpr3(kicadModString);
    const footprint = parsed.find(
      (node) => node instanceof Footprint5
    );
    if (!footprint) {
      return kicadModString;
    }
    if (metadata.version !== void 0) {
      footprint.version = Number(metadata.version);
    }
    if (metadata.generator !== void 0) {
      footprint.generator = metadata.generator;
    }
    if (metadata.generatorVersion !== void 0) {
      footprint.generatorVersion = String(metadata.generatorVersion);
    }
    if (metadata.embeddedFonts !== void 0) {
    }
    if (metadata.properties) {
      const newProperties = [];
      const refMeta = metadata.properties.Reference;
      newProperties.push(
        new Property3({
          key: "Reference",
          value: refMeta?.value ?? "REF**",
          position: refMeta?.at ? [
            Number(refMeta.at.x),
            Number(refMeta.at.y),
            Number(refMeta.at.rotation ?? 0)
          ] : [0, 0, 0],
          layer: refMeta?.layer ?? "F.SilkS",
          uuid: refMeta?.uuid ?? generateDeterministicUuid(`${footprintName}-property-Reference`),
          effects: createTextEffects3(refMeta?.effects),
          hidden: refMeta?.hide
        })
      );
      const valMeta = metadata.properties.Value;
      newProperties.push(
        new Property3({
          key: "Value",
          value: valMeta?.value ?? footprintName,
          position: valMeta?.at ? [
            Number(valMeta.at.x),
            Number(valMeta.at.y),
            Number(valMeta.at.rotation ?? 0)
          ] : [0, 0, 0],
          layer: valMeta?.layer ?? "F.Fab",
          uuid: valMeta?.uuid ?? generateDeterministicUuid(`${footprintName}-property-Value`),
          effects: createTextEffects3(valMeta?.effects),
          hidden: valMeta?.hide
        })
      );
      const dsMeta = metadata.properties.Datasheet;
      newProperties.push(
        new Property3({
          key: "Datasheet",
          value: dsMeta?.value ?? "",
          position: dsMeta?.at ? [
            Number(dsMeta.at.x),
            Number(dsMeta.at.y),
            Number(dsMeta.at.rotation ?? 0)
          ] : [0, 0, 0],
          layer: dsMeta?.layer ?? "F.Fab",
          uuid: dsMeta?.uuid ?? generateDeterministicUuid(`${footprintName}-property-Datasheet`),
          effects: createTextEffects3(dsMeta?.effects),
          hidden: dsMeta?.hide ?? true
        })
      );
      const descMeta = metadata.properties.Description;
      newProperties.push(
        new Property3({
          key: "Description",
          value: descMeta?.value ?? "",
          position: descMeta?.at ? [
            Number(descMeta.at.x),
            Number(descMeta.at.y),
            Number(descMeta.at.rotation ?? 0)
          ] : [0, 0, 0],
          layer: descMeta?.layer ?? "F.Fab",
          uuid: descMeta?.uuid ?? generateDeterministicUuid(`${footprintName}-property-Description`),
          effects: createTextEffects3(descMeta?.effects),
          hidden: descMeta?.hide ?? true
        })
      );
      footprint.properties = newProperties;
    }
    if (metadata.attributes && footprint.attr) {
      if (metadata.attributes.through_hole) {
        footprint.attr.type = "through_hole";
      } else if (metadata.attributes.smd) {
        footprint.attr.type = "smd";
      }
      if (metadata.attributes.exclude_from_pos_files !== void 0) {
        footprint.attr.excludeFromPosFiles = metadata.attributes.exclude_from_pos_files;
      }
      if (metadata.attributes.exclude_from_bom !== void 0) {
        footprint.attr.excludeFromBom = metadata.attributes.exclude_from_bom;
      }
    }
    return footprint.getString();
  } catch (error) {
    console.warn(`Failed to apply kicadFootprintMetadata:`, error);
    return kicadModString;
  }
}

// lib/kicad-library/stages/ClassifyKicadFootprintsStage.ts
import { parseKicadMod as parseKicadMod2 } from "kicadts";
var KICAD_3RD_PARTY_PLACEHOLDER2 = "${KICAD_3RD_PARTY}";
function classifyKicadFootprints(ctx) {
  for (const extractedKicadComponent of ctx.extractedKicadComponents) {
    classifyFootprintsForComponent({
      ctx,
      extractedKicadComponent
    });
  }
}
function classifyFootprintsForComponent({
  ctx,
  extractedKicadComponent
}) {
  const { tscircuitComponentName, kicadFootprints } = extractedKicadComponent;
  let hasAddedUserFootprint = false;
  const builtComponent = ctx.builtTscircuitComponents.find(
    (c) => c.tscircuitComponentName === tscircuitComponentName
  );
  const pcbComponent = builtComponent?.circuitJson.find(
    (el) => el.type === "pcb_component"
  );
  const metadata = pcbComponent?.metadata?.kicad_footprint;
  for (const kicadFootprint of kicadFootprints) {
    if (kicadFootprint.isBuiltin) {
      addBuiltinFootprint({ ctx, kicadFootprint });
    } else {
      if (!hasAddedUserFootprint) {
        hasAddedUserFootprint = true;
        let renamedFootprint = renameKicadFootprint({
          kicadFootprint,
          newKicadFootprintName: tscircuitComponentName,
          kicadLibraryName: ctx.kicadLibraryName,
          isPcm: ctx.isPcm,
          kicadPcmPackageId: ctx.kicadPcmPackageId
        });
        if (metadata) {
          renamedFootprint = {
            ...renamedFootprint,
            kicadModString: applyKicadFootprintMetadata(
              renamedFootprint.kicadModString,
              metadata,
              tscircuitComponentName
            )
          };
        }
        addUserFootprint({ ctx, kicadFootprint: renamedFootprint });
      } else {
        addUserFootprint({ ctx, kicadFootprint });
      }
    }
  }
}
function addUserFootprint({
  ctx,
  kicadFootprint
}) {
  const alreadyExists = ctx.userKicadFootprints.some(
    (fp) => fp.footprintName === kicadFootprint.footprintName
  );
  if (!alreadyExists) {
    ctx.userKicadFootprints.push(kicadFootprint);
  }
}
function addBuiltinFootprint({
  ctx,
  kicadFootprint
}) {
  const alreadyExists = ctx.builtinKicadFootprints.some(
    (fp) => fp.footprintName === kicadFootprint.footprintName
  );
  if (!alreadyExists) {
    if (ctx.isPcm && ctx.kicadPcmPackageId) {
      const updatedFootprint = updateBuiltinFootprintModelPaths({
        kicadFootprint,
        kicadPcmPackageId: ctx.kicadPcmPackageId
      });
      ctx.builtinKicadFootprints.push(updatedFootprint);
    } else {
      ctx.builtinKicadFootprints.push(kicadFootprint);
    }
  }
}
function updateBuiltinFootprintModelPaths({
  kicadFootprint,
  kicadPcmPackageId
}) {
  const footprint = parseKicadMod2(kicadFootprint.kicadModString);
  for (const model of footprint.models) {
    const currentPath = model.path;
    const usesProjectPath = currentPath.includes("${KIPRJMOD}/") || /3dmodels[\\/]/.test(currentPath);
    if (usesProjectPath) {
      const filename = currentPath.split(/[\\/]/).pop() ?? "";
      model.path = `${KICAD_3RD_PARTY_PLACEHOLDER2}/3dmodels/${kicadPcmPackageId}/tscircuit_builtin.3dshapes/${filename}`;
    }
  }
  return {
    footprintName: kicadFootprint.footprintName,
    kicadModString: footprint.getString(),
    model3dSourcePaths: kicadFootprint.model3dSourcePaths,
    isBuiltin: kicadFootprint.isBuiltin
  };
}
function componentHasCustomFootprint(extractedKicadComponent) {
  return extractedKicadComponent.kicadFootprints.some((fp) => !fp.isBuiltin);
}

// lib/kicad-library/kicad-library-converter-utils/renameKicadSymbol.ts
function renameKicadSymbol(params) {
  const { kicadSymbol, newKicadSymbolName } = params;
  const symbol = kicadSymbol.symbol;
  const oldName = symbol.libraryId;
  symbol.libraryId = newKicadSymbolName;
  if (oldName && symbol.subSymbols) {
    for (const subSymbol of symbol.subSymbols) {
      if (subSymbol.libraryId?.startsWith(oldName)) {
        const suffix = subSymbol.libraryId.slice(oldName.length);
        subSymbol.libraryId = newKicadSymbolName + suffix;
      }
    }
  }
  return { symbolName: newKicadSymbolName, symbol };
}

// lib/kicad-library/kicad-library-converter-utils/updateKicadSymbolFootprint.ts
function updateKicadSymbolFootprint(params) {
  const { kicadSymbol, kicadLibraryName, kicadFootprintName, isPcm } = params;
  const properties = kicadSymbol.symbol.properties ?? [];
  const effectiveKicadLibraryName = isPcm ? `PCM_${kicadLibraryName}` : kicadLibraryName;
  for (const prop of properties) {
    if (prop.key === "Footprint") {
      prop.value = `${effectiveKicadLibraryName}:${kicadFootprintName}`;
    }
  }
}

// lib/kicad-library/kicad-library-converter-utils/updateBuiltinKicadSymbolFootprint.ts
function updateBuiltinKicadSymbolFootprint(kicadSymbol, options) {
  const symbol = kicadSymbol.symbol;
  const properties = symbol.properties ?? [];
  const libraryName = options?.isPcm ? "PCM_tscircuit_builtin" : "tscircuit_builtin";
  for (const prop of properties) {
    if (prop.key === "Footprint" && prop.value) {
      const parts = prop.value.split(":");
      const footprintName = parts.length > 1 ? parts[1] : parts[0];
      prop.value = `${libraryName}:${footprintName}`;
    }
  }
  return { symbolName: kicadSymbol.symbolName, symbol };
}

// lib/kicad-library/kicad-library-converter-utils/applyKicadSymbolMetadata.ts
import {
  EmbeddedFonts as EmbeddedFonts6,
  SymbolPinNames as SymbolPinNames3,
  SymbolPinNumbers as SymbolPinNumbers3,
  SymbolProperty as SymbolProperty4,
  TextEffects as TextEffects15,
  TextEffectsFont as TextEffectsFont15,
  TextEffectsJustify as TextEffectsJustify7
} from "kicadts";
var DEFAULT_TEXT_SIZE = 1.27;
var DEFAULT_TEXT_THICKNESS = 0.15;
var toNumber = (value, fallback) => {
  if (value === void 0) return fallback;
  const parsed = typeof value === "number" ? value : Number.parseFloat(value);
  if (Number.isNaN(parsed)) return fallback;
  return parsed;
};
var createTextEffects4 = (effectsMeta, fallback) => {
  if (!effectsMeta) return fallback;
  const effects = new TextEffects15({
    font: fallback?.font,
    justify: fallback?.justify,
    hiddenText: fallback?.hiddenText ?? false
  });
  if (!effects.font) {
    const defaultFont = new TextEffectsFont15();
    defaultFont.size = { width: DEFAULT_TEXT_SIZE, height: DEFAULT_TEXT_SIZE };
    effects.font = defaultFont;
  }
  if (effectsMeta.font?.size) {
    effects.font.size = {
      width: toNumber(effectsMeta.font.size.x, DEFAULT_TEXT_SIZE),
      height: toNumber(effectsMeta.font.size.y, DEFAULT_TEXT_SIZE)
    };
  }
  if (effectsMeta.font?.thickness !== void 0) {
    effects.font.thickness = toNumber(
      effectsMeta.font.thickness,
      DEFAULT_TEXT_THICKNESS
    );
  }
  if (!effects.font.size) {
    effects.font.size = { width: DEFAULT_TEXT_SIZE, height: DEFAULT_TEXT_SIZE };
  }
  if (!effects.font.thickness && effectsMeta.font?.thickness !== void 0) {
    effects.font.thickness = DEFAULT_TEXT_THICKNESS;
  }
  const justify = createJustify(effectsMeta.justify);
  if (justify) {
    effects.justify = justify;
  }
  if (effectsMeta.hide !== void 0) {
    effects.hiddenText = effectsMeta.hide;
  }
  return effects;
};
var createJustify = (justifyInput) => {
  if (!justifyInput) return void 0;
  const values = Array.isArray(justifyInput) ? justifyInput : [justifyInput];
  const options = {};
  for (const value of values) {
    if (value === "left" || value === "right") {
      options.horizontal = value;
    } else if (value === "top" || value === "bottom") {
      options.vertical = value;
    } else if (value === "mirror") {
      options.mirror = true;
    }
  }
  if (!options.horizontal && !options.vertical && !options.mirror) {
    return void 0;
  }
  return new TextEffectsJustify7(options);
};
var applySymbolProperty = (symbol, key, propertyMeta) => {
  const existingProperty = symbol.properties.find((prop) => prop.key === key);
  const nextId = propertyMeta.id !== void 0 ? toNumber(propertyMeta.id) : existingProperty?.id;
  const nextAt = propertyMeta.at ? [
    toNumber(propertyMeta.at.x, 0),
    toNumber(propertyMeta.at.y, 0),
    toNumber(propertyMeta.at.rotation, 0)
  ] : existingProperty?.at;
  const nextEffects = createTextEffects4(
    propertyMeta.effects,
    existingProperty?.effects
  );
  if (existingProperty) {
    existingProperty.value = propertyMeta.value;
    if (nextId !== void 0) {
      existingProperty.id = nextId;
    }
    if (nextAt) {
      existingProperty.at = nextAt;
    }
    if (nextEffects) {
      existingProperty.effects = nextEffects;
    }
    return;
  }
  symbol.properties.push(
    new SymbolProperty4({
      key,
      value: propertyMeta.value,
      id: nextId,
      at: nextAt,
      effects: nextEffects
    })
  );
};
function applyKicadSymbolMetadata(kicadSymbol, metadata) {
  const { symbol } = kicadSymbol;
  if (metadata.excludeFromSim !== void 0) {
    symbol.excludeFromSim = metadata.excludeFromSim;
  }
  if (metadata.inBom !== void 0) {
    symbol.inBom = metadata.inBom;
  }
  if (metadata.onBoard !== void 0) {
    symbol.onBoard = metadata.onBoard;
  }
  if (metadata.embeddedFonts !== void 0) {
    symbol._sxEmbeddedFonts = new EmbeddedFonts6(metadata.embeddedFonts);
  }
  if (metadata.pinNumbers?.hide !== void 0) {
    const pinNumbers = symbol.pinNumbers ?? new SymbolPinNumbers3();
    pinNumbers.hide = metadata.pinNumbers.hide;
    symbol.pinNumbers = pinNumbers;
  }
  if (metadata.pinNames) {
    const pinNames = symbol.pinNames ?? new SymbolPinNames3();
    if (metadata.pinNames.offset !== void 0) {
      pinNames.offset = toNumber(metadata.pinNames.offset, pinNames.offset);
    }
    if (metadata.pinNames.hide !== void 0) {
      pinNames.hide = metadata.pinNames.hide;
    }
    symbol.pinNames = pinNames;
  }
  if (metadata.properties) {
    for (const [key, propertyMeta] of Object.entries(metadata.properties)) {
      if (!propertyMeta) continue;
      applySymbolProperty(symbol, key, propertyMeta);
    }
  }
  return kicadSymbol;
}

// lib/kicad-library/stages/ClassifyKicadSymbolsStage.ts
var addedSymbolNames = /* @__PURE__ */ new Set();
function classifyKicadSymbols(ctx) {
  addedSymbolNames.clear();
  for (const extractedKicadComponent of ctx.extractedKicadComponents) {
    classifySymbolsForComponent({
      ctx,
      extractedKicadComponent
    });
  }
}
function getSymbolFootprintRef(kicadSymbol) {
  const properties = kicadSymbol.symbol.properties ?? [];
  for (const prop of properties) {
    if (prop.key === "Footprint" && prop.value) {
      const parts = prop.value.split(":");
      return (parts.length > 1 ? parts[1] : parts[0]) ?? null;
    }
  }
  return null;
}
function classifySymbolsForComponent({
  ctx,
  extractedKicadComponent
}) {
  const { tscircuitComponentName, kicadSymbols } = extractedKicadComponent;
  const hasCustomFootprint = componentHasCustomFootprint(
    extractedKicadComponent
  );
  let hasAddedUserSymbol = false;
  const customFootprintNames = new Set(
    extractedKicadComponent.kicadFootprints.filter((fp) => !fp.isBuiltin).map((fp) => fp.footprintName)
  );
  const builtComponent = ctx.builtTscircuitComponents.find(
    (c) => c.tscircuitComponentName === tscircuitComponentName
  );
  const schematicSymbol = builtComponent?.circuitJson.find(
    (el) => el.type === "schematic_symbol"
  );
  const metadata = schematicSymbol?.metadata?.kicad_symbol;
  for (const kicadSymbol of kicadSymbols) {
    if (!kicadSymbol.isBuiltin) {
      const symbolName = kicadSymbol.symbolName;
      if (addedSymbolNames.has(symbolName)) {
        continue;
      }
      addedSymbolNames.add(symbolName);
      if (hasCustomFootprint) {
        updateKicadSymbolFootprint({
          kicadSymbol,
          kicadLibraryName: ctx.kicadLibraryName,
          kicadFootprintName: tscircuitComponentName,
          isPcm: ctx.isPcm
        });
      }
      const updatedSymbol = metadata ? applyKicadSymbolMetadata(kicadSymbol, metadata) : kicadSymbol;
      addUserSymbol({ ctx, kicadSymbol: updatedSymbol });
    } else if (hasCustomFootprint && !hasAddedUserSymbol) {
      const footprintRef = getSymbolFootprintRef(kicadSymbol);
      const symbolMatchesCustomFootprint = footprintRef != null && customFootprintNames.has(footprintRef);
      if (symbolMatchesCustomFootprint) {
        hasAddedUserSymbol = true;
        const renamedSymbol = renameKicadSymbol({
          kicadSymbol,
          newKicadSymbolName: tscircuitComponentName
        });
        updateKicadSymbolFootprint({
          kicadSymbol: renamedSymbol,
          kicadLibraryName: ctx.kicadLibraryName,
          kicadFootprintName: tscircuitComponentName,
          isPcm: ctx.isPcm
        });
        const updatedSymbol = metadata ? applyKicadSymbolMetadata(renamedSymbol, metadata) : renamedSymbol;
        addUserSymbol({ ctx, kicadSymbol: updatedSymbol });
      } else {
        const updatedSymbol = updateBuiltinKicadSymbolFootprint(kicadSymbol, {
          isPcm: ctx.isPcm
        });
        addBuiltinSymbol({ ctx, kicadSymbol: updatedSymbol });
      }
    } else {
      const updatedSymbol = updateBuiltinKicadSymbolFootprint(kicadSymbol, {
        isPcm: ctx.isPcm
      });
      addBuiltinSymbol({ ctx, kicadSymbol: updatedSymbol });
    }
  }
}
function addUserSymbol({
  ctx,
  kicadSymbol
}) {
  const alreadyExistsByName = ctx.userKicadSymbols.some(
    (s) => s.symbolName === kicadSymbol.symbolName
  );
  if (alreadyExistsByName) {
    return;
  }
  ctx.userKicadSymbols.push(kicadSymbol);
}
function addBuiltinSymbol({
  ctx,
  kicadSymbol
}) {
  const alreadyExists = ctx.builtinKicadSymbols.some(
    (s) => s.symbolName === kicadSymbol.symbolName
  );
  if (!alreadyExists) {
    ctx.builtinKicadSymbols.push(kicadSymbol);
  }
}

// lib/kicad-library/stages/BuildKicadLibraryFilesStage.ts
import { KicadSymbolLib as KicadSymbolLib2 } from "kicadts";

// lib/kicad-library/kicad-library-converter-utils/generateSymLibTable.ts
function generateSymLibTable(params) {
  const { kicadLibraryName, includeUser, includeBuiltin } = params;
  let content = "(sym_lib_table\n";
  if (includeUser) {
    content += `  (lib (name "${kicadLibraryName}")(type "KiCad")(uri "\${KIPRJMOD}/symbols/${kicadLibraryName}.kicad_sym")(options "")(descr ""))
`;
  }
  if (includeBuiltin) {
    content += `  (lib (name "tscircuit_builtin")(type "KiCad")(uri "\${KIPRJMOD}/symbols/tscircuit_builtin.kicad_sym")(options "")(descr ""))
`;
  }
  content += ")\n";
  return content;
}

// lib/kicad-library/kicad-library-converter-utils/generateFpLibTable.ts
function generateFpLibTable(params) {
  const { kicadLibraryName, includeUser, includeBuiltin } = params;
  let content = "(fp_lib_table\n";
  if (includeUser) {
    content += `  (lib (name "${kicadLibraryName}")(type "KiCad")(uri "\${KIPRJMOD}/footprints/${kicadLibraryName}.pretty")(options "")(descr ""))
`;
  }
  if (includeBuiltin) {
    content += `  (lib (name "tscircuit_builtin")(type "KiCad")(uri "\${KIPRJMOD}/footprints/tscircuit_builtin.pretty")(options "")(descr ""))
`;
  }
  content += ")\n";
  return content;
}

// lib/kicad-library/stages/BuildKicadLibraryFilesStage.ts
var KICAD_SYM_LIB_VERSION2 = 20211014;
var KICAD_GENERATOR = "circuit-json-to-kicad";
function buildKicadLibraryFiles(ctx) {
  buildUserSymbolLibrary(ctx);
  buildBuiltinSymbolLibrary(ctx);
  buildUserFootprintLibrary(ctx);
  buildBuiltinFootprintLibrary(ctx);
  buildLibraryTables(ctx);
}
function buildUserSymbolLibrary(ctx) {
  if (ctx.userKicadSymbols.length === 0) return;
  const symbolLib = new KicadSymbolLib2({
    version: KICAD_SYM_LIB_VERSION2,
    generator: KICAD_GENERATOR,
    symbols: ctx.userKicadSymbols.map((s) => s.symbol)
  });
  ctx.kicadProjectFsMap[`symbols/${ctx.kicadLibraryName}.kicad_sym`] = symbolLib.getString();
}
function buildBuiltinSymbolLibrary(ctx) {
  if (!ctx.includeBuiltins || ctx.builtinKicadSymbols.length === 0) return;
  const symbolLib = new KicadSymbolLib2({
    version: KICAD_SYM_LIB_VERSION2,
    generator: KICAD_GENERATOR,
    symbols: ctx.builtinKicadSymbols.map((s) => s.symbol)
  });
  ctx.kicadProjectFsMap["symbols/tscircuit_builtin.kicad_sym"] = symbolLib.getString();
}
function buildUserFootprintLibrary(ctx) {
  for (const kicadFootprint of ctx.userKicadFootprints) {
    const filePath = `footprints/${ctx.kicadLibraryName}.pretty/${kicadFootprint.footprintName}.kicad_mod`;
    ctx.kicadProjectFsMap[filePath] = kicadFootprint.kicadModString;
  }
}
function buildBuiltinFootprintLibrary(ctx) {
  if (!ctx.includeBuiltins || ctx.builtinKicadFootprints.length === 0) return;
  for (const kicadFootprint of ctx.builtinKicadFootprints) {
    const filePath = `footprints/tscircuit_builtin.pretty/${kicadFootprint.footprintName}.kicad_mod`;
    ctx.kicadProjectFsMap[filePath] = kicadFootprint.kicadModString;
  }
}
function buildLibraryTables(ctx) {
  const hasUserFootprints = ctx.userKicadFootprints.length > 0;
  const hasUserSymbols = ctx.userKicadSymbols.length > 0;
  const hasBuiltinFootprints = ctx.includeBuiltins && ctx.builtinKicadFootprints.length > 0;
  const hasBuiltinSymbols = ctx.includeBuiltins && ctx.builtinKicadSymbols.length > 0;
  ctx.kicadProjectFsMap["fp-lib-table"] = generateFpLibTable({
    kicadLibraryName: ctx.kicadLibraryName,
    includeUser: hasUserFootprints,
    includeBuiltin: hasBuiltinFootprints
  });
  ctx.kicadProjectFsMap["sym-lib-table"] = generateSymLibTable({
    kicadLibraryName: ctx.kicadLibraryName,
    includeUser: hasUserSymbols,
    includeBuiltin: hasBuiltinSymbols
  });
}

// lib/kicad-library/KicadLibraryConverter.ts
var KicadLibraryConverter = class {
  options;
  output = null;
  ctx;
  constructor(options) {
    this.options = options;
    this.ctx = createKicadLibraryConverterContext({
      kicadLibraryName: options.kicadLibraryName ?? "tscircuit_library",
      includeBuiltins: options.includeBuiltins ?? true,
      isPcm: options.isPcm ?? false,
      kicadPcmPackageId: options.kicadPcmPackageId
    });
  }
  async run() {
    this.ctx.builtTscircuitComponents = await this.buildTscircuitComponents();
    this.ctx.extractedKicadComponents = this.extractKicadComponents();
    classifyKicadFootprints(this.ctx);
    classifyKicadSymbols(this.ctx);
    buildKicadLibraryFiles(this.ctx);
    this.output = {
      kicadProjectFsMap: this.ctx.kicadProjectFsMap,
      model3dSourcePaths: this.ctx.model3dSourcePaths
    };
  }
  /**
   * Builds tscircuit components to circuit-json.
   */
  async buildTscircuitComponents() {
    const builtTscircuitComponents = [];
    const { entrypoint } = this.options;
    const exports = await this.options.getExportsFromTsxFile(entrypoint);
    const namedExports = exports.filter(
      (name) => name !== "default" && /^[A-Z]/.test(name)
    );
    for (const exportName of namedExports) {
      let componentPath = entrypoint;
      if (this.options.resolveExportPath) {
        const resolved = await this.options.resolveExportPath(
          entrypoint,
          exportName
        );
        if (resolved) componentPath = resolved;
      }
      const circuitJson = await this.options.buildFileToCircuitJson(
        componentPath,
        exportName
      );
      if (circuitJson && (!Array.isArray(circuitJson) || circuitJson.length > 0)) {
        builtTscircuitComponents.push({
          tscircuitComponentName: exportName,
          circuitJson
        });
      }
    }
    if (exports.includes("default")) {
      let componentPath = entrypoint;
      if (this.options.resolveExportPath) {
        const resolved = await this.options.resolveExportPath(
          entrypoint,
          "default"
        );
        if (resolved) componentPath = resolved;
      }
      const componentName = deriveComponentNameFromPath(componentPath);
      const circuitJson = await this.options.buildFileToCircuitJson(
        componentPath,
        "default"
      );
      if (circuitJson && (!Array.isArray(circuitJson) || circuitJson.length > 0)) {
        builtTscircuitComponents.push({
          tscircuitComponentName: componentName,
          circuitJson
        });
      }
    }
    return builtTscircuitComponents;
  }
  /**
   * Extracts KiCad footprints and symbols from built tscircuit components.
   */
  extractKicadComponents() {
    const extractedKicadComponents = [];
    for (const builtTscircuitComponent of this.ctx.builtTscircuitComponents) {
      const { tscircuitComponentName, circuitJson } = builtTscircuitComponent;
      const libConverter = new CircuitJsonToKicadLibraryConverter(circuitJson, {
        libraryName: this.ctx.kicadLibraryName,
        footprintLibraryName: this.ctx.kicadLibraryName
      });
      libConverter.runUntilFinished();
      const libOutput = libConverter.getOutput();
      for (const path of libOutput.model3dSourcePaths) {
        if (!this.ctx.model3dSourcePaths.includes(path)) {
          this.ctx.model3dSourcePaths.push(path);
        }
      }
      extractedKicadComponents.push({
        tscircuitComponentName,
        kicadFootprints: libOutput.footprints,
        kicadSymbols: libOutput.symbols,
        model3dSourcePaths: libOutput.model3dSourcePaths
      });
    }
    return extractedKicadComponents;
  }
  getOutput() {
    if (!this.output) {
      throw new Error(
        "Converter has not been run yet. Call run() before getOutput()."
      );
    }
    return this.output;
  }
};
function createKicadLibraryConverterContext(params) {
  return {
    kicadLibraryName: params.kicadLibraryName,
    includeBuiltins: params.includeBuiltins,
    isPcm: params.isPcm,
    kicadPcmPackageId: params.kicadPcmPackageId,
    builtTscircuitComponents: [],
    extractedKicadComponents: [],
    userKicadFootprints: [],
    builtinKicadFootprints: [],
    userKicadSymbols: [],
    builtinKicadSymbols: [],
    model3dSourcePaths: [],
    kicadProjectFsMap: {}
  };
}
function deriveComponentNameFromPath(filePath) {
  const filename = filePath.split(/[/\\]/).pop() || filePath;
  return filename.replace(/\.(tsx?|jsx?)$/, "");
}
export {
  CircuitJsonToKicadLibraryConverter,
  CircuitJsonToKicadModConverter,
  CircuitJsonToKicadPcbConverter,
  CircuitJsonToKicadProConverter,
  CircuitJsonToKicadSchConverter,
  KicadLibraryConverter,
  resolveAndLoadKicad3dModelFiles
};
