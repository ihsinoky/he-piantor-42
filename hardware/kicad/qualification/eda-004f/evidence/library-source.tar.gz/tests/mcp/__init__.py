"""MCP server integration tests."""
